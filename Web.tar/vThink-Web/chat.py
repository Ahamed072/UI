"""Terminal-based RAG chatbot for vThink knowledge base."""

from sitemap_service.rag import rag_pipeline


def main():
    print("=" * 60)
    print("  vThink RAG Chatbot")
    print("  Type your question and press Enter.")
    print("  Type 'quit' or 'exit' to stop.")
    print("  Type 'clear' to reset chat history.")
    print("=" * 60)

    chat_history = []

    while True:
        print()
        query = input("You: ").strip()

        if not query:
            continue
        if query.lower() in ("quit", "exit"):
            print("Bye!")
            break
        if query.lower() == "clear":
            chat_history = []
            print("[Chat history cleared]")
            continue

        try:
            result = rag_pipeline(
                query=query,
                chat_history=chat_history,
            )

            answer = result["answer"]
            standalone = result["standalone_query"]
            category = result["detected_category"]
            sources = result["sources"]

            # Show reformulated query and detected category
            if standalone.lower().strip("? ") != query.lower().strip("? "):
                print(f"\n[Reformulated: {standalone}]")
            print(f"[Categories: {', '.join(category)}]")

            print(f"\nAssistant: {answer}")

            # Show sources
            seen = set()
            unique_sources = []
            for s in sources:
                url = s.get("url", "")
                if url and url not in seen:
                    seen.add(url)
                    unique_sources.append(url)

            if unique_sources:
                print("\nSources:")
                for url in unique_sources:
                    print(f"  - {url}")

            # Update chat history
            chat_history.append({"role": "user", "content": query})
            chat_history.append({"role": "assistant", "content": answer})

        except Exception as e:
            print(f"\n[Error: {e}]")


if __name__ == "__main__":
    main()
