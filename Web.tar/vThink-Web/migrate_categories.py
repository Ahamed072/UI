"""One-time migration: tag existing ChromaDB documents with category metadata."""

from sitemap_service.vector_store import get_collection, url_to_category


def main():
    collection = get_collection()
    all_docs = collection.get(include=["metadatas"])

    if not all_docs["ids"]:
        print("No documents found in ChromaDB.")
        return

    updated = 0
    for doc_id, meta in zip(all_docs["ids"], all_docs["metadatas"]):
        url = meta.get("url", "")
        category = url_to_category(url)
        meta["category"] = category
        collection.update(ids=[doc_id], metadatas=[meta])
        print(f"  {category:15s} <- {url}")
        updated += 1

    print(f"\nDone. Tagged {updated} documents.")


if __name__ == "__main__":
    main()
