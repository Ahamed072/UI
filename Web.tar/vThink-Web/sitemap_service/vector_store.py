from typing import Dict

import chromadb
from chromadb.utils.embedding_functions import SentenceTransformerEmbeddingFunction

from .config import CHROMA_DB_DIR, CHROMA_COLLECTION_NAME, EMBEDDING_MODEL


def url_to_category(url: str) -> str:
    """Derive a category tag from a URL for intent-based filtering."""
    if "vthink.ai" in url:
        return "ai-products"
    if "/services/" in url:
        return "services"
    if "/products/" in url:
        return "products"
    if "/careers" in url or "/jobs/" in url:
        return "careers"
    return "general"


def get_collection():
    """Get or create the ChromaDB collection with sentence-transformer embeddings."""
    client = chromadb.PersistentClient(path=CHROMA_DB_DIR)
    embedding_fn = SentenceTransformerEmbeddingFunction(model_name=EMBEDDING_MODEL)
    collection = client.get_or_create_collection(
        name=CHROMA_COLLECTION_NAME,
        embedding_function=embedding_fn,
    )
    return collection


def store_single_document(collection, url: str, content: str, site_label: str):
    """Store a single cleaned page in ChromaDB immediately after cleaning."""
    collection.upsert(
        ids=[url],
        documents=[content],
        metadatas=[{"type": "vThink-web", "url": url, "site": site_label, "category": url_to_category(url)}],
    )
    print(f"[VectorDB] Stored: {url} (collection total: {collection.count()})")
