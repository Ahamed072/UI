import re
import json
from typing import List, Dict, Optional
from collections import defaultdict

from openai import OpenAI
from rank_bm25 import BM25Okapi
from dotenv import load_dotenv

from .vector_store import get_collection
from .config import OPENAI_MODEL

load_dotenv()

client = OpenAI()

SEMANTIC_K = 15
KEYWORD_K = 15
FINAL_TOP_K = 8
RRF_CONSTANT = 60

VALID_CATEGORIES = ["services", "products", "ai-products", "careers", "general"]


# --- BM25 Index Cache ---
class BM25Index:
    """Cached BM25 index built from ChromaDB documents. Rebuilt only when doc count changes."""

    def __init__(self):
        self.bm25: Optional[BM25Okapi] = None
        self.ids: List[str] = []
        self.documents: List[str] = []
        self.metadatas: List[dict] = []
        self._doc_count: int = 0

    def _tokenize(self, text: str) -> List[str]:
        return re.findall(r"\w+", text.lower())

    def _build(self):
        collection = get_collection()
        current_count = collection.count()

        if current_count == self._doc_count and self.bm25 is not None:
            return

        print(f"[BM25] Building index ({current_count} documents)...")
        all_docs = collection.get(include=["documents", "metadatas"])

        self.ids = all_docs["ids"]
        self.documents = all_docs["documents"]
        self.metadatas = all_docs["metadatas"]

        tokenized_corpus = [self._tokenize(doc) for doc in self.documents]
        self.bm25 = BM25Okapi(tokenized_corpus)
        self._doc_count = current_count
        print(f"[BM25] Index ready")

    def search(
        self, query: str, top_k: int = KEYWORD_K, categories: Optional[List[str]] = None
    ) -> List[Dict]:
        self._build()

        if not self.ids:
            return []

        tokenized_query = self._tokenize(query)
        scores = self.bm25.get_scores(tokenized_query)

        scored_indices = sorted(
            range(len(scores)), key=lambda i: scores[i], reverse=True
        )

        # Filter by categories if specified (skip filtering for "general" or empty)
        filter_cats = [c for c in (categories or []) if c != "general"]

        results = []
        for idx in scored_indices:
            if scores[idx] <= 0:
                continue
            if filter_cats:
                doc_category = self.metadatas[idx].get("category", "general")
                if doc_category not in filter_cats:
                    continue
            results.append(
                {
                    "id": self.ids[idx],
                    "content": self.documents[idx],
                    "metadata": self.metadatas[idx],
                    "score": float(scores[idx]),
                }
            )
            if len(results) >= top_k:
                break

        print(f"[RAG] Keyword search: {len(results)} results (BM25, categories={categories})")
        return results

    def rebuild(self):
        self._doc_count = 0
        self.bm25 = None


bm25_index = BM25Index()


def reformulate_and_classify(
    query: str, chat_history: List[Dict[str, str]]
) -> Dict:
    """
    Single LLM call that:
    1. Reformulates the query into a standalone question (using chat history)
    2. Classifies the intent into one or more categories
    Returns {"query": "...", "categories": ["...", "..."]}
    """
    system_prompt = (
        "You are a query processor for vThink Solutions. You have two jobs:\n"
        "1. If chat history is provided, rewrite the user's question as a standalone question.\n"
        "   If no chat history, keep the question as-is.\n"
        "2. Classify the question into ONE or MORE relevant categories (return all that apply):\n"
        "   - services: about vThink's service offerings (DevOps, data engineering, infrastructure, app modernization, product engineering)\n"
        "   - products: about vThink's software products (KRA360, Rebrandify, AssetPro, CampusQuiz)\n"
        "   - ai-products: about vThink's AI-powered tools (Intelli Search, Palm ML, Conversational Analytics, Instant Dashboard, Answer Assistant, TLDR-IQ, Office Assistant Agent, MCP Server Suites, Rebrandify AI)\n"
        "   - careers: about job openings, hiring, career opportunities at vThink\n"
        "   - general: anything else (company info, contact, CSR, about, leadership, address, or unclear intent)\n\n"
        "Rules:\n"
        "- If the query is about products/tools in general, include BOTH products AND ai-products.\n"
        "- If the query mentions a specific product name, include only the matching category.\n"
        "- Use general only when no other category fits.\n\n"
        'Respond ONLY with valid JSON: {"query": "standalone question", "categories": ["cat1", "cat2"]}'
    )

    user_content = query
    if chat_history:
        history_text = "\n".join(
            f"{msg['role'].upper()}: {msg['content']}" for msg in chat_history
        )
        user_content = f"Chat History:\n{history_text}\n\nFollow-up Question: {query}"

    response = client.chat.completions.create(
        model=OPENAI_MODEL,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_content},
        ],
        temperature=0,
    )

    raw = response.choices[0].message.content.strip()

    # Parse JSON response
    try:
        parsed = json.loads(raw)
        standalone = parsed.get("query", query)
        categories = parsed.get("categories", ["general"])
        if isinstance(categories, str):
            categories = [categories]
        categories = [c for c in categories if c in VALID_CATEGORIES] or ["general"]
    except (json.JSONDecodeError, AttributeError):
        standalone = raw if not raw.startswith("{") else query
        categories = ["general"]

    print(f"[RAG] Original: {query}")
    print(f"[RAG] Reformulated: {standalone}")
    print(f"[RAG] Categories: {categories}")
    return {"query": standalone, "categories": categories}


def keyword_search(
    query: str, top_k: int = KEYWORD_K, categories: Optional[List[str]] = None
) -> List[Dict]:
    return bm25_index.search(query, top_k=top_k, categories=categories)


def semantic_search(
    query: str, top_k: int = SEMANTIC_K, categories: Optional[List[str]] = None
) -> List[Dict]:
    collection = get_collection()

    # Build category filter
    filter_cats = [c for c in (categories or []) if c != "general"]
    where_filter = None
    if filter_cats:
        if len(filter_cats) == 1:
            where_filter = {"category": filter_cats[0]}
        else:
            where_filter = {"category": {"$in": filter_cats}}
        filtered_count = len(
            collection.get(where=where_filter, include=[])["ids"]
        )
        n = min(top_k, filtered_count)
    else:
        n = min(top_k, collection.count())

    if n == 0:
        print(f"[RAG] Semantic search: 0 results (no docs for categories={categories})")
        return []

    results = collection.query(
        query_texts=[query], n_results=n, where=where_filter
    )

    documents = []
    for i in range(len(results["ids"][0])):
        documents.append(
            {
                "id": results["ids"][0][i],
                "content": results["documents"][0][i],
                "metadata": results["metadatas"][0][i],
                "distance": results["distances"][0][i]
                if results.get("distances")
                else None,
            }
        )

    print(f"[RAG] Semantic search: {len(documents)} results (categories={categories})")
    return documents


def reciprocal_rank_fusion(
    keyword_results: List[Dict],
    semantic_results: List[Dict],
    final_k: int = FINAL_TOP_K,
    k: int = RRF_CONSTANT,
) -> List[Dict]:
    doc_map: Dict[str, Dict] = {}
    rrf_scores: Dict[str, float] = defaultdict(float)

    for rank, doc in enumerate(keyword_results):
        doc_id = doc["id"]
        rrf_scores[doc_id] += 1.0 / (k + rank + 1)
        if doc_id not in doc_map:
            doc_map[doc_id] = doc

    for rank, doc in enumerate(semantic_results):
        doc_id = doc["id"]
        rrf_scores[doc_id] += 1.0 / (k + rank + 1)
        if doc_id not in doc_map:
            doc_map[doc_id] = doc

    ranked_ids = sorted(
        rrf_scores.keys(), key=lambda d: rrf_scores[d], reverse=True
    )
    top_ids = ranked_ids[:final_k]

    results = []
    for doc_id in top_ids:
        doc = doc_map[doc_id].copy()
        doc["rrf_score"] = rrf_scores[doc_id]
        results.append(doc)

    print(
        f"[RAG] RRF: {len(keyword_results)} keyword + {len(semantic_results)} semantic "
        f"-> {len(rrf_scores)} unique -> top {len(results)}"
    )
    return results


def generate_answer(
    query: str, context_docs: List[Dict], chat_history: List[Dict[str, str]]
) -> str:
    context_parts = []
    for i, doc in enumerate(context_docs, 1):
        meta = doc["metadata"]
        context_parts.append(
            f"[Source {i}]\n"
            f"URL: {meta.get('url', 'N/A')}\n"
            f"Site: {meta.get('site', 'N/A')}\n"
            f"Content:\n{doc['content']}"
        )

    context_text = "\n\n---\n\n".join(context_parts)

    messages = [
        {
            "role": "system",
            "content": (
                "You are a helpful assistant for vThink Solutions. Answer questions based on "
                "the provided context from vThink websites (vthink.co.in and vthink.ai). "
                "Use the context to give accurate, specific answers. "
                "If the context doesn't contain enough information to answer, say so clearly. "
                "When referencing information, mention the source URL."
            ),
        },
    ]

    for msg in chat_history:
        messages.append({"role": msg["role"], "content": msg["content"]})

    messages.append(
        {
            "role": "user",
            "content": (
                f"Context from vThink knowledge base:\n\n{context_text}\n\n"
                f"---\n\nQuestion: {query}"
            ),
        }
    )

    response = client.chat.completions.create(
        model=OPENAI_MODEL,
        messages=messages,
        temperature=0.3,
    )

    return response.choices[0].message.content


def rag_pipeline(
    query: str, chat_history: List[Dict[str, str]], top_k: int = FINAL_TOP_K
) -> Dict:
    """Full RAG pipeline: reformulate+classify -> filtered hybrid search -> RRF -> generate."""
    # Step 1: Reformulate query + classify intent (single LLM call)
    result = reformulate_and_classify(query, chat_history)
    standalone_query = result["query"]
    categories = result["categories"]

    # Step 2: Filtered hybrid search
    keyword_results = keyword_search(standalone_query, top_k=KEYWORD_K, categories=categories)
    semantic_results = semantic_search(standalone_query, top_k=SEMANTIC_K, categories=categories)

    # Step 3: Reciprocal Rank Fusion
    fused_results = reciprocal_rank_fusion(
        keyword_results, semantic_results, final_k=top_k
    )

    # Step 4: Generate answer
    answer = generate_answer(standalone_query, fused_results, chat_history)

    sources = [
        {"url": doc["metadata"].get("url"), "site": doc["metadata"].get("site")}
        for doc in fused_results
    ]

    return {
        "answer": answer,
        "standalone_query": standalone_query,
        "detected_category": categories,
        "sources": sources,
    }
