import asyncio
import sys
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, List

from crawl4ai import AsyncWebCrawler, BrowserConfig, CrawlerRunConfig, CacheMode

from .config import CRAWL_MAX_CONCURRENT


async def _crawl_impl(
    urls: List[str], max_concurrent: int
) -> Dict[str, str]:
    """Core crawl logic - runs inside its own event loop on Windows."""
    browser_config = BrowserConfig(
        headless=True,
        verbose=False,
        extra_args=["--disable-gpu", "--disable-dev-shm-usage", "--no-sandbox"],
    )
    crawl_config = CrawlerRunConfig(cache_mode=CacheMode.BYPASS)

    crawler = AsyncWebCrawler(config=browser_config)
    await crawler.start()

    results: Dict[str, str] = {}

    try:
        for i in range(0, len(urls), max_concurrent):
            batch = urls[i : i + max_concurrent]
            tasks = []

            for j, url in enumerate(batch):
                session_id = f"sitemap_session_{i + j}"
                task = crawler.arun(
                    url=url, config=crawl_config, session_id=session_id
                )
                tasks.append(task)

            batch_results = await asyncio.gather(*tasks, return_exceptions=True)

            for url, result in zip(batch, batch_results):
                if isinstance(result, Exception):
                    print(f"[Crawler] Error crawling {url}: {result}")
                elif result.success:
                    content = result.markdown
                    if hasattr(content, "raw_markdown"):
                        content = content.raw_markdown
                    if content and content.strip():
                        results[url] = content
                    else:
                        print(f"[Crawler] Empty content for {url}")
                else:
                    print(
                        f"[Crawler] Failed {url}: {getattr(result, 'error_message', 'Unknown error')}"
                    )

            print(
                f"[Crawler] Batch {i // max_concurrent + 1} done: {len(batch)} URLs processed"
            )

    finally:
        await crawler.close()

    print(f"[Crawler] Total: {len(results)}/{len(urls)} URLs crawled successfully")
    return results


def _run_in_new_loop(urls: List[str], max_concurrent: int) -> Dict[str, str]:
    """Run the crawl in a new ProactorEventLoop (needed on Windows for Playwright)."""
    if sys.platform == "win32":
        loop = asyncio.ProactorEventLoop()
        asyncio.set_event_loop(loop)
    else:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
    try:
        return loop.run_until_complete(_crawl_impl(urls, max_concurrent))
    finally:
        loop.close()


async def crawl_urls_parallel(
    urls: List[str], max_concurrent: int = CRAWL_MAX_CONCURRENT
) -> Dict[str, str]:
    """
    Crawl multiple URLs in parallel batches using crawl4ai.
    Runs in a separate thread to avoid Windows event loop limitations.
    Returns a dict of {url: markdown_content} for successfully crawled pages.
    """
    loop = asyncio.get_event_loop()
    with ThreadPoolExecutor(max_workers=1) as executor:
        result = await loop.run_in_executor(
            executor, _run_in_new_loop, urls, max_concurrent
        )
    return result
