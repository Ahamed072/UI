export type MessageSender = 'user' | 'bot';

export interface ChatMessage {
  readonly id: string;
  readonly content: string;
  readonly sender: MessageSender;
  readonly timestamp: Date;
  readonly isWebSearch: boolean;
}
