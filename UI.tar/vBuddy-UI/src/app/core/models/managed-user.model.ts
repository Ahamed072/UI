import { AppUser, UserRole } from './user.model';

export interface ManagedUser extends AppUser {
  readonly empId: string;
}

export interface UserFormData {
  readonly empId: string;
  readonly name: string;
  readonly email: string;
  readonly role: UserRole;
}
