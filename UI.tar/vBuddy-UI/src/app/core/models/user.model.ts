export type UserRole = 'user' | 'admin';

export interface AppUser {
  readonly id: string;
  readonly name: string;
  readonly email: string;
  readonly role: UserRole;
}
