export interface DocumentItem {
  readonly id: string;
  readonly name: string;
  readonly uploadedBy: string;
  readonly uploadedAt: Date;
  readonly fileSize: string;
}
