import { Injectable, signal } from '@angular/core';
import { ChatMessage } from '../models/message.model';
import { ALL_MOCK_RESPONSES } from '../constants/mock-responses.constant';
import { APP_CONSTANTS } from '../constants/app.constants';

@Injectable({ providedIn: 'root' })
export class ChatService {
  private readonly messagesSignal = signal<ChatMessage[]>([]);
  private readonly isTypingSignal = signal(false);
  private typingTimeoutId: ReturnType<typeof setTimeout> | null = null;

  public readonly messages = this.messagesSignal.asReadonly();
  public readonly isTyping = this.isTypingSignal.asReadonly();

  public sendMessage(content: string, isWebSearch: boolean): void {
    const trimmedContent = content.trim();
    if (!trimmedContent) {
      return;
    }

    const userMessage: ChatMessage = {
      id: crypto.randomUUID(),
      content: trimmedContent,
      sender: 'user',
      timestamp: new Date(),
      isWebSearch,
    };

    this.messagesSignal.update((messages) => [...messages, userMessage]);
    this.simulateBotResponse(trimmedContent, isWebSearch);
  }

  public clearChat(): void {
    this.messagesSignal.set([]);
    this.isTypingSignal.set(false);
    this.clearTypingTimeout();
  }

  private simulateBotResponse(userQuery: string, isWebSearch: boolean): void {
    this.isTypingSignal.set(true);
    this.clearTypingTimeout();

    this.typingTimeoutId = setTimeout(() => {
      const responseContent = this.findMockResponse(userQuery, isWebSearch);

      const botMessage: ChatMessage = {
        id: crypto.randomUUID(),
        content: responseContent,
        sender: 'bot',
        timestamp: new Date(),
        isWebSearch,
      };

      this.messagesSignal.update((messages) => [...messages, botMessage]);
      this.isTypingSignal.set(false);
    }, APP_CONSTANTS.typingDelayMs);
  }

  private findMockResponse(query: string, isWebSearch: boolean): string {
    const lowerQuery = query.toLowerCase();
    const prefix = isWebSearch ? APP_CONSTANTS.webSearchPrefix : '';

    const matchedRule = ALL_MOCK_RESPONSES.find((rule) =>
      rule.keywords.some((keyword) => lowerQuery.includes(keyword))
    );

    const response = matchedRule?.response ?? APP_CONSTANTS.fallbackResponse;
    return prefix + response;
  }

  private clearTypingTimeout(): void {
    if (this.typingTimeoutId !== null) {
      clearTimeout(this.typingTimeoutId);
      this.typingTimeoutId = null;
    }
  }
}
