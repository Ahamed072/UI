import { computed, Injectable, signal } from '@angular/core';
import { Router } from '@angular/router';
import { AppUser, UserRole } from '../models/user.model';
import { MOCK_CREDENTIALS } from '../constants/app.constants';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly currentUserSignal = signal<AppUser | null>(null);

  public readonly currentUser = this.currentUserSignal.asReadonly();
  public readonly isAuthenticated = computed(() => this.currentUserSignal() !== null);
  public readonly userRole = computed<UserRole | null>(() => this.currentUserSignal()?.role ?? null);
  public readonly isAdmin = computed(() => this.userRole() === 'admin');

  constructor(private readonly router: Router) {}

  public login(email: string, password: string): boolean {
    const trimmedEmail = email.trim().toLowerCase();
    const trimmedPassword = password.trim();

    if (!trimmedEmail || !trimmedPassword) {
      return false;
    }

    const matched = MOCK_CREDENTIALS.find(
      (cred) => cred.email === trimmedEmail && cred.password === trimmedPassword,
    );

    if (!matched) {
      return false;
    }

    const user: AppUser = {
      id: crypto.randomUUID(),
      name: matched.name,
      email: matched.email,
      role: matched.role,
    };

    this.currentUserSignal.set(user);
    return true;
  }

  public logout(): void {
    this.currentUserSignal.set(null);
    void this.router.navigate(['/login']);
  }
}
