import { computed, Injectable, signal } from '@angular/core';
import { DocumentItem } from '../models/document.model';
import { MOCK_DOCUMENTS } from '../constants/mock-documents.constant';

const MIN_FILE_SIZE_KB = 200;
const MAX_FILE_SIZE_KB = 4000;
const KB_PER_MB = 1000;

@Injectable({ providedIn: 'root' })
export class DocumentService {
  private readonly documentsSignal = signal<DocumentItem[]>([...MOCK_DOCUMENTS]);

  public readonly documents = this.documentsSignal.asReadonly();
  public readonly totalCount = computed(() => this.documentsSignal().length);

  public addDocument(name: string, uploadedBy: string): void {
    const newDoc: DocumentItem = {
      id: crypto.randomUUID(),
      name,
      uploadedBy,
      uploadedAt: new Date(),
      fileSize: this.generateMockFileSize(),
    };

    this.documentsSignal.update((docs) => [newDoc, ...docs]);
  }

  public updateDocument(id: string, newName: string): void {
    this.documentsSignal.update((docs) =>
      docs.map((doc) =>
        doc.id === id
          ? { ...doc, name: newName, uploadedAt: new Date() }
          : doc,
      ),
    );
  }

  public deleteDocument(id: string): void {
    this.documentsSignal.update((docs) => docs.filter((doc) => doc.id !== id));
  }

  private generateMockFileSize(): string {
    const sizeKb = Math.floor(Math.random() * MAX_FILE_SIZE_KB) + MIN_FILE_SIZE_KB;
    return sizeKb >= KB_PER_MB
      ? `${(sizeKb / KB_PER_MB).toFixed(1)} MB`
      : `${sizeKb} KB`;
  }
}
