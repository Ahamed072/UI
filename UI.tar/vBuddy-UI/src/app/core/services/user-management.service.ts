import { computed, Injectable, signal } from '@angular/core';
import { ManagedUser } from '../models/managed-user.model';
import { UserRole } from '../models/user.model';
import { MOCK_USERS } from '../constants/mock-users.constant';

@Injectable({ providedIn: 'root' })
export class UserManagementService {
  private readonly usersSignal = signal<ManagedUser[]>([...MOCK_USERS]);

  public readonly users = this.usersSignal.asReadonly();
  public readonly totalCount = computed(() => this.usersSignal().length);

  public addUser(empId: string, name: string, email: string, role: UserRole): void {
    const newUser: ManagedUser = {
      id: crypto.randomUUID(),
      empId,
      name,
      email,
      role,
    };
    this.usersSignal.update((users) => [newUser, ...users]);
  }

  public updateUser(id: string, name: string, email: string, role: UserRole): void {
    this.usersSignal.update((users) =>
      users.map((user) =>
        user.id === id ? { ...user, name, email, role } : user,
      ),
    );
  }

  public deleteUser(id: string): void {
    this.usersSignal.update((users) => users.filter((user) => user.id !== id));
  }
}
