import { UserRole } from '../models/user.model';

export const APP_CONSTANTS = {
  appName: 'vBuddy',
  appTagline: 'Your Intelligent Company Assistant',
  typingDelayMs: 1500,
  defaultGreeting: 'Hello! I\'m vBuddy, your company assistant. How can I help you today?',
  fallbackResponse: 'I appreciate your question. Let me look into that for you. For more specific information, please reach out to the relevant department or try rephrasing your query.',
  webSearchPrefix: '[Web Search] ',
  maxMessageLength: 2000,
} as const;

export const SUGGESTION_CHIPS = [
  {
    label: 'Company Policies',
    query: 'What are the company policies regarding leave and work from home?',
    icon: 'policy',
  },
  {
    label: 'Internal Apps',
    query: 'What internal applications are available for employees?',
    icon: 'apps',
  },
  {
    label: 'General Info',
    query: 'Tell me about the company overview and mission.',
    icon: 'info',
  },
] as const;

interface MockCredential {
  readonly email: string;
  readonly password: string;
  readonly name: string;
  readonly role: UserRole;
}

export const MOCK_CREDENTIALS: readonly MockCredential[] = [
  { email: 'user@company.com', password: 'user123', name: 'John User', role: 'user' },
  { email: 'admin@company.com', password: 'admin123', name: 'Admin Manager', role: 'admin' },
] as const;

export const ADMIN_NAV_ITEMS = [
  { label: 'Document Management', icon: 'description', route: 'documents' },
  { label: 'User Management', icon: 'people', route: 'users' },
  { label: 'Chat Interface', icon: 'chat', route: 'chat' },
] as const;
