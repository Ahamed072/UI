interface MockResponseRule {
  readonly keywords: readonly string[];
  readonly response: string;
}

const POLICY_RESPONSES: readonly MockResponseRule[] = [
  {
    keywords: ['leave', 'vacation', 'pto', 'time off', 'holiday'],
    response:
      'Our leave policy provides employees with:\n\n' +
      '- **Casual Leave**: 12 days per year\n' +
      '- **Sick Leave**: 10 days per year\n' +
      '- **Earned Leave**: 15 days per year\n' +
      '- **Public Holidays**: As per the regional calendar\n\n' +
      'Leave requests must be submitted at least 3 business days in advance through the HRMS portal. ' +
      'For sick leave exceeding 2 consecutive days, a medical certificate is required.',
  },
  {
    keywords: ['wfh', 'work from home', 'remote', 'hybrid', 'work from'],
    response:
      'Our hybrid work policy allows employees to:\n\n' +
      '- Work from home up to **3 days per week**\n' +
      '- Mandatory in-office days are **Tuesday and Thursday**\n' +
      '- Remote work requests must be approved by your reporting manager\n' +
      '- Ensure stable internet connectivity and availability during core hours (10 AM - 5 PM)\n\n' +
      'For extended remote work (more than 1 week), please submit a request through the HRMS portal.',
  },
  {
    keywords: ['dress', 'attire', 'dress code', 'clothing'],
    response:
      'Our dress code policy is **Business Casual** for regular workdays:\n\n' +
      '- **Acceptable**: Collared shirts, blouses, chinos, formal trousers, closed-toe shoes\n' +
      '- **Fridays**: Smart casual is permitted\n' +
      '- **Client Meetings**: Formal business attire is required\n' +
      '- **Not Permitted**: Flip-flops, shorts, sleeveless tops, ripped jeans\n\n' +
      'Please refer to the employee handbook on Confluence for complete details.',
  },
  {
    keywords: ['travel', 'business travel', 'trip', 'onsite'],
    response:
      'Business travel guidelines:\n\n' +
      '- All travel must be pre-approved by your manager and the finance team\n' +
      '- **Domestic Travel**: Book through the company travel portal for best rates\n' +
      '- **International Travel**: Requires VP-level approval and must be initiated 2 weeks in advance\n' +
      '- **Per Diem**: Domestic - INR 2,500/day | International - USD 75/day\n' +
      '- Submit expense reports within 5 business days of return via the Expense Management app.',
  },
  {
    keywords: ['expense', 'reimbursement', 'claim', 'bills'],
    response:
      'Expense reimbursement process:\n\n' +
      '1. Log into the **Expense Management App**\n' +
      '2. Create a new expense report with valid receipts\n' +
      '3. Categorize expenses (Travel, Meals, Office Supplies, etc.)\n' +
      '4. Submit for manager approval\n' +
      '5. Reimbursement is processed within **7-10 business days** after approval\n\n' +
      'Note: Expenses over INR 5,000 require additional approval from the department head.',
  },
  {
    keywords: ['performance', 'review', 'appraisal', 'rating', 'promotion'],
    response:
      'Performance review cycle:\n\n' +
      '- **Annual Reviews**: Conducted in March-April each year\n' +
      '- **Mid-Year Check-in**: September (informal, goal alignment)\n' +
      '- **Rating Scale**: 1-5 (Exceeds Expectations, Meets Expectations, Developing, Below Expectations, Needs Improvement)\n' +
      '- **Promotion Cycles**: Twice a year (April and October)\n\n' +
      'Ensure your goals are updated in the HRMS portal before the review period begins.',
  },
];

const APP_RESPONSES: readonly MockResponseRule[] = [
  {
    keywords: ['hrms', 'hr portal', 'human resource', 'hr system'],
    response:
      '**HRMS Portal** - Human Resource Management System\n\n' +
      '- **URL**: hrms.company.internal\n' +
      '- **Purpose**: Leave management, attendance tracking, payslips, tax declarations, and employee records\n' +
      '- **Access**: Use your company SSO credentials\n' +
      '- **Support**: Raise a ticket on ServiceDesk under "HRMS Support" category',
  },
  {
    keywords: ['jira', 'ticket', 'task management', 'project management', 'sprint'],
    response:
      '**Jira** - Project & Task Management\n\n' +
      '- **URL**: jira.company.internal\n' +
      '- **Purpose**: Sprint planning, bug tracking, task assignment, and project management\n' +
      '- **Access**: Auto-provisioned for all engineering and product team members\n' +
      '- **Tip**: Use the "Quick Create" shortcut (C) to create tickets faster',
  },
  {
    keywords: ['confluence', 'wiki', 'documentation', 'docs', 'knowledge base'],
    response:
      '**Confluence** - Knowledge Base & Documentation\n\n' +
      '- **URL**: confluence.company.internal\n' +
      '- **Purpose**: Team documentation, meeting notes, project wikis, and runbooks\n' +
      '- **Key Spaces**: Engineering Docs, Product Wiki, HR Policies, Onboarding Guide\n' +
      '- **Access**: Available to all employees via SSO',
  },
  {
    keywords: ['slack', 'chat', 'messaging', 'communication', 'channel'],
    response:
      '**Slack** - Team Communication\n\n' +
      '- **Purpose**: Real-time messaging, team channels, and integrations\n' +
      '- **Key Channels**: #general, #engineering, #hr-queries, #random, #announcements\n' +
      '- **Guidelines**: Use threads for discussions, keep #general for important updates\n' +
      '- **Tip**: Install the desktop app for better notification management',
  },
  {
    keywords: ['vpn', 'network', 'remote access', 'connect'],
    response:
      '**VPN** - Virtual Private Network\n\n' +
      '- **Client**: GlobalProtect VPN\n' +
      '- **Setup Guide**: Available on Confluence under "IT Setup Guides"\n' +
      '- **Connection**: Required for accessing internal services from outside the office\n' +
      '- **Support**: Contact IT Helpdesk at ext. 1234 or raise a ServiceDesk ticket',
  },
  {
    keywords: ['timesheet', 'time tracking', 'hours', 'log time', 'time entry'],
    response:
      '**Timesheet Portal**\n\n' +
      '- **URL**: timesheet.company.internal\n' +
      '- **Purpose**: Log daily work hours and project-wise time allocation\n' +
      '- **Deadline**: Timesheets must be submitted by **Friday 6:00 PM** each week\n' +
      '- **Note**: Missing timesheets may affect your monthly payroll processing\n' +
      '- **Access**: Available through HRMS portal under "My Timesheet"',
  },
  {
    keywords: ['internal', 'apps', 'applications', 'tools', 'software', 'systems'],
    response:
      'Here are the key internal applications available to employees:\n\n' +
      '| Application | Purpose |\n' +
      '|---|---|\n' +
      '| **HRMS** | Leave, attendance, payslips |\n' +
      '| **Jira** | Project & task management |\n' +
      '| **Confluence** | Documentation & wikis |\n' +
      '| **Slack** | Team communication |\n' +
      '| **VPN (GlobalProtect)** | Remote network access |\n' +
      '| **Timesheet Portal** | Time tracking |\n' +
      '| **ServiceDesk** | IT support tickets |\n' +
      '| **Expense Manager** | Reimbursements |\n\n' +
      'All applications are accessible via SSO. Visit the IT Setup Guide on Confluence for installation instructions.',
  },
];

const GENERAL_RESPONSES: readonly MockResponseRule[] = [
  {
    keywords: ['about', 'company', 'overview', 'who are', 'what is'],
    response:
      '**About Our Company**\n\n' +
      'We are a leading technology solutions provider specializing in digital transformation, ' +
      'cloud services, and enterprise software development. Founded in 2010, we have grown to ' +
      'a team of **2,500+ employees** across 8 global offices.\n\n' +
      '- **Industry**: Information Technology & Services\n' +
      '- **Headquarters**: Bangalore, India\n' +
      '- **Founded**: 2010\n' +
      '- **Employees**: 2,500+',
  },
  {
    keywords: ['ceo', 'founder', 'leadership', 'management', 'cto', 'executive'],
    response:
      '**Leadership Team**\n\n' +
      '- **CEO**: Rajesh Kumar - Visionary leader with 20+ years in tech industry\n' +
      '- **CTO**: Priya Sharma - Leads technology strategy and innovation\n' +
      '- **CFO**: Amit Patel - Oversees financial operations and growth strategy\n' +
      '- **VP Engineering**: Sanjay Reddy - Manages engineering teams globally\n' +
      '- **VP HR**: Neha Gupta - Drives people strategy and culture initiatives\n\n' +
      'The leadership team meets quarterly for company-wide town halls.',
  },
  {
    keywords: ['office', 'location', 'branch', 'address', 'where'],
    response:
      '**Office Locations**\n\n' +
      '| Location | Type | Address |\n' +
      '|---|---|---|\n' +
      '| **Bangalore** | HQ | Tech Park, Whitefield |\n' +
      '| **Chennai** | Dev Center | OMR IT Corridor |\n' +
      '| **Hyderabad** | Dev Center | HITEC City |\n' +
      '| **Mumbai** | Sales Office | BKC |\n' +
      '| **New York** | US Office | Manhattan |\n' +
      '| **London** | UK Office | Canary Wharf |\n' +
      '| **Singapore** | APAC Office | Marina Bay |\n' +
      '| **Dubai** | MEA Office | DIFC |\n\n' +
      'Contact the admin team for visitor access and parking details.',
  },
  {
    keywords: ['department', 'team', 'org', 'structure', 'division'],
    response:
      '**Departments & Teams**\n\n' +
      '- **Engineering**: Frontend, Backend, DevOps, QA, Data Engineering\n' +
      '- **Product**: Product Management, UX/UI Design, Business Analysis\n' +
      '- **Sales & Marketing**: Sales, Marketing, Customer Success, Pre-Sales\n' +
      '- **Operations**: HR, Finance, Admin, Legal, IT Support\n' +
      '- **Innovation Lab**: R&D, AI/ML, Emerging Technologies\n\n' +
      'Each department has a dedicated Slack channel and Confluence space.',
  },
  {
    keywords: ['mission', 'vision', 'values', 'culture', 'goal'],
    response:
      '**Our Mission & Values**\n\n' +
      '**Mission**: To empower businesses through innovative technology solutions that drive growth and efficiency.\n\n' +
      '**Vision**: To be the most trusted technology partner for enterprises worldwide.\n\n' +
      '**Core Values**:\n' +
      '1. **Innovation First** - We embrace change and push boundaries\n' +
      '2. **Customer Obsession** - Client success is our success\n' +
      '3. **Integrity** - We do the right thing, always\n' +
      '4. **Collaboration** - Together, we achieve more\n' +
      '5. **Excellence** - We strive for quality in everything we do',
  },
];

export const ALL_MOCK_RESPONSES: readonly MockResponseRule[] = [
  ...POLICY_RESPONSES,
  ...APP_RESPONSES,
  ...GENERAL_RESPONSES,
];
