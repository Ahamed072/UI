import { ManagedUser } from '../models/managed-user.model';

export const MOCK_USERS: ManagedUser[] = [
  {
    id: '1',
    empId: 'EMP001',
    name: 'John User',
    email: 'john.user@company.com',
    role: 'user',
  },
  {
    id: '2',
    empId: 'EMP002',
    name: 'Admin Manager',
    email: 'admin@company.com',
    role: 'admin',
  },
  {
    id: '3',
    empId: 'EMP003',
    name: 'Sarah Connor',
    email: 'sarah.connor@company.com',
    role: 'user',
  },
  {
    id: '4',
    empId: 'EMP004',
    name: 'Mike Chen',
    email: 'mike.chen@company.com',
    role: 'user',
  },
  {
    id: '5',
    empId: 'EMP005',
    name: 'Emily Davis',
    email: 'emily.davis@company.com',
    role: 'admin',
  },
  {
    id: '6',
    empId: 'EMP006',
    name: 'Raj Patel',
    email: 'raj.patel@company.com',
    role: 'user',
  },
];
