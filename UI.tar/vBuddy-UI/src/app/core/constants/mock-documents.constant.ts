import { DocumentItem } from '../models/document.model';

export const MOCK_DOCUMENTS: DocumentItem[] = [
  {
    id: '1',
    name: 'Employee Handbook 2025.pdf',
    uploadedBy: 'Admin Manager',
    uploadedAt: new Date('2025-01-15T10:30:00'),
    fileSize: '2.4 MB',
  },
  {
    id: '2',
    name: 'IT Security Policy.pdf',
    uploadedBy: 'Admin Manager',
    uploadedAt: new Date('2025-02-20T14:15:00'),
    fileSize: '1.1 MB',
  },
  {
    id: '3',
    name: 'Leave Policy Guidelines.pdf',
    uploadedBy: 'Admin Manager',
    uploadedAt: new Date('2025-03-10T09:45:00'),
    fileSize: '890 KB',
  },
  {
    id: '4',
    name: 'Onboarding Checklist.pdf',
    uploadedBy: 'Admin Manager',
    uploadedAt: new Date('2025-04-05T11:00:00'),
    fileSize: '560 KB',
  },
  {
    id: '5',
    name: 'Code of Conduct.pdf',
    uploadedBy: 'Admin Manager',
    uploadedAt: new Date('2025-05-18T16:30:00'),
    fileSize: '1.8 MB',
  },
];
