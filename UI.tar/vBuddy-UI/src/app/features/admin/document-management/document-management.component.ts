import { Component, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { DocumentService } from '../../../core/services/document.service';
import { AuthService } from '../../../core/services/auth.service';
import { DocumentItem } from '../../../core/models/document.model';
import { UploadDialogComponent } from './upload-dialog/upload-dialog.component';
import { ConfirmDialogComponent } from './confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-document-management',
  standalone: true,
  imports: [DatePipe, UploadDialogComponent, ConfirmDialogComponent],
  templateUrl: './document-management.component.html',
  styleUrl: './document-management.component.scss',
})
export class DocumentManagementComponent {
  protected readonly showUploadDialog = signal(false);
  protected readonly showDeleteDialog = signal(false);
  protected readonly showUpdateDialog = signal(false);
  protected readonly selectedDocument = signal<DocumentItem | null>(null);

  constructor(
    protected readonly documentService: DocumentService,
    private readonly authService: AuthService,
  ) {}

  protected get documents() {
    return this.documentService.documents;
  }

  protected get totalCount() {
    return this.documentService.totalCount;
  }

  protected onUploadNew(): void {
    this.selectedDocument.set(null);
    this.showUploadDialog.set(true);
  }

  protected onUpdate(doc: DocumentItem): void {
    this.selectedDocument.set(doc);
    this.showUpdateDialog.set(true);
  }

  protected onDelete(doc: DocumentItem): void {
    this.selectedDocument.set(doc);
    this.showDeleteDialog.set(true);
  }

  protected onUploadConfirm(fileNames: string[]): void {
    const userName = this.authService.currentUser()?.name ?? 'Unknown';
    for (const fileName of fileNames) {
      this.documentService.addDocument(fileName, userName);
    }
    this.showUploadDialog.set(false);
  }

  protected onUpdateConfirm(fileNames: string[]): void {
    const doc = this.selectedDocument();
    if (doc && fileNames.length > 0) {
      this.documentService.updateDocument(doc.id, fileNames[0]);
    }
    this.showUpdateDialog.set(false);
    this.selectedDocument.set(null);
  }

  protected onDeleteConfirm(): void {
    const doc = this.selectedDocument();
    if (doc) {
      this.documentService.deleteDocument(doc.id);
    }
    this.showDeleteDialog.set(false);
    this.selectedDocument.set(null);
  }

  protected onDialogClose(): void {
    this.showUploadDialog.set(false);
    this.showDeleteDialog.set(false);
    this.showUpdateDialog.set(false);
    this.selectedDocument.set(null);
  }

  protected getDocIcon(name: string): string {
    return name.toLowerCase().endsWith('.md') ? 'article' : 'picture_as_pdf';
  }

  protected isMarkdown(name: string): boolean {
    return name.toLowerCase().endsWith('.md');
  }

  protected trackByDocId(_index: number, doc: DocumentItem): string {
    return doc.id;
  }
}
