import { Component, input, output, signal } from '@angular/core';

@Component({
  selector: 'app-upload-dialog',
  standalone: true,
  templateUrl: './upload-dialog.component.html',
  styleUrl: './upload-dialog.component.scss',
})
export class UploadDialogComponent {
  public readonly dialogTitle = input('Upload Document');
  public readonly existingFileName = input('');
  public readonly allowMultiple = input(false);

  public readonly confirm = output<string[]>();
  public readonly cancel = output<void>();

  protected readonly selectedFileNames = signal<string[]>([]);

  protected get isConfirmDisabled(): boolean {
    return this.selectedFileNames().length === 0 && !this.existingFileName();
  }

  protected onFileSelected(event: Event): void {
    const target = event.target as HTMLInputElement;
    const files = target.files;
    if (!files || files.length === 0) {
      return;
    }

    const newNames: string[] = [];
    for (let i = 0; i < files.length; i++) {
      newNames.push(files[i].name);
    }

    if (this.allowMultiple()) {
      const existing = this.selectedFileNames();
      const merged = [...existing];
      for (const name of newNames) {
        if (!merged.includes(name)) {
          merged.push(name);
        }
      }
      this.selectedFileNames.set(merged);
    } else {
      this.selectedFileNames.set([newNames[0]]);
    }

    target.value = '';
  }

  protected removeFile(index: number): void {
    this.selectedFileNames.update((names) =>
      names.filter((_, i) => i !== index),
    );
  }

  protected onConfirm(): void {
    const fileNames = this.selectedFileNames();
    if (fileNames.length > 0) {
      this.confirm.emit(fileNames);
    } else if (this.existingFileName()) {
      this.confirm.emit([this.existingFileName()]);
    }
  }

  protected onCancel(): void {
    this.cancel.emit();
  }

  protected onBackdropClick(event: MouseEvent): void {
    if ((event.target as HTMLElement).classList.contains('dialog-overlay')) {
      this.onCancel();
    }
  }
}
