import { Component, signal } from '@angular/core';
import { UserManagementService } from '../../../core/services/user-management.service';
import { ManagedUser, UserFormData } from '../../../core/models/managed-user.model';
import { UserFormDialogComponent } from './user-form-dialog/user-form-dialog.component';
import { ConfirmDialogComponent } from '../document-management/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-user-management',
  standalone: true,
  imports: [UserFormDialogComponent, ConfirmDialogComponent],
  templateUrl: './user-management.component.html',
  styleUrl: './user-management.component.scss',
})
export class UserManagementComponent {
  protected readonly showCreateDialog = signal(false);
  protected readonly showUpdateDialog = signal(false);
  protected readonly showDeleteDialog = signal(false);
  protected readonly selectedUser = signal<ManagedUser | null>(null);

  constructor(private readonly userManagementService: UserManagementService) {}

  protected get users() {
    return this.userManagementService.users;
  }

  protected get totalCount() {
    return this.userManagementService.totalCount;
  }

  protected onCreateNew(): void {
    this.selectedUser.set(null);
    this.showCreateDialog.set(true);
  }

  protected onUpdate(user: ManagedUser): void {
    this.selectedUser.set(user);
    this.showUpdateDialog.set(true);
  }

  protected onDelete(user: ManagedUser): void {
    this.selectedUser.set(user);
    this.showDeleteDialog.set(true);
  }

  protected onCreateConfirm(formData: UserFormData): void {
    this.userManagementService.addUser(
      formData.empId,
      formData.name,
      formData.email,
      formData.role,
    );
    this.showCreateDialog.set(false);
  }

  protected onUpdateConfirm(formData: UserFormData): void {
    const user = this.selectedUser();
    if (user) {
      this.userManagementService.updateUser(
        user.id,
        formData.name,
        formData.email,
        formData.role,
      );
    }
    this.showUpdateDialog.set(false);
    this.selectedUser.set(null);
  }

  protected onDeleteConfirm(): void {
    const user = this.selectedUser();
    if (user) {
      this.userManagementService.deleteUser(user.id);
    }
    this.showDeleteDialog.set(false);
    this.selectedUser.set(null);
  }

  protected onDialogClose(): void {
    this.showCreateDialog.set(false);
    this.showUpdateDialog.set(false);
    this.showDeleteDialog.set(false);
    this.selectedUser.set(null);
  }
}
