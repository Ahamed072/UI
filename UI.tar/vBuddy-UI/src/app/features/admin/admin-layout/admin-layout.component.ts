import { Component, signal } from '@angular/core';
import { RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { APP_CONSTANTS, ADMIN_NAV_ITEMS } from '../../../core/constants/app.constants';
import { ConfirmDialogComponent } from '../document-management/confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-admin-layout',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive, ConfirmDialogComponent],
  templateUrl: './admin-layout.component.html',
  styleUrl: './admin-layout.component.scss',
})
export class AdminLayoutComponent {
  protected readonly appName = APP_CONSTANTS.appName;
  protected readonly navItems = ADMIN_NAV_ITEMS;
  protected readonly showLogoutDialog = signal(false);

  constructor(private readonly authService: AuthService) {}

  protected get currentUser() {
    return this.authService.currentUser;
  }

  protected onLogout(): void {
    this.showLogoutDialog.set(true);
  }

  protected onLogoutConfirm(): void {
    this.showLogoutDialog.set(false);
    this.authService.logout();
  }

  protected onLogoutCancel(): void {
    this.showLogoutDialog.set(false);
  }
}
