import { Component, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from '../../core/services/auth.service';
import { APP_CONSTANTS } from '../../core/constants/app.constants';

@Component({
  selector: 'app-login-page',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './login-page.component.html',
  styleUrl: './login-page.component.scss',
})
export class LoginPageComponent {
  protected readonly appName = APP_CONSTANTS.appName;
  protected readonly appTagline = APP_CONSTANTS.appTagline;

  protected readonly email = signal('');
  protected readonly password = signal('');
  protected readonly errorMessage = signal('');
  protected readonly isLoading = signal(false);

  constructor(
    private readonly authService: AuthService,
    private readonly router: Router,
  ) {}

  protected onSubmit(): void {
    this.errorMessage.set('');

    if (!this.email().trim() || !this.password().trim()) {
      this.errorMessage.set('Please enter both email and password.');
      return;
    }

    this.isLoading.set(true);

    const success = this.authService.login(this.email(), this.password());

    if (success) {
      const targetRoute = this.authService.isAdmin() ? '/admin' : '/chat';
      void this.router.navigate([targetRoute]);
    } else {
      this.errorMessage.set('Invalid credentials. Please try again.');
      this.isLoading.set(false);
    }
  }
}
