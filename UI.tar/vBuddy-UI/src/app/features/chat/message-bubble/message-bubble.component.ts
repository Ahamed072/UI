import { Component, computed, input } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ChatMessage } from '../../../core/models/message.model';

@Component({
  selector: 'app-message-bubble',
  standalone: true,
  imports: [DatePipe],
  templateUrl: './message-bubble.component.html',
  styleUrl: './message-bubble.component.scss',
})
export class MessageBubbleComponent {
  public readonly message = input.required<ChatMessage>();

  protected readonly isUser = computed(() => this.message().sender === 'user');
  protected readonly isBot = computed(() => this.message().sender === 'bot');
}
