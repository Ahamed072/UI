CREATE DATABASE IF NOT EXISTS `vbuddy_db` 
  DEFAULT CHARACTER SET utf8mb4 
  COLLATE utf8mb4_0900_ai_ci;
USE `vbuddy_db`;

--Table Document_Store 
CREATE TABLE Document_Store ( 
    file_id BIGINT AUTO_INCREMENT PRIMARY KEY, 
file_name VARCHAR(255) NOT NULL, description TEXT NULL, 
file_type VARCHAR(50) NOT NULL, uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
uploaded_by VARCHAR(100) NULL, is_deleted TINYINT(1) DEFAULT 0, 
deleted_at TIMESTAMP NULL, deleted_by VARCHAR(100) NULL);

CREATE TABLE `users` (
  `EMP_ID` varchar(255) NOT NULL,
  `NAME` varchar(255) NOT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `ROLE` enum('admin','user') NOT NULL,
  `IS_ACTIVE` tinyint(1) DEFAULT '1',
  `createdAt` datetime DEFAULT NULL,
  `updatedAt` datetime DEFAULT NULL,
  PRIMARY KEY (`EMP_ID`),
  UNIQUE KEY `EMAIL` (`EMAIL`)
);


CREATE TABLE Chat_Sessions (
    session_id VARCHAR(255) NOT NULL,
    emp_id VARCHAR(255) NOT NULL,
    conversation JSON NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    is_deleted TINYINT(1) DEFAULT 0,
    deleted_at TIMESTAMP NULL,
    PRIMARY KEY (session_id),

    CONSTRAINT fk_chat_session_user
        FOREIGN KEY (emp_id) REFERENCES users(emp_id)
        ON DELETE CASCADE ON UPDATE CASCADE,

    -- Indexes
    INDEX idx_emp_id (emp_id),
    INDEX idx_emp_active (emp_id, is_deleted)
);


CREATE TABLE `Sessions` (
  `SESSION_ID` varchar(255) NOT NULL,
  `EMP_ID` varchar(255) NOT NULL,
  `expiresAt` datetime DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL,
  `JWT_TOKEN` varchar(512) DEFAULT NULL,
  `is_deleted` boolean,
  PRIMARY KEY (`SESSION_ID`),
  KEY `EMP_ID` (`EMP_ID`),
  CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`EMP_ID`) 
    REFERENCES `users` (`EMP_ID`)
);
