import hashlib
import json
import os
from typing import Dict, List, Tuple

import requests

from .config import CONTENT_HASHES_PATH, BASELINES_DIR, REQUEST_TIMEOUT


def load_hashes() -> Dict[str, str]:
    """Load stored content hashes. Returns empty dict if no file exists."""
    if not os.path.exists(CONTENT_HASHES_PATH):
        return {}
    with open(CONTENT_HASHES_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def save_hashes(hashes: Dict[str, str]):
    """Save content hashes to JSON file."""
    os.makedirs(BASELINES_DIR, exist_ok=True)
    with open(CONTENT_HASHES_PATH, "w", encoding="utf-8") as f:
        json.dump(hashes, f, indent=2)


def fetch_url_hash(url: str) -> str:
    """Fetch URL with requests and return MD5 hash of response body."""
    response = requests.get(url, timeout=REQUEST_TIMEOUT)
    response.raise_for_status()
    return hashlib.md5(response.content).hexdigest()


def check_changed_urls(urls: List[str]) -> Tuple[List[str], Dict[str, str]]:
    """
    Check which URLs have changed content since last run.

    Returns:
        changed_urls: URLs that are new or have different hash (need re-crawl + LLM clean)
        new_hashes: {url: hash} for ALL urls (to save after processing)
    """
    stored_hashes = load_hashes()
    changed_urls = []
    new_hashes = {}

    for url in urls:
        try:
            current_hash = fetch_url_hash(url)
            new_hashes[url] = current_hash

            stored_hash = stored_hashes.get(url)
            if stored_hash != current_hash:
                changed_urls.append(url)
                if stored_hash is None:
                    print(f"[Hash] NEW: {url}")
                else:
                    print(f"[Hash] CHANGED: {url}")
            else:
                print(f"[Hash] Unchanged: {url}")
        except Exception as e:
            print(f"[Hash] Error fetching {url}: {e}")
            # Keep old hash if fetch fails, don't mark as changed
            if url in stored_hashes:
                new_hashes[url] = stored_hashes[url]

    print(
        f"[Hash] Result: {len(changed_urls)} changed, "
        f"{len(urls) - len(changed_urls)} unchanged out of {len(urls)} URLs"
    )
    return changed_urls, new_hashes
