import os
import json
from typing import Optional
from datetime import datetime, timezone

from .models import BaselineData
from .config import BASELINES_DIR


def _baseline_path(site_key: str) -> str:
    return os.path.join(BASELINES_DIR, f"{site_key}.json")


def load_baseline(site_key: str) -> Optional[BaselineData]:
    path = _baseline_path(site_key)
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return BaselineData(**data)


def save_baseline(site_key: str, site_label: str, urls: list[str]) -> BaselineData:
    os.makedirs(BASELINES_DIR, exist_ok=True)

    baseline = BaselineData(
        site=site_label,
        fetched_at=datetime.now(timezone.utc).isoformat(),
        urls=urls,
    )

    path = _baseline_path(site_key)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(baseline.model_dump(), f, indent=2)

    return baseline
