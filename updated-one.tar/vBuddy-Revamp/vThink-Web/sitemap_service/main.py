import asyncio
from datetime import datetime, timezone

from fastapi import FastAPI, HTTPException

from .models import SiteKey, SiteDiffResult, ComparisonResponse, ChatRequest, ChatResponse
from .sitemap_parser import fetch_sitemap_urls, filter_urls
from .baseline_store import load_baseline, save_baseline
from .comparator import compare_url_lists
from .crawler import crawl_urls_parallel
from .llm_cleaner import clean_content
from .vector_store import get_collection, store_single_document
from .rag import rag_pipeline, bm25_index
from .content_hash import check_changed_urls, load_hashes, save_hashes
from .config import SITES

app = FastAPI(
    title="vThink Sitemap Comparison Service",
    description="Compares sitemaps, crawls pages, cleans content via LLM, and stores in ChromaDB.",
    version="2.0.0",
)


def _process_site(site_key: str) -> SiteDiffResult:
    site_config = SITES[site_key]

    raw_urls = fetch_sitemap_urls(site_config["sitemap_url"])
    current_urls = filter_urls(raw_urls, site_config["filter_patterns"])

    baseline = load_baseline(site_key)

    if baseline is None:
        save_baseline(site_key, site_config["label"], current_urls)
        return SiteDiffResult(
            site_label=site_config["label"],
            is_first_run=True,
            baseline_timestamp=None,
            current_url_count=len(current_urls),
            baseline_url_count=None,
            added_urls=[],
            removed_urls=[],
            has_changes=False,
        )

    added, removed = compare_url_lists(baseline.urls, current_urls)

    result = SiteDiffResult(
        site_label=site_config["label"],
        is_first_run=False,
        baseline_timestamp=baseline.fetched_at,
        current_url_count=len(current_urls),
        baseline_url_count=len(baseline.urls),
        added_urls=added,
        removed_urls=removed,
        has_changes=len(added) > 0 or len(removed) > 0,
    )

    save_baseline(site_key, site_config["label"], current_urls)

    return result


async def _crawl_and_store(site_key: str, site_label: str) -> dict:
    """Crawl changed baseline URLs for a site, clean via LLM, store in ChromaDB per URL."""
    baseline = load_baseline(site_key)
    if baseline is None or not baseline.urls:
        return {"site": site_label, "crawled": 0, "cleaned": 0, "stored": 0, "skipped": 0}

    urls = baseline.urls

    # Step 1: Check which URLs have changed content via lightweight hash check
    print(f"\n[Pipeline] Checking content hashes for {len(urls)} URLs ({site_label})...")
    changed_urls, new_hashes = check_changed_urls(urls)
    skipped = len(urls) - len(changed_urls)

    if not changed_urls:
        print(f"[Pipeline] No content changes detected for {site_label}. Skipping crawl + LLM.")
        all_hashes = load_hashes()
        all_hashes.update(new_hashes)
        save_hashes(all_hashes)
        return {"site": site_label, "crawled": 0, "cleaned": 0, "stored": 0, "skipped": skipped}

    # Step 2: Crawl ONLY changed URLs in parallel
    print(f"[Pipeline] Crawling {len(changed_urls)} changed URLs for {site_label} (skipping {skipped})...")
    crawled = await crawl_urls_parallel(changed_urls)

    # Step 3: Clean each changed URL via LLM and store in ChromaDB immediately
    collection = get_collection()
    cleaned_count = 0
    stored_count = 0

    for i, (url, raw_content) in enumerate(crawled.items(), 1):
        try:
            print(f"[Pipeline] ({i}/{len(crawled)}) Cleaning: {url}")
            cleaned_text = clean_content(url, raw_content)
            if cleaned_text and cleaned_text.strip():
                cleaned_count += 1
                store_single_document(collection, url, cleaned_text, site_label)
                stored_count += 1
            else:
                print(f"[Pipeline] Empty LLM result for {url}")
        except Exception as e:
            print(f"[Pipeline] Error processing {url}: {e}")

    # Step 4: Merge with existing hashes and save
    all_hashes = load_hashes()
    all_hashes.update(new_hashes)
    save_hashes(all_hashes)

    print(f"[Pipeline] Done {site_label}: crawled={len(crawled)}, cleaned={cleaned_count}, stored={stored_count}, skipped={skipped}")

    # Invalidate BM25 cache so next query rebuilds with new docs
    if stored_count > 0:
        bm25_index.rebuild()

    return {
        "site": site_label,
        "crawled": len(crawled),
        "cleaned": cleaned_count,
        "stored": stored_count,
        "skipped": skipped,
    }


@app.get("/compare")
async def compare_all_sitemaps():
    # Phase 1: Sitemap comparison
    comparison_results = []
    errors = []

    for site_key in SITES:
        try:
            result = _process_site(site_key)
            comparison_results.append(result)
        except Exception as e:
            errors.append(
                {
                    "site_key": site_key,
                    "site_label": SITES[site_key]["label"],
                    "error": str(e),
                }
            )

    # Phase 2: Crawl + LLM clean + store in ChromaDB for all sites
    knowledge_results = []
    for site_key, site_config in SITES.items():
        try:
            kb_result = await _crawl_and_store(site_key, site_config["label"])
            knowledge_results.append(kb_result)
        except Exception as e:
            knowledge_results.append(
                {
                    "site": site_config["label"],
                    "error": str(e),
                    "crawled": 0,
                    "cleaned": 0,
                    "stored": 0,
                }
            )

    return {
        "compared_at": datetime.now(timezone.utc).isoformat(),
        "comparison": {
            "results": [r.model_dump() for r in comparison_results],
            "error_sites": errors,
        },
        "knowledge_base": knowledge_results,
    }


@app.get("/compare/{site_key}")
async def compare_single_sitemap(site_key: SiteKey):
    try:
        result = _process_site(site_key.value)
    except Exception as e:
        raise HTTPException(status_code=502, detail=f"Failed to fetch sitemap: {e}")

    try:
        kb_result = await _crawl_and_store(
            site_key.value, SITES[site_key.value]["label"]
        )
    except Exception as e:
        kb_result = {
            "site": SITES[site_key.value]["label"],
            "error": str(e),
            "crawled": 0,
            "cleaned": 0,
            "stored": 0,
        }

    return {
        "compared_at": datetime.now(timezone.utc).isoformat(),
        "comparison": {
            "results": [result.model_dump()],
            "error_sites": [],
        },
        "knowledge_base": [kb_result],
    }


@app.get("/baseline/{site_key}")
def get_baseline(site_key: SiteKey):
    baseline = load_baseline(site_key.value)
    if baseline is None:
        raise HTTPException(
            status_code=404,
            detail=f"No baseline exists for {site_key.value}. Run /compare first.",
        )
    return baseline.model_dump()


@app.post("/chat", response_model=ChatResponse)
def chat(request: ChatRequest):
    chat_history = [msg.model_dump() for msg in request.chat_history]

    result = rag_pipeline(
        query=request.query,
        chat_history=chat_history,
        top_k=request.top_k,
    )

    return ChatResponse(**result)
