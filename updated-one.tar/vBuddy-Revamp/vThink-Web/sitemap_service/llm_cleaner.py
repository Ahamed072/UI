from typing import Dict

from openai import OpenAI
from dotenv import load_dotenv

from .config import OPENAI_MODEL

load_dotenv()

SYSTEM_PROMPT = """You are a content extraction assistant. Given raw scraped markdown from a webpage,
extract ONLY the meaningful main content. Remove:
- Navigation menus, headers, footers
- Sidebar links, breadcrumbs
- Cookie notices, popups
- Repeated boilerplate text
- Social media links/buttons
- Any HTML artifacts or formatting noise

Return ONLY the clean, meaningful text content of the page. Preserve the logical structure
(headings, paragraphs, lists) but remove all non-content elements. If the page has very little
meaningful content, return whatever is available."""


def clean_content(url: str, raw_content: str) -> str:
    """Use OpenAI to clean raw scraped content, extracting only meaningful text."""
    client = OpenAI()

    # Truncate very long content to stay within token limits
    max_chars = 15000
    truncated = raw_content[:max_chars] if len(raw_content) > max_chars else raw_content

    response = client.chat.completions.create(
        model=OPENAI_MODEL,
        messages=[
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "user",
                "content": f"URL: {url}\n\nRaw scraped content:\n{truncated}",
            },
        ],
        temperature=0,
    )

    return response.choices[0].message.content


def clean_all_content(crawled_data: Dict[str, str]) -> Dict[str, str]:
    """Clean all crawled content through the LLM. Returns {url: cleaned_content}."""
    cleaned = {}

    for i, (url, raw_content) in enumerate(crawled_data.items(), 1):
        try:
            print(f"[LLM] Cleaning {i}/{len(crawled_data)}: {url}")
            cleaned_text = clean_content(url, raw_content)
            if cleaned_text and cleaned_text.strip():
                cleaned[url] = cleaned_text
            else:
                print(f"[LLM] Empty result for {url}")
        except Exception as e:
            print(f"[LLM] Error cleaning {url}: {e}")

    print(f"[LLM] Total: {len(cleaned)}/{len(crawled_data)} pages cleaned")
    return cleaned
