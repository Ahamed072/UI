export interface SessionData {
  readonly empId: string;
  readonly token: string;
  readonly sessionId: string;
  readonly userName: string;
  readonly email: string;
  readonly role: 'user' | 'admin';
}
