export interface DocumentItem {
  readonly id: number;
  readonly name: string;
  readonly description: string | null;
  readonly uploadedBy: string;
  readonly uploadedById: string | null;
  readonly uploadedAt: Date;
}
