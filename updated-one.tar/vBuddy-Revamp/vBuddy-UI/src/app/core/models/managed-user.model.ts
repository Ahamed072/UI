import { UserRole } from './user.model';

export interface ManagedUser {
  readonly empId: string;
  readonly name: string;
  readonly email: string;
  readonly role: UserRole;
  readonly isActive: boolean;
}

export interface UserFormData {
  readonly empId: string;
  readonly name: string;
  readonly email: string;
  readonly role: UserRole;
}
