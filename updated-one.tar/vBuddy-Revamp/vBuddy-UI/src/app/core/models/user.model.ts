export type UserRole = 'user' | 'admin';

export interface AppUser {
  readonly empId: string;
  readonly name: string;
  readonly email: string;
  readonly role: UserRole;
}
