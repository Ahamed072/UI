import { ChatSource, WebSource } from './api-response.model';

export type MessageSender = 'user' | 'bot';

export interface ChatMessage {
  readonly id: string;
  readonly content: string;
  readonly sender: MessageSender;
  readonly timestamp: Date;
  readonly isWebSearch: boolean;
  readonly sources?: ReadonlyArray<ChatSource>;
  readonly webSources?: ReadonlyArray<WebSource>;
}
