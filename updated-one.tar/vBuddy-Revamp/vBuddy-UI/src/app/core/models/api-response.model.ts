import { UserRole } from './user.model';

// POST /api/auth/login response
export interface LoginApiResponse {
  readonly token: string;
  readonly role: UserRole;
  readonly EMP_ID: string;
  readonly NAME: string;
  readonly session_id: string;
  readonly redirect: string;
}

// POST /chat request
export interface ChatApiRequest {
  readonly emp_id: string;
  readonly session_id: string;
  readonly question: string;
  readonly model: string;
  readonly user_name: string;
  readonly is_web_search: boolean;
}

// POST /chat response
export interface ChatApiResponse {
  readonly answer: string;
  readonly session_id: string;
  readonly model: string;
  readonly sources: ReadonlyArray<ChatSource> | null;
  readonly web_sources: ReadonlyArray<WebSource> | null;
  readonly used_document_context: boolean;
  readonly is_web_search: boolean;
}

export interface ChatSource {
  readonly file_name: string;
  readonly file_id: number | string | null;
}

export interface WebSource {
  readonly url: string | null;
  readonly site: string | null;
}

// GET /get-conversation/{sessionId} response
export interface ConversationApiResponse {
  readonly conversation: ReadonlyArray<ConversationMessage>;
}

export interface ConversationMessage {
  readonly role: 'human' | 'ai';
  readonly content: string;
  readonly sources?: ReadonlyArray<ChatSource>;
}

// GET /list-docs response item
export interface DocumentApiItem {
  readonly FILE_ID: number;
  readonly FILE_NAME: string;
  readonly DESCRIPTION: string | null;
  readonly UPLOADED_AT: string;
  readonly UPLOADED_BY: string | null;
  readonly UPLOADED_BY_NAME: string;
}

// POST /upload-doc response
export interface UploadDocApiResponse {
  readonly message: string;
  readonly file_id: number;
}

// POST /update-doc response
export interface UpdateDocApiResponse {
  readonly message: string;
  readonly file_id: number;
  readonly new_file_name: string;
}

// POST /delete-doc request
export interface DeleteDocApiRequest {
  readonly file_id: number;
}

// GET /api/users/list response item
export interface UserApiItem {
  readonly EMP_ID: string;
  readonly NAME: string;
  readonly EMAIL: string;
  readonly ROLE: UserRole;
  readonly IS_ACTIVE: number;
}

// GET /api/users/list paginated response
export interface PaginatedUsersApiResponse {
  readonly users: ReadonlyArray<UserApiItem>;
  readonly total: number;
  readonly page: number;
  readonly page_size: number;
  readonly total_pages: number;
}

// POST /api/users/add request
export interface AddUserApiRequest {
  readonly emp_id: string;
  readonly name: string;
  readonly email: string;
  readonly role: UserRole;
}

// PUT /api/users/edit/{empId} request
export interface EditUserApiRequest {
  readonly NAME: string;
  readonly EMAIL: string;
  readonly ROLE: UserRole;
}

// Generic API message response
export interface ApiMessageResponse {
  readonly message: string;
}
