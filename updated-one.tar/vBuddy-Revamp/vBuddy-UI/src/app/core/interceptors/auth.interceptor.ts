import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { AuthService } from '../services/auth.service';
import { NotificationService } from '../services/notification.service';
import { API_CONFIG } from '../constants/app.constants';

const SESSION_EXPIRY_REDIRECT_DELAY_MS = 2000;

export const authInterceptor: HttpInterceptorFn = (req, next) => {
  const authService = inject(AuthService);
  const notificationService = inject(NotificationService);

  const isApiRequest = req.url.startsWith(API_CONFIG.baseUrl);
  const isLoginRequest = req.url.includes(API_CONFIG.endpoints.login);

  let clonedReq = req;
  if (isApiRequest && !isLoginRequest) {
    const token = authService.getToken();
    if (token) {
      clonedReq = req.clone({
        setHeaders: {
          Authorization: `Bearer ${token}`,
        },
      });
    }
  }

  return next(clonedReq).pipe(
    catchError((error: HttpErrorResponse) => {
      if (isApiRequest && (error.status === 401 || error.status === 403)) {
        notificationService.showError('Your session has expired. Redirecting to login...');
        setTimeout(() => {
          authService.forceLogout();
        }, SESSION_EXPIRY_REDIRECT_DELAY_MS);
      }
      return throwError(() => error);
    }),
  );
};
