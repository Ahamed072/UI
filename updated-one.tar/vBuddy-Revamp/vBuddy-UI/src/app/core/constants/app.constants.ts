export const APP_CONSTANTS = {
  appName: 'vBuddy',
  companyName: 'vThink Global Technologies',
  companyShortName: 'vThink',
  companyLogoPath: 'vthink-logo.png',
  appTagline: 'Your Intelligent Company Assistant',
  typingDelayMs: 1500,
  defaultGreeting:
    "Hello! I'm vBuddy, your intelligent assistant by vThink Global Technologies. How can I help you today?",
  fallbackResponse:
    'I appreciate your question. Let me look into that for you. For more specific information, please reach out to the relevant department or try rephrasing your query.',
  webSearchPrefix: '[Web Search] ',
  maxMessageLength: 2000,
  policyDocumentsUrl: 'https://vthinktechnologies.greythr.com/v3/portal/ess/documents-view/company-policies',
} as const;

export const SUGGESTION_CHIPS = [
  {
    label: 'Company Policies',
    query: 'What are the company policies regarding leave and work from home?',
    icon: 'policy',
  },
  {
    label: 'Internal Apps',
    query: 'What internal applications are available for employees?',
    icon: 'apps',
  },
  {
    label: 'General Info',
    query: 'show me the vThink clients',
    icon: 'info',
  },
] as const;

export const ADMIN_NAV_ITEMS = [
  { label: 'Document Management', icon: 'description', route: 'documents' },
  { label: 'User Management', icon: 'people', route: 'users' },
  { label: 'Chat Interface', icon: 'chat', route: 'chat' },
] as const;

export const API_CONFIG = {
  baseUrl: 'http://localhost:8000',
  endpoints: {
    login: '/api/auth/login',
    logout: '/api/auth/logout',
    chat: '/chat',
    getConversation: '/get-conversation',
    endSession: '/end-session',
    listDocs: '/list-docs',
    uploadDoc: '/upload-doc',
    updateDoc: '/update-doc',
    deleteDoc: '/delete-doc',
    listUsers: '/api/users/list',
    addUser: '/api/users/add',
    editUser: '/api/users/edit',
    deleteUser: '/api/users/delete',
    syncWeb: '/sync-web',
  },
} as const;

export const MSAL_CONFIG = {
  clientId: '264d0ea6-fba2-4d90-aa74-bceeee062c44',
  authority: 'https://login.microsoftonline.com/3bc90aa9-088f-4447-9eb2-ff13839e19dd',
  redirectUri: 'http://localhost:4200',
} as const;

export const SESSION_STORAGE_KEY = 'vbuddy_session_data' as const;

export const CHAT_MODEL = 'gpt-4o-mini' as const;

export const ALLOWED_EMAIL_DOMAIN = '@vthink.co.in' as const;

export const ALLOWED_FILE_EXTENSIONS = ['.pdf', '.docx', '.md'] as const;
