import { inject, Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ManagedUser } from '../models/managed-user.model';
import { UserRole } from '../models/user.model';
import {
  UserApiItem,
  PaginatedUsersApiResponse,
  AddUserApiRequest,
  EditUserApiRequest,
  ApiMessageResponse,
} from '../models/api-response.model';
import { API_CONFIG } from '../constants/app.constants';
import { NotificationService } from './notification.service';

@Injectable({ providedIn: 'root' })
export class UserManagementService {
  private readonly usersSignal = signal<ManagedUser[]>([]);
  private readonly isLoadingSignal = signal(false);
  private readonly totalCountSignal = signal(0);
  private readonly currentPageSignal = signal(1);
  private readonly totalPagesSignal = signal(0);
  private readonly pageSize = 10;

  public readonly users = this.usersSignal.asReadonly();
  public readonly totalCount = this.totalCountSignal.asReadonly();
  public readonly isLoading = this.isLoadingSignal.asReadonly();
  public readonly currentPage = this.currentPageSignal.asReadonly();
  public readonly totalPages = this.totalPagesSignal.asReadonly();

  private readonly http = inject(HttpClient);
  private readonly notificationService = inject(NotificationService);

  public loadUsers(page: number = 1): void {
    this.isLoadingSignal.set(true);
    this.currentPageSignal.set(page);
    const url = `${API_CONFIG.baseUrl}${API_CONFIG.endpoints.listUsers}?page=${page}&page_size=${this.pageSize}`;

    this.http.get<PaginatedUsersApiResponse>(url).subscribe({
      next: (response) => {
        const mapped = response.users.map((item) => this.mapApiToManagedUser(item));
        this.usersSignal.set(mapped);
        this.totalCountSignal.set(response.total);
        this.totalPagesSignal.set(response.total_pages);
        this.isLoadingSignal.set(false);
      },
      error: () => {
        this.notificationService.showError('Error fetching users. Please try again.');
        this.isLoadingSignal.set(false);
      },
    });
  }

  public addUser(empId: string, name: string, email: string, role: UserRole): void {
    const url = `${API_CONFIG.baseUrl}${API_CONFIG.endpoints.addUser}`;
    const body: AddUserApiRequest = { emp_id: empId, name, email, role };

    this.http.post(url, body).subscribe({
      next: () => {
        this.notificationService.showSuccess('User added successfully!');
        this.loadUsers(this.currentPageSignal());
      },
      error: () => {
        this.notificationService.showError('Error adding user. Please try again.');
      },
    });
  }

  public updateUser(empId: string, name: string, email: string, role: UserRole): void {
    const url = `${API_CONFIG.baseUrl}${API_CONFIG.endpoints.editUser}/${empId}`;
    const body: EditUserApiRequest = { NAME: name, EMAIL: email, ROLE: role };

    this.http.put(url, body).subscribe({
      next: () => {
        this.notificationService.showSuccess('User updated successfully!');
        this.loadUsers(this.currentPageSignal());
      },
      error: () => {
        this.notificationService.showError('Error updating user. Please try again.');
      },
    });
  }

  public deleteUser(empId: string): void {
    const url = `${API_CONFIG.baseUrl}${API_CONFIG.endpoints.deleteUser}/${empId}`;

    this.http.delete<ApiMessageResponse>(url).subscribe({
      next: () => {
        this.notificationService.showSuccess('User deleted successfully!');
        this.loadUsers(this.currentPageSignal());
      },
      error: () => {
        this.notificationService.showError('Error deleting user. Please try again.');
      },
    });
  }

  private mapApiToManagedUser(item: UserApiItem): ManagedUser {
    return {
      empId: item.EMP_ID,
      name: item.NAME,
      email: item.EMAIL,
      role: item.ROLE,
      isActive: Boolean(item.IS_ACTIVE),
    };
  }
}
