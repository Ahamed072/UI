import { Injectable, signal } from '@angular/core';

export type ToastType = 'success' | 'error' | 'warning' | 'info';

export interface ToastMessage {
  readonly id: string;
  readonly message: string;
  readonly type: ToastType;
}

const TOAST_DURATION_MS = 4000;

@Injectable({ providedIn: 'root' })
export class NotificationService {
  private readonly toastsSignal = signal<ToastMessage[]>([]);

  public readonly toasts = this.toastsSignal.asReadonly();

  public showSuccess(message: string): void {
    this.addToast(message, 'success');
  }

  public showError(message: string): void {
    this.addToast(message, 'error');
  }

  public showWarning(message: string): void {
    this.addToast(message, 'warning');
  }

  public showInfo(message: string): void {
    this.addToast(message, 'info');
  }

  public dismissToast(id: string): void {
    this.toastsSignal.update((toasts) => toasts.filter((t) => t.id !== id));
  }

  private addToast(message: string, type: ToastType): void {
    const id = crypto.randomUUID();
    const toast: ToastMessage = { id, message, type };
    this.toastsSignal.update((toasts) => [...toasts, toast]);

    setTimeout(() => {
      this.dismissToast(id);
    }, TOAST_DURATION_MS);
  }
}
