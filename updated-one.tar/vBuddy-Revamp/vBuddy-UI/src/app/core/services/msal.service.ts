import { Injectable } from '@angular/core';
import {
  PublicClientApplication,
  AuthenticationResult,
  RedirectRequest,
} from '@azure/msal-browser';
import { MSAL_CONFIG } from '../constants/app.constants';

@Injectable({ providedIn: 'root' })
export class MsalWrapperService {
  private readonly msalInstance: PublicClientApplication;
  private initialized = false;
  private redirectPromise: Promise<AuthenticationResult | null> | null = null;

  constructor() {
    this.msalInstance = new PublicClientApplication({
      auth: {
        clientId: MSAL_CONFIG.clientId,
        authority: MSAL_CONFIG.authority,
        redirectUri: MSAL_CONFIG.redirectUri,
      },
      cache: {
        cacheLocation: 'sessionStorage',
      },
    });
  }

  public async initialize(): Promise<void> {
    if (!this.initialized) {
      await this.msalInstance.initialize();
      this.initialized = true;
    }
  }

  public async handleRedirectPromise(): Promise<AuthenticationResult | null> {
    await this.initialize();
    if (!this.redirectPromise) {
      this.redirectPromise = this.msalInstance.handleRedirectPromise();
    }
    return this.redirectPromise;
  }

  public async loginRedirect(): Promise<void> {
    await this.initialize();
    if (this.redirectPromise) {
      await this.redirectPromise;
    }
    const loginRequest: RedirectRequest = {
      scopes: ['openid', 'profile', 'email', 'User.Read'],
    };
    await this.msalInstance.loginRedirect(loginRequest);
  }

  public async logoutRedirect(): Promise<void> {
    await this.initialize();
    await this.msalInstance.logoutRedirect({
      postLogoutRedirectUri: MSAL_CONFIG.redirectUri,
    });
  }
}
