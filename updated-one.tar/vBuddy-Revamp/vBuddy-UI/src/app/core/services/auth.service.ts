import { computed, inject, Injectable, signal } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { Observable, tap, catchError, of, finalize } from 'rxjs';
import { AppUser, UserRole } from '../models/user.model';
import { SessionData } from '../models/session.model';
import { LoginApiResponse } from '../models/api-response.model';
import { API_CONFIG, SESSION_STORAGE_KEY } from '../constants/app.constants';
import { MsalWrapperService } from './msal.service';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly currentUserSignal = signal<AppUser | null>(null);
  private readonly sessionSignal = signal<SessionData | null>(null);

  public readonly currentUser = this.currentUserSignal.asReadonly();
  public readonly isAuthenticated = computed(() => this.currentUserSignal() !== null);
  public readonly userRole = computed<UserRole | null>(
    () => this.currentUserSignal()?.role ?? null,
  );
  public readonly isAdmin = computed(() => this.userRole() === 'admin');
  public readonly session = this.sessionSignal.asReadonly();

  private readonly http = inject(HttpClient);
  private readonly router = inject(Router);
  private readonly msalService = inject(MsalWrapperService);

  constructor() {
    this.restoreSession();
  }

  public getToken(): string | null {
    return this.sessionSignal()?.token ?? null;
  }

  public getSessionId(): string | null {
    return this.sessionSignal()?.sessionId ?? null;
  }

  public getEmpId(): string | null {
    return this.sessionSignal()?.empId ?? null;
  }

  public getUserName(): string | null {
    return this.sessionSignal()?.userName ?? null;
  }

  public async loginWithMsal(): Promise<void> {
    await this.msalService.loginRedirect();
  }

  public async handleMsalRedirect(): Promise<void> {
    const result = await this.msalService.handleRedirectPromise();
    if (result?.account) {
      const email = result.account.username;
      this.loginWithEmail(email).subscribe({
        next: (response) => {
          const targetRoute = response.role === 'admin' ? '/admin' : '/chat';
          void this.router.navigate([targetRoute]);
        },
      });
    }
  }

  public loginWithEmail(email: string): Observable<LoginApiResponse> {
    const url = `${API_CONFIG.baseUrl}${API_CONFIG.endpoints.login}`;
    return this.http.post<LoginApiResponse>(url, { email }).pipe(
      tap((response) => {
        const session: SessionData = {
          empId: response.EMP_ID,
          token: response.token,
          sessionId: response.session_id,
          userName: response.NAME,
          email,
          role: response.role,
        };
        this.persistSession(session);
      }),
    );
  }

  public logout(): void {
    const sessionId = this.getSessionId();
    const url = `${API_CONFIG.baseUrl}${API_CONFIG.endpoints.logout}`;

    if (sessionId) {
      this.http
        .post(url, { session_id: sessionId })
        .pipe(
          catchError(() => of(null)),
          finalize(() => {
            this.clearSession();
            void this.msalService.logoutRedirect();
          }),
        )
        .subscribe();
    } else {
      this.clearSession();
      void this.msalService.logoutRedirect();
    }
  }

  public startNewSession(): void {
    const currentSession = this.sessionSignal();
    if (currentSession) {
      const newSession: SessionData = {
        ...currentSession,
        sessionId: crypto.randomUUID(),
      };
      this.persistSession(newSession);
    }
  }

  public forceLogout(): void {
    this.clearSession();
    void this.router.navigate(['/login']);
  }

  private restoreSession(): void {
    try {
      const stored = localStorage.getItem(SESSION_STORAGE_KEY);
      if (stored) {
        const session: SessionData = JSON.parse(stored);
        if (session.token && session.empId) {
          this.sessionSignal.set(session);
          this.currentUserSignal.set({
            empId: session.empId,
            name: session.userName,
            email: session.email,
            role: session.role,
          });
        }
      }
    } catch {
      this.clearSession();
    }
  }

  private persistSession(session: SessionData): void {
    try {
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
    } catch {
      // localStorage may be unavailable
    }
    this.sessionSignal.set(session);
    this.currentUserSignal.set({
      empId: session.empId,
      name: session.userName,
      email: '',
      role: session.role,
    });
  }

  private clearSession(): void {
    try {
      localStorage.removeItem(SESSION_STORAGE_KEY);
    } catch {
      // silent fail
    }
    this.sessionSignal.set(null);
    this.currentUserSignal.set(null);
  }
}
