import { computed, inject, Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { forkJoin, Observable, of } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { DocumentItem } from '../models/document.model';
import {
  DocumentApiItem,
  UploadDocApiResponse,
  UpdateDocApiResponse,
  ApiMessageResponse,
} from '../models/api-response.model';
import { API_CONFIG } from '../constants/app.constants';
import { NotificationService } from './notification.service';

export type UploadStatus = 'pending' | 'uploading' | 'success' | 'error';

@Injectable({ providedIn: 'root' })
export class DocumentService {
  private readonly documentsSignal = signal<DocumentItem[]>([]);
  private readonly isLoadingSignal = signal(false);
  private readonly uploadStatesSignal = signal<Record<string, UploadStatus>>({});
  private readonly isUploadingSignal = signal(false);

  public readonly documents = this.documentsSignal.asReadonly();
  public readonly totalCount = computed(() => this.documentsSignal().length);
  public readonly isLoading = this.isLoadingSignal.asReadonly();
  public readonly uploadStates = this.uploadStatesSignal.asReadonly();
  public readonly isUploading = this.isUploadingSignal.asReadonly();

  private readonly http = inject(HttpClient);
  private readonly notificationService = inject(NotificationService);

  public loadDocuments(): void {
    this.isLoadingSignal.set(true);
    const url = `${API_CONFIG.baseUrl}${API_CONFIG.endpoints.listDocs}`;

    this.http.get<DocumentApiItem[]>(url).subscribe({
      next: (items) => {
        const mapped = items.map((item) => this.mapApiToDocumentItem(item));
        this.documentsSignal.set(mapped);
        this.isLoadingSignal.set(false);
      },
      error: () => {
        this.notificationService.showError('Error fetching documents. Please try again.');
        this.isLoadingSignal.set(false);
      },
    });
  }

  public uploadDocuments(files: File[]): void {
    const states: Record<string, UploadStatus> = {};
    for (const file of files) {
      states[file.name] = 'uploading';
    }
    this.uploadStatesSignal.set(states);
    this.isUploadingSignal.set(true);

    const url = `${API_CONFIG.baseUrl}${API_CONFIG.endpoints.uploadDoc}`;

    const observables = files.map((file) => {
      const formData = new FormData();
      formData.append('file', file);

      return this.http.post<UploadDocApiResponse>(url, formData).pipe(
        tap(() => {
          this.uploadStatesSignal.update((s) => ({ ...s, [file.name]: 'success' }));
        }),
        catchError(() => {
          this.uploadStatesSignal.update((s) => ({ ...s, [file.name]: 'error' }));
          return of(null);
        }),
      );
    });

    forkJoin(observables).subscribe({
      next: (results) => {
        const successCount = results.filter((r) => r !== null).length;
        const errorCount = results.length - successCount;

        if (errorCount === 0) {
          this.notificationService.showSuccess(
            `All ${successCount} file(s) uploaded successfully!`,
          );
        } else if (successCount > 0) {
          this.notificationService.showWarning(
            `${successCount} file(s) uploaded, ${errorCount} failed.`,
          );
        } else {
          this.notificationService.showError('All uploads failed. Please try again.');
        }

        this.isUploadingSignal.set(false);
        this.loadDocuments();
      },
      error: () => {
        this.notificationService.showError('Error uploading files. Please try again.');
        this.isUploadingSignal.set(false);
      },
    });
  }

  public updateDocument(fileId: number, file: File): void {
    this.uploadStatesSignal.set({ [file.name]: 'uploading' });
    this.isUploadingSignal.set(true);

    const url = `${API_CONFIG.baseUrl}${API_CONFIG.endpoints.updateDoc}`;
    const formData = new FormData();
    formData.append('file', file);
    formData.append('file_id', fileId.toString());

    this.http.post<UpdateDocApiResponse>(url, formData).subscribe({
      next: () => {
        this.uploadStatesSignal.update((s) => ({ ...s, [file.name]: 'success' }));
        this.notificationService.showSuccess('Document updated successfully.');
        this.isUploadingSignal.set(false);
        this.loadDocuments();
      },
      error: () => {
        this.uploadStatesSignal.update((s) => ({ ...s, [file.name]: 'error' }));
        this.notificationService.showError('Error updating document. Please try again.');
        this.isUploadingSignal.set(false);
      },
    });
  }

  public syncWebKnowledgeBase(): Observable<any> {
    const url = `${API_CONFIG.baseUrl}${API_CONFIG.endpoints.syncWeb}`;
    return this.http.post<any>(url, {});
  }

  public deleteDocument(fileId: number): void {
    const url = `${API_CONFIG.baseUrl}${API_CONFIG.endpoints.deleteDoc}`;

    this.http.post<ApiMessageResponse>(url, { file_id: fileId }).subscribe({
      next: () => {
        this.notificationService.showSuccess('Document deleted successfully.');
        this.loadDocuments();
      },
      error: () => {
        this.notificationService.showError('Error deleting document. Please try again.');
      },
    });
  }

  private mapApiToDocumentItem(item: DocumentApiItem): DocumentItem {
    return {
      id: item.FILE_ID,
      name: item.FILE_NAME,
      description: item.DESCRIPTION,
      uploadedBy: item.UPLOADED_BY_NAME,
      uploadedById: item.UPLOADED_BY,
      uploadedAt: new Date(item.UPLOADED_AT),
    };
  }
}
