import { inject, Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ChatMessage } from '../models/message.model';
import { ChatApiRequest, ChatApiResponse, ConversationApiResponse } from '../models/api-response.model';
import { API_CONFIG, CHAT_MODEL } from '../constants/app.constants';
import { AuthService } from './auth.service';
import { NotificationService } from './notification.service';

@Injectable({ providedIn: 'root' })
export class ChatService {
  private readonly messagesSignal = signal<ChatMessage[]>([]);
  private readonly isTypingSignal = signal(false);

  public readonly messages = this.messagesSignal.asReadonly();
  public readonly isTyping = this.isTypingSignal.asReadonly();

  private readonly http = inject(HttpClient);
  private readonly authService = inject(AuthService);
  private readonly notificationService = inject(NotificationService);

  public loadConversation(): void {
    const sessionId = this.authService.getSessionId();
    if (!sessionId) {
      return;
    }

    const url = `${API_CONFIG.baseUrl}${API_CONFIG.endpoints.getConversation}/${sessionId}`;

    this.http.get<ConversationApiResponse>(url).subscribe({
      next: (response) => {
        if (response.conversation?.length > 0) {
          const mapped: ChatMessage[] = response.conversation.map((msg) => ({
            id: crypto.randomUUID(),
            content: msg.content,
            sender: msg.role === 'human' ? ('user' as const) : ('bot' as const),
            timestamp: new Date(),
            isWebSearch: false,
            sources: msg.role === 'ai' && msg.sources?.length ? msg.sources : undefined,
          }));
          this.messagesSignal.set(mapped);
        }
      },
      error: () => {
        // Silently continue with empty chat
      },
    });
  }

  public sendMessage(content: string, isWebSearch: boolean): void {
    const trimmedContent = content.trim();
    if (!trimmedContent) {
      return;
    }

    const empId = this.authService.getEmpId();
    const sessionId = this.authService.getSessionId();
    const userName = this.authService.getUserName();

    if (!empId || !sessionId || !userName) {
      this.notificationService.showError('Session data is missing. Please log in again.');
      return;
    }

    const userMessage: ChatMessage = {
      id: crypto.randomUUID(),
      content: trimmedContent,
      sender: 'user',
      timestamp: new Date(),
      isWebSearch,
    };
    this.messagesSignal.update((messages) => [...messages, userMessage]);

    this.isTypingSignal.set(true);

    const url = `${API_CONFIG.baseUrl}${API_CONFIG.endpoints.chat}`;
    const requestBody: ChatApiRequest = {
      emp_id: empId,
      session_id: sessionId,
      question: trimmedContent,
      model: CHAT_MODEL,
      user_name: userName,
      is_web_search: isWebSearch,
    };

    this.http.post<ChatApiResponse>(url, requestBody).subscribe({
      next: (response) => {
        const botMessage: ChatMessage = {
          id: crypto.randomUUID(),
          content: response.answer,
          sender: 'bot',
          timestamp: new Date(),
          isWebSearch: response.is_web_search,
          sources:
            !response.is_web_search && response.used_document_context && response.sources?.length
              ? response.sources
              : undefined,
          webSources:
            response.is_web_search && response.web_sources?.length
              ? response.web_sources
              : undefined,
        };
        this.messagesSignal.update((messages) => [...messages, botMessage]);
        this.isTypingSignal.set(false);
      },
      error: () => {
        const errorMessage: ChatMessage = {
          id: crypto.randomUUID(),
          content: 'Sorry, something went wrong. Please try again.',
          sender: 'bot',
          timestamp: new Date(),
          isWebSearch: false,
        };
        this.messagesSignal.update((messages) => [...messages, errorMessage]);
        this.isTypingSignal.set(false);
      },
    });
  }

  public clearChat(): void {
    this.messagesSignal.set([]);
    this.isTypingSignal.set(false);
    this.authService.startNewSession();
  }
}
