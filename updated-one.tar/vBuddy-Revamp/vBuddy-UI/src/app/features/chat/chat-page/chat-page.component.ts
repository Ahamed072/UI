import { AfterViewChecked, Component, effect, ElementRef, OnInit, signal, ViewChild } from '@angular/core';
import { ChatHeaderComponent } from '../chat-header/chat-header.component';
import { WelcomePanelComponent } from '../welcome-panel/welcome-panel.component';
import { MessageBubbleComponent } from '../message-bubble/message-bubble.component';
import { ChatInputComponent } from '../chat-input/chat-input.component';
import { ConfirmDialogComponent } from '../../admin/document-management/confirm-dialog/confirm-dialog.component';
import { ChatService } from '../../../core/services/chat.service';
import { AuthService } from '../../../core/services/auth.service';
import { ChatMessage } from '../../../core/models/message.model';
import { APP_CONSTANTS } from '../../../core/constants/app.constants';

@Component({
  selector: 'app-chat-page',
  standalone: true,
  imports: [
    ChatHeaderComponent,
    WelcomePanelComponent,
    MessageBubbleComponent,
    ChatInputComponent,
    ConfirmDialogComponent,
  ],
  templateUrl: './chat-page.component.html',
  styleUrl: './chat-page.component.scss',
})
export class ChatPageComponent implements OnInit, AfterViewChecked {
  @ViewChild('messagesContainer') private readonly messagesContainer!: ElementRef<HTMLDivElement>;

  protected readonly logoPath = APP_CONSTANTS.companyLogoPath;
  protected readonly isWebSearchEnabled = signal(false);
  protected readonly showLogoutDialog = signal(false);
  private shouldScrollToBottom = false;

  constructor(
    protected readonly chatService: ChatService,
    private readonly authService: AuthService,
  ) {
    effect(() => {
      this.chatService.messages();
      this.shouldScrollToBottom = true;
    });
  }

  public ngOnInit(): void {
    this.chatService.loadConversation();
  }

  public ngAfterViewChecked(): void {
    if (this.shouldScrollToBottom) {
      this.scrollToBottom();
      this.shouldScrollToBottom = false;
    }
  }

  protected get messages() {
    return this.chatService.messages;
  }

  protected get isTyping() {
    return this.chatService.isTyping;
  }

  protected onSendMessage(content: string): void {
    this.chatService.sendMessage(content, this.isWebSearchEnabled());
  }

  protected onSuggestionClick(query: string): void {
    this.onSendMessage(query);
  }

  protected onNewChat(): void {
    this.chatService.clearChat();
  }

  protected onLogout(): void {
    this.showLogoutDialog.set(true);
  }

  protected onLogoutConfirm(): void {
    this.showLogoutDialog.set(false);
    this.authService.logout();
  }

  protected onLogoutCancel(): void {
    this.showLogoutDialog.set(false);
  }

  protected onWebSearchToggle(enabled: boolean): void {
    this.isWebSearchEnabled.set(enabled);
  }

  protected trackByMessageId(_index: number, message: ChatMessage): string {
    return message.id;
  }

  private scrollToBottom(): void {
    const container = this.messagesContainer?.nativeElement;
    if (container) {
      container.scrollTop = container.scrollHeight;
    }
  }
}
