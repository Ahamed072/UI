import { Component, input, output } from '@angular/core';
import { APP_CONSTANTS } from '../../../core/constants/app.constants';

@Component({
  selector: 'app-chat-header',
  standalone: true,
  templateUrl: './chat-header.component.html',
  styleUrl: './chat-header.component.scss',
})
export class ChatHeaderComponent {
  protected readonly appName = APP_CONSTANTS.appName;
  protected readonly logoPath = APP_CONSTANTS.companyLogoPath;
  protected readonly companyShortName = APP_CONSTANTS.companyShortName;

  public readonly isWebSearchEnabled = input(false);

  public readonly newChat = output<void>();
  public readonly logout = output<void>();
  public readonly webSearchToggle = output<boolean>();

  protected onNewChat(): void {
    this.newChat.emit();
  }

  protected onLogout(): void {
    this.logout.emit();
  }

  protected onWebSearchToggle(): void {
    this.webSearchToggle.emit(!this.isWebSearchEnabled());
  }
}
