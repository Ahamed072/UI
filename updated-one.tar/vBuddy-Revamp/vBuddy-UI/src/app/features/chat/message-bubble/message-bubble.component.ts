import { Component, computed, input } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ChatMessage } from '../../../core/models/message.model';
import { APP_CONSTANTS } from '../../../core/constants/app.constants';
import { MarkdownPipe } from '../../../shared/pipes/markdown.pipe';

@Component({
  selector: 'app-message-bubble',
  standalone: true,
  imports: [DatePipe, MarkdownPipe],
  templateUrl: './message-bubble.component.html',
  styleUrl: './message-bubble.component.scss',
})
export class MessageBubbleComponent {
  protected readonly appName = APP_CONSTANTS.appName;
  protected readonly logoPath = APP_CONSTANTS.companyLogoPath;
  protected readonly policyDocsUrl = APP_CONSTANTS.policyDocumentsUrl;

  public readonly message = input.required<ChatMessage>();

  protected readonly isUser = computed(() => this.message().sender === 'user');
  protected readonly isBot = computed(() => this.message().sender === 'bot');
  protected readonly hasSources = computed(
    () => this.isBot() && (this.message().sources?.length ?? 0) > 0,
  );
  protected readonly hasWebSources = computed(
    () => this.isBot() && (this.message().webSources?.length ?? 0) > 0,
  );
}
