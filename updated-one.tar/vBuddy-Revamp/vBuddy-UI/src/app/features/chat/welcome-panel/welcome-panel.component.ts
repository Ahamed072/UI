import { Component, output } from '@angular/core';
import { APP_CONSTANTS, SUGGESTION_CHIPS } from '../../../core/constants/app.constants';

@Component({
  selector: 'app-welcome-panel',
  standalone: true,
  templateUrl: './welcome-panel.component.html',
  styleUrl: './welcome-panel.component.scss',
})
export class WelcomePanelComponent {
  protected readonly appName = APP_CONSTANTS.appName;
  protected readonly greeting = APP_CONSTANTS.defaultGreeting;
  protected readonly companyName = APP_CONSTANTS.companyName;
  protected readonly logoPath = APP_CONSTANTS.companyLogoPath;
  protected readonly suggestions = SUGGESTION_CHIPS;

  public readonly suggestionClick = output<string>();

  protected onSuggestionClick(query: string): void {
    this.suggestionClick.emit(query);
  }

  protected trackBySuggestion(_index: number, item: (typeof SUGGESTION_CHIPS)[number]): string {
    return item.label;
  }
}
