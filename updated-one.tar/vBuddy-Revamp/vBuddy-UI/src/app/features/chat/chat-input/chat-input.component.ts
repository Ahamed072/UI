import { Component, input, output, signal } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { APP_CONSTANTS } from '../../../core/constants/app.constants';

@Component({
  selector: 'app-chat-input',
  standalone: true,
  imports: [FormsModule],
  templateUrl: './chat-input.component.html',
  styleUrl: './chat-input.component.scss',
})
export class ChatInputComponent {
  public readonly isDisabled = input(false);

  public readonly messageSend = output<string>();

  protected readonly appName = APP_CONSTANTS.appName;
  protected readonly messageText = signal('');
  protected readonly maxLength = APP_CONSTANTS.maxMessageLength;

  protected onSend(): void {
    const text = this.messageText().trim();
    if (!text || this.isDisabled()) {
      return;
    }

    this.messageSend.emit(text);
    this.messageText.set('');
  }

  protected onKeyDown(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.onSend();
    }
  }
}
