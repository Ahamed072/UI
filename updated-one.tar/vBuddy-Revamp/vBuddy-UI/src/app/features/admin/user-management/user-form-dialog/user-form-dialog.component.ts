import { Component, input, OnInit, output, signal } from '@angular/core';
import { UserRole } from '../../../../core/models/user.model';
import { ManagedUser, UserFormData } from '../../../../core/models/managed-user.model';
import { ALLOWED_EMAIL_DOMAIN } from '../../../../core/constants/app.constants';

@Component({
  selector: 'app-user-form-dialog',
  standalone: true,
  templateUrl: './user-form-dialog.component.html',
  styleUrl: './user-form-dialog.component.scss',
})
export class UserFormDialogComponent implements OnInit {
  public readonly dialogTitle = input('Create User');
  public readonly existingUser = input<ManagedUser | null>(null);

  public readonly confirm = output<UserFormData>();
  public readonly cancel = output<void>();

  protected readonly empId = signal('');
  protected readonly name = signal('');
  protected readonly email = signal('');
  protected readonly role = signal<UserRole>('user');
  protected readonly emailError = signal('');

  public ngOnInit(): void {
    const user = this.existingUser();
    if (user) {
      this.empId.set(user.empId);
      this.name.set(user.name);
      this.email.set(user.email);
      this.role.set(user.role);
    }
  }

  protected get isEditMode(): boolean {
    return this.existingUser() !== null;
  }

  protected get isFormValid(): boolean {
    const hasName = this.name().trim().length > 0;
    const trimmedEmail = this.email().trim().toLowerCase();
    const hasEmail = trimmedEmail.length > 0;
    const hasEmpId = this.isEditMode || this.empId().trim().length > 0;
    const validEmail = trimmedEmail.endsWith(ALLOWED_EMAIL_DOMAIN);

    return hasName && hasEmail && hasEmpId && validEmail;
  }

  protected onInputChange(event: Event, field: 'empId' | 'name' | 'email'): void {
    const value = (event.target as HTMLInputElement).value;
    this[field].set(value);
    if (field === 'email') {
      this.validateEmail(value);
    }
  }

  private validateEmail(value: string): void {
    const trimmed = value.trim().toLowerCase();
    if (trimmed.length > 0 && !trimmed.endsWith(ALLOWED_EMAIL_DOMAIN)) {
      this.emailError.set(`Email must end with ${ALLOWED_EMAIL_DOMAIN}`);
    } else {
      this.emailError.set('');
    }
  }

  protected onRoleChange(event: Event): void {
    const value = (event.target as HTMLSelectElement).value as UserRole;
    this.role.set(value);
  }

  protected onConfirm(): void {
    if (this.isFormValid) {
      this.confirm.emit({
        empId: this.empId().trim(),
        name: this.name().trim(),
        email: this.email().trim(),
        role: this.role(),
      });
    }
  }

  protected onCancel(): void {
    this.cancel.emit();
  }

  protected onBackdropClick(event: MouseEvent): void {
    if ((event.target as HTMLElement).classList.contains('dialog-overlay')) {
      this.onCancel();
    }
  }
}
