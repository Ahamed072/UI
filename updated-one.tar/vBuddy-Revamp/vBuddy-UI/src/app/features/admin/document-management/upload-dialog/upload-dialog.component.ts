import { Component, input, output, signal } from '@angular/core';
import { KeyValuePipe } from '@angular/common';

@Component({
  selector: 'app-upload-dialog',
  standalone: true,
  imports: [KeyValuePipe],
  templateUrl: './upload-dialog.component.html',
  styleUrl: './upload-dialog.component.scss',
})
export class UploadDialogComponent {
  public readonly dialogTitle = input('Upload Document');
  public readonly existingFileName = input('');
  public readonly allowMultiple = input(false);
  public readonly isUploading = input(false);
  public readonly uploadStates = input<Record<string, string>>({});

  public readonly confirm = output<File[]>();
  public readonly cancel = output<void>();

  protected readonly selectedFiles = signal<File[]>([]);
  protected readonly selectedFileNames = signal<string[]>([]);

  protected get isConfirmDisabled(): boolean {
    return this.selectedFiles().length === 0;
  }

  protected onFileSelected(event: Event): void {
    const target = event.target as HTMLInputElement;
    const files = target.files;
    if (!files || files.length === 0) {
      return;
    }

    const newFiles: File[] = [];
    const newNames: string[] = [];
    for (let i = 0; i < files.length; i++) {
      newFiles.push(files[i]);
      newNames.push(files[i].name);
    }

    if (this.allowMultiple()) {
      const existingFiles = this.selectedFiles();
      const existingNames = this.selectedFileNames();
      const mergedFiles = [...existingFiles];
      const mergedNames = [...existingNames];
      for (let i = 0; i < newFiles.length; i++) {
        if (!mergedNames.includes(newNames[i])) {
          mergedFiles.push(newFiles[i]);
          mergedNames.push(newNames[i]);
        }
      }
      this.selectedFiles.set(mergedFiles);
      this.selectedFileNames.set(mergedNames);
    } else {
      this.selectedFiles.set([newFiles[0]]);
      this.selectedFileNames.set([newNames[0]]);
    }

    target.value = '';
  }

  protected removeFile(index: number): void {
    this.selectedFiles.update((files) => files.filter((_, i) => i !== index));
    this.selectedFileNames.update((names) => names.filter((_, i) => i !== index));
  }

  protected onConfirm(): void {
    const files = this.selectedFiles();
    if (files.length > 0) {
      this.confirm.emit(files);
    }
  }

  protected onCancel(): void {
    if (!this.isUploading()) {
      this.cancel.emit();
    }
  }

  protected onBackdropClick(event: MouseEvent): void {
    if ((event.target as HTMLElement).classList.contains('dialog-overlay')) {
      this.onCancel();
    }
  }

  protected getStatusIcon(status: string): string {
    switch (status) {
      case 'uploading': return 'sync';
      case 'success': return 'check_circle';
      case 'error': return 'error';
      default: return 'schedule';
    }
  }
}
