import { Component, input, output } from '@angular/core';

@Component({
  selector: 'app-confirm-dialog',
  standalone: true,
  templateUrl: './confirm-dialog.component.html',
  styleUrl: './confirm-dialog.component.scss',
})
export class ConfirmDialogComponent {
  public readonly title = input('Confirm');
  public readonly message = input('Are you sure?');
  public readonly cancelLabel = input('No');
  public readonly confirmLabel = input('Yes, Delete');
  public readonly icon = input('warning');
  public readonly confirmStyle = input<'danger' | 'primary'>('danger');

  public readonly confirm = output<void>();
  public readonly cancel = output<void>();

  protected onConfirm(): void {
    this.confirm.emit();
  }

  protected onCancel(): void {
    this.cancel.emit();
  }

  protected onBackdropClick(event: MouseEvent): void {
    if ((event.target as HTMLElement).classList.contains('dialog-overlay')) {
      this.onCancel();
    }
  }
}
