import { Component, computed, effect, OnInit, signal } from '@angular/core';
import { DatePipe } from '@angular/common';
import { DocumentService } from '../../../core/services/document.service';
import { NotificationService } from '../../../core/services/notification.service';
import { DocumentItem } from '../../../core/models/document.model';
import { UploadDialogComponent } from './upload-dialog/upload-dialog.component';
import { ConfirmDialogComponent } from './confirm-dialog/confirm-dialog.component';

@Component({
  selector: 'app-document-management',
  standalone: true,
  imports: [DatePipe, UploadDialogComponent, ConfirmDialogComponent],
  templateUrl: './document-management.component.html',
  styleUrl: './document-management.component.scss',
})
export class DocumentManagementComponent implements OnInit {
  protected readonly showUploadDialog = signal(false);
  protected readonly showDeleteDialog = signal(false);
  protected readonly showUpdateDialog = signal(false);
  protected readonly selectedDocument = signal<DocumentItem | null>(null);

  // Pagination
  protected readonly currentPage = signal(1);
  protected readonly pageSize = signal(10);

  protected readonly totalPages = computed(() =>
    Math.ceil(this.documentService.totalCount() / this.pageSize()),
  );

  protected readonly paginatedDocuments = computed(() => {
    const all = this.documentService.documents();
    const start = (this.currentPage() - 1) * this.pageSize();
    return all.slice(start, start + this.pageSize());
  });

  protected readonly pageOffset = computed(
    () => (this.currentPage() - 1) * this.pageSize(),
  );

  protected readonly pageNumbers = computed(() =>
    Array.from({ length: this.totalPages() }, (_, i) => i + 1),
  );

  // Sync Knowledge Base
  protected readonly showSyncDialog = signal(false);
  protected readonly isSyncing = signal(false);

  private wasUploading = false;

  constructor(
    protected readonly documentService: DocumentService,
    private readonly notificationService: NotificationService,
  ) {
    effect(() => {
      const uploading = this.documentService.isUploading();
      if (this.wasUploading && !uploading) {
        this.showUploadDialog.set(false);
        this.showUpdateDialog.set(false);
        this.selectedDocument.set(null);
        this.currentPage.set(1);
      }
      this.wasUploading = uploading;
    });
  }

  public ngOnInit(): void {
    this.documentService.loadDocuments();
  }

  protected get totalCount() {
    return this.documentService.totalCount;
  }

  protected onUploadNew(): void {
    this.selectedDocument.set(null);
    this.showUploadDialog.set(true);
  }

  protected onUpdate(doc: DocumentItem): void {
    this.selectedDocument.set(doc);
    this.showUpdateDialog.set(true);
  }

  protected onDelete(doc: DocumentItem): void {
    this.selectedDocument.set(doc);
    this.showDeleteDialog.set(true);
  }

  protected onUploadConfirm(files: File[]): void {
    this.documentService.uploadDocuments(files);
  }

  protected onUpdateConfirm(files: File[]): void {
    const doc = this.selectedDocument();
    if (doc && files.length > 0) {
      this.documentService.updateDocument(doc.id, files[0]);
    }
  }

  protected onDeleteConfirm(): void {
    const doc = this.selectedDocument();
    if (doc) {
      this.documentService.deleteDocument(doc.id);
      if (this.currentPage() > this.totalPages()) {
        this.currentPage.set(Math.max(1, this.totalPages()));
      }
    }
    this.showDeleteDialog.set(false);
    this.selectedDocument.set(null);
  }

  protected onDialogClose(): void {
    this.showUploadDialog.set(false);
    this.showDeleteDialog.set(false);
    this.showUpdateDialog.set(false);
    this.showSyncDialog.set(false);
    this.selectedDocument.set(null);
  }

  // Pagination navigation
  protected goToPage(page: number): void {
    if (page >= 1 && page <= this.totalPages()) {
      this.currentPage.set(page);
    }
  }

  protected goToPreviousPage(): void {
    this.goToPage(this.currentPage() - 1);
  }

  protected goToNextPage(): void {
    this.goToPage(this.currentPage() + 1);
  }

  // Sync Knowledge Base
  protected onSyncKnowledgeBase(): void {
    if (this.isSyncing()) {
      return;
    }
    this.showSyncDialog.set(true);
  }

  protected onSyncConfirm(): void {
    this.showSyncDialog.set(false);
    this.isSyncing.set(true);

    this.documentService.syncWebKnowledgeBase().subscribe({
      next: (result) => {
        this.isSyncing.set(false);
        const totalStored = result.knowledge_base?.reduce(
          (sum: number, kb: any) => sum + (kb.stored || 0), 0
        ) ?? 0;
        if (totalStored > 0) {
          this.notificationService.showSuccess(
            `Web knowledge base synced! ${totalStored} page(s) updated.`
          );
        } else {
          this.notificationService.showSuccess(
            'Web knowledge base is already up to date.'
          );
        }
      },
      error: () => {
        this.isSyncing.set(false);
        this.notificationService.showError(
          'Failed to sync web knowledge base. Please try again.'
        );
      },
    });
  }

  protected onSyncCancel(): void {
    this.showSyncDialog.set(false);
  }

  protected getDocIcon(name: string): string {
    return name.toLowerCase().endsWith('.md') ? 'article' : 'picture_as_pdf';
  }

  protected isMarkdown(name: string): boolean {
    return name.toLowerCase().endsWith('.md');
  }
}
