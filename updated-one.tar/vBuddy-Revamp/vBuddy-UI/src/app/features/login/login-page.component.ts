import { Component, OnInit, signal } from '@angular/core';
import { AuthService } from '../../core/services/auth.service';
import { APP_CONSTANTS } from '../../core/constants/app.constants';

@Component({
  selector: 'app-login-page',
  standalone: true,
  imports: [],
  templateUrl: './login-page.component.html',
  styleUrl: './login-page.component.scss',
})
export class LoginPageComponent implements OnInit {
  protected readonly appName = APP_CONSTANTS.appName;
  protected readonly appTagline = APP_CONSTANTS.appTagline;
  protected readonly companyName = APP_CONSTANTS.companyName;
  protected readonly logoPath = APP_CONSTANTS.companyLogoPath;

  protected readonly errorMessage = signal('');
  protected readonly isLoading = signal(false);

  constructor(private readonly authService: AuthService) {}

  public ngOnInit(): void {
    this.isLoading.set(true);
    this.authService
      .handleMsalRedirect()
      .then(() => {
        this.isLoading.set(false);
      })
      .catch(() => {
        this.errorMessage.set('Login failed. Please try again.');
        this.isLoading.set(false);
      });
  }

  protected async onMicrosoftLogin(): Promise<void> {
    this.isLoading.set(true);
    this.errorMessage.set('');
    try {
      await this.authService.loginWithMsal();
    } catch (error: unknown) {
      const message =
        error instanceof Error ? error.message : 'Login failed. Please try again.';
      this.errorMessage.set(message);
      this.isLoading.set(false);
    }
  }
}
