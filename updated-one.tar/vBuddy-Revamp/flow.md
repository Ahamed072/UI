%%{init: {'theme': 'base', 'themeVariables': { 'fontSize': '14px', 'fontFamily': 'Inter, Arial, sans-serif', 'clusterBkg': '#fdfbf9', 'clusterBorder': '#e6d8d1', 'lineColor': '#a39b98'}}}%%
flowchart LR
    %% Global Graph Settings
    direction LR

    %% -------------------------
    %% STYLING CLASSES
    %% -------------------------
    classDef endpoint fill:#fdf4f0,stroke:#e8bcae,stroke-width:2px,rx:25,ry:25,color:#222,font-weight:bold;
    classDef orchestrator fill:#f4f4f5,stroke:#d4d4d8,stroke-width:2px,rx:8,ry:8,color:#222,font-weight:bold;
    classDef process fill:#ffffff,stroke:#d0c0b8,stroke-width:2px,rx:8,ry:8,color:#333;
    classDef db fill:#f0f7fc,stroke:#a1c6e8,stroke-width:2px,rx:8,ry:8,color:#333;

    %% -------------------------
    %% NODES & FLOW
    %% -------------------------
    
    User(["<b>👤 User Query</b><br/><span style='font-size:12px; font-weight:normal;'>+ Chat History (Past 10 turns)</span>"]):::endpoint
    Chain["<b>⚙️ RAG Chain</b><br/><span style='font-size:12px; font-weight:normal;'>invoke(input, history)</span>"]:::orchestrator

    subgraph Stage1 ["STAGE 1: Intent Classification & Retrieval"]
        direction TB
        
        Intent["<b>🧠 1. Intent Analyzer</b> (LLM temp=0)<br/><hr style='margin: 4px 0; border-color:#eee;'/><div style='text-align:left; font-size:12px; line-height:1.4;'><b>In:</b> Query, History, Doc Summaries<br/><b>Out:</b> Standalone Search Query<br/><b>Out:</b> Target Type & File Filters</div>"]:::process

        DB[("<b>🗄️ 2. Smart Retrieval</b> (ChromaDB)<br/><hr style='margin: 4px 0; border-color:#a1c6e8;'/><div style='text-align:left; font-size:12px; line-height:1.4;'>🔍 <b>Internal Apps:</b> k=5<br/>🔍 <b>Policy (w/ or w/o files):</b> k=8<br/>🚫 <b>General:</b> No search (dummy doc)</div>")]:::db

        Extract["<b>📑 3. Citation Extractor</b><br/><hr style='margin: 4px 0; border-color:#eee;'/><div style='text-align:left; font-size:12px;'>Packages Source IDs & Filenames<br/>for accurate F.E. referencing</div>"]:::process

        Intent -- "Passes Standalone<br/>Query & Filters" --> DB
        DB -- "Raw Chunks" --> Extract
    end

    subgraph Stage2 ["STAGE 2: Text Generation"]
        direction TB
        
        Gen["<b>⚡ Final LLM Synthesizer</b><br/><hr style='margin: 4px 0; border-color:#eee;'/><div style='text-align:left; font-size:12px; line-height:1.4;'><b>Prompt:</b> System Rules & Restrictions<br/><b>Context:</b> Retrieved Docs + History<br/><b>Output:</b> Formatted Helpful Answer</div>"]:::process
    end

    Out(["<b>💬 Frontend Response</b><br/><span style='font-size:12px; font-weight:normal;'>Answer String + Attached Citations</span>"]):::endpoint

    %% Main Connections
    User ==> Chain
    Chain ==> Stage1
    Extract == "Retrieved<br/>Context" ==> Stage2
    Stage2 ==> Out