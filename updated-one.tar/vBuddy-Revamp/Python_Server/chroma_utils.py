from langchain_community.document_loaders import PyPDFLoader, Docx2txtLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_huggingface import HuggingFaceEmbeddings
from langchain_chroma import Chroma
from langchain_openai import ChatOpenAI
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from typing import List
from langchain_core.documents import Document
import os
import hashlib
from dotenv import load_dotenv

load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200, length_function=len)
embedding_function = HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L12-v2")
vectorstore = Chroma(persist_directory="./chroma_db", embedding_function=embedding_function)


def generate_chunk_id(file_id: int, file_name: str, page: int, chunk_index: int, content: str) -> str:
    """
    Generate a deterministic unique ID for each chunk based on its content and metadata.
    This prevents duplicate chunks from being created when the same document is re-indexed.
    """
    # Create a unique string combining file info, page, chunk index, and content hash
    # Using SHA-256 instead of MD5 for security compliance (non-cryptographic use case)
    content_hash = hashlib.sha256(content.encode()).hexdigest()[:8]
    unique_string = f"{file_id}_{file_name}_{page}_{chunk_index}_{content_hash}"
    return hashlib.sha256(unique_string.encode()).hexdigest()


def load_and_split_document(file_path: str) -> List[Document]:
    if file_path.endswith('.pdf'):
        loader = PyPDFLoader(file_path)
    elif file_path.endswith('.docx'):
        loader = Docx2txtLoader(file_path)
    else:
        raise ValueError(f"Unsupported file type: {file_path}")
    
    documents = loader.load()
    return text_splitter.split_documents(documents)

def summarize_document_content(splits: List[Document]) -> str:
    """
    Summarize document content using GPT-4o-mini for Document Management System.
    
    Args:
        splits: List of Document objects from text splitter
        
    Returns:
        A concise summary paragraph suitable for DMS description
    """
    # Concatenate all document chunks
    full_content = "\n\n".join([doc.page_content for doc in splits])
    
    # Limit content length to avoid token limits (approximately 8000 tokens worth of text)
    if len(full_content) > 32000:
        full_content = full_content[:32000] + "..."
    
    # Summarization prompt
    summarization_prompt = (
       """Summarize the uploaded document in a single, concise paragraph suitable for a Document Management System (DMS). 
            The summary must clearly describe the purpose of the document, what it covers, key processes or policies included, 
            and major components or sections—without adding interpretations or omitting important structural elements. 
            Maintain a professional and neutral tone, avoid unnecessary details, and ensure the summary reads like an official 
            document description.

            Ensure the summary addresses also includes the following areas:

            ** PURPOSE & SCOPE **
            - State the primary purpose in one clear sentence.
            - Identify who the document applies to (employees, contractors, departments, etc.).
            - Specify the situations or scenarios the document covers.

            ** KEY CONTENT AREAS **
            List the main topics, processes, or sections included in the document using clear keywords:
            - [Topic 1]
            - [Topic 2]
            - [Topic 3]
            - etc.

            ** CRITICAL DETAILS **
            Include any essential points such as:
            - Important timelines, deadlines, or response requirements.
            - Key contacts, committees, or responsible parties.
            - Compliance or regulatory obligations.
            - Mandatory actions, restrictions, or prohibitions."""
    )
    
    # Create prompt template
    summary_prompt_template = ChatPromptTemplate.from_messages([
        ("system", summarization_prompt),
        ("human", "Document content:\n\n{content}")
    ])
    
    # Initialize LLM with gpt-4o-mini
    llm = ChatOpenAI(model="gpt-4o-mini", openai_api_key=OPENAI_API_KEY)
    
    # Create chain
    summary_chain = summary_prompt_template | llm | StrOutputParser()
    
    # Generate summary
    try:
        summary = summary_chain.invoke({"content": full_content})
        return summary.strip()
    except Exception as e:
        print(f"Error generating summary: {e}")
        return "Unable to generate summary for this document."


def generate_internal_apps_description(file_path: str) -> str:
    """
    Generate a dynamic description for internal apps knowledge base using GPT-4o-mini.
    This description will be used by the intermediate LLM for query classification.
    
    Args:
        file_path: Path to the internal_apps_knowledge.md file
        
    Returns:
        A structured description suitable for injection into the intermediate LLM prompt
    """
    try:
        # Read the markdown file
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Limit content length to avoid token limits
        if len(content) > 32000:
            content = content[:32000] + "..."
        
        # Prompt for generating internal apps classification summary
        apps_description_prompt = (
            """Analyze the internal applications knowledge base and generate a concise, structured summary 
            specifically designed for an intermediate LLM to classify user queries accurately.
            
            Your output will be injected into a query classification prompt, so it must be clear and actionable.
            
            For each application in the knowledge base, extract and format:
            
            1. **Application Name & Abbreviation** (e.g., VAR, VAM, KRA, vTest, VTA)
            2. **Primary Purpose** - One sentence describing what the app does
            3. **Key Features/Capabilities** - Bullet points of main functionalities
            4. **Target Users** - Who uses it (HR team, IT Administration, all employees, etc.)
            5. **Access URL** - If available
            6. **Contact Persons/Support** - Key contacts for support
            
            FORMAT YOUR RESPONSE AS:
            
            Questions about vThink's internal applications/tools/systems including:
            * [AppName] ([Abbreviation]) - [One-line purpose]. 
              Used by [target users] for [key features like X, Y, Z].
              Contacts: [Person1, Person2]. URL: [url if available]
            * [Next app...]
            
            CRITICAL REQUIREMENTS:
            - Keep each app description to 2-3 lines maximum
            - Focus on keywords that users might mention in queries
            - Maintain consistent formatting for easy parsing
            - Include ALL applications found in the knowledge base
            - Use clear, searchable terminology
            - DO NOT use curly braces or special template characters in your output
            - Use parentheses or square brackets instead of curly braces if grouping is needed
            
            This summary will help the LLM identify when a user is asking about internal applications
            versus company policies or general questions."""
        )
        
        # Create prompt template
        description_prompt_template = ChatPromptTemplate.from_messages([
            ("system", apps_description_prompt),
            ("human", "Internal Apps Knowledge Base Content:\n\n{content}")
        ])
        
        # Initialize LLM with gpt-4o-mini
        llm = ChatOpenAI(model="gpt-4o-mini", openai_api_key=OPENAI_API_KEY)
        
        # Create chain
        description_chain = description_prompt_template | llm | StrOutputParser()
        
        # Generate description
        description = description_chain.invoke({"content": content})
        return description.strip()
        
    except Exception as e:
        print(f"Error generating internal apps description: {e}")
        # Return fallback description
        return ("Questions about vThink's internal applications/tools/systems including: "
                "VAR (attendance reports), VAM (asset management), KRA (employee feedback), "
                "vTest (recruitment tests), VTA (talent acquisition)")
    

def index_document_to_chroma(file_path: str, file_record) -> tuple[bool, str | None]:
    """Index a document to ChromaDB and return success status with description.
    
    Args:
        file_path: Path to the document file
        file_record: Database record containing file metadata
        
    Returns:
        tuple: (success: bool, description: str | None)
    """
    try:
        # Delete any existing chunks for this file_id to prevent duplicates
        try:
            existing_docs = vectorstore.get(where={"file_id": file_record.FILE_ID})
            if existing_docs and len(existing_docs['ids']) > 0:
                vectorstore._collection.delete(where={"file_id": file_record.FILE_ID})
        except Exception:
            pass
        
        splits = load_and_split_document(file_path)
        description = summarize_document_content(splits)
        
        # Generate deterministic IDs and add metadata to each split
        chunk_ids = []
        for idx, split in enumerate(splits):
            page = split.metadata.get('page', 0)
            chunk_id = generate_chunk_id(
                file_id=file_record.FILE_ID,
                file_name=file_record.FILE_NAME,
                page=page,
                chunk_index=idx,
                content=split.page_content
            )
            chunk_ids.append(chunk_id)
            
            # Add metadata for routing
            split.metadata['type'] = 'policy'
            split.metadata['file_id'] = file_record.FILE_ID
            split.metadata['file_name'] = file_record.FILE_NAME
            split.metadata['file_description'] = file_record.DESCRIPTION
            split.metadata['chunk_index'] = idx
        
        vectorstore.add_documents(documents=splits, ids=chunk_ids)
        return True, description
    except Exception as e:
        print(f"Error indexing document: {e}")
        return False, None

def delete_doc_from_chroma(file_id: int):
    try:
        vectorstore._collection.delete(where={"file_id": file_id})
        return True
    except Exception as e:
        print(f"Error deleting document with file_id {file_id}: {e}")
        return False


def _extract_app_metadata(section: str) -> dict | None:
    """Extract application metadata from a markdown section.
    
    Args:
        section: Markdown section containing app information
        
    Returns:
        dict with app_name, content, url, owner or None if no valid app found
    """
    import re
    
    # Extract application name
    name_match = re.search(r'Application Name:\s*\*\*(.+?)\*\*', section)
    if not name_match:
        return None
    
    app_name = name_match.group(1).strip()
    
    # Extract additional metadata - fixed regex to avoid reluctant quantifier issue
    url_match = re.search(r'\*\*Access URL\*\*\s*\[?(https?://[^\]\s]+)\]?', section)
    # Fixed: Use [^\n]+ instead of .+? to properly match until newline
    owner_match = re.search(r'\*\*App Owner\*\*\s*([^\n]+)', section)
    
    return {
        'app_name': app_name,
        'content': section,
        'url': url_match.group(1).strip() if url_match else '',
        'owner': owner_match.group(1).strip() if owner_match else ''
    }


def _parse_internal_apps_markdown(file_path: str) -> list[dict]:
    """Parse internal apps markdown file and extract app sections.
    
    Args:
        file_path: Path to the internal_apps_knowledge.md file
        
    Returns:
        List of app metadata dictionaries
    """
    with open(file_path, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Split by '---' delimiter (each app section is between delimiters)
    sections = content.split('---')
    
    apps = []
    for section in sections:
        section = section.strip()
        if not section:
            continue
        
        app_metadata = _extract_app_metadata(section)
        if app_metadata:
            apps.append(app_metadata)
    
    return apps


def index_internal_apps_to_chroma(file_path: str, file_record) -> tuple[bool, str | None]:
    """Index internal_apps_knowledge.md file into ChromaDB.
    
    Args:
        file_path: Path to the internal_apps_knowledge.md file
        file_record: Database record for the file
        
    Returns:
        tuple: (success: bool, description: str | None)
    """
    try:
        # Delete any existing internal_apps chunks to prevent duplicates
        try:
            existing_docs = vectorstore.get(where={"type": "internal_apps"})
            if existing_docs and len(existing_docs['ids']) > 0:
                vectorstore._collection.delete(where={"type": "internal_apps"})
        except Exception:
            pass
        
        # Generate dynamic description using LLM
        description = generate_internal_apps_description(file_path)
        
        # Parse markdown file using helper function
        apps = _parse_internal_apps_markdown(file_path)
        
        if not apps:
            print("No applications found in the markdown file.")
            return False, None
        
        # Create Document objects with proper metadata
        documents = []
        chunk_ids = []
        
        for idx, app in enumerate(apps):
            # Generate deterministic chunk ID
            # Using SHA-256 instead of MD5 for security compliance (non-cryptographic use case)
            content_hash = hashlib.sha256(app['content'].encode()).hexdigest()[:8]
            unique_string = f"internal_app_{app['app_name']}_{idx}_{content_hash}"
            chunk_id = hashlib.sha256(unique_string.encode()).hexdigest()
            chunk_ids.append(chunk_id)
            
            # Create document with metadata for routing
            doc = Document(
                page_content=app['content'],
                metadata={
                    'type': 'internal_apps',
                    'source': 'app_catalog',
                    'app_name': app['app_name'],
                    'app_url': app['url'],
                    'app_owner': app['owner'],
                    'chunk_index': idx,
                    'file_id': file_record.FILE_ID
                }
            )
            documents.append(doc)
        
        # Add documents to ChromaDB
        vectorstore.add_documents(documents=documents, ids=chunk_ids)
        return True, description
        
    except Exception as e:
        print(f"Error indexing internal apps: {e}")
        return False, None