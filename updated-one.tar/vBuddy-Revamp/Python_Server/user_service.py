"""
User management service for CRUD operations on users.
"""
import math
from typing import List, Dict, Optional
from sqlalchemy.orm import Session
from fastapi import HTTPException, status

from db_utils import Users


def add_user_to_db(
    db: Session,
    emp_id: str,
    name: str,
    email: str,
    role: str
) -> Users:
    """
    Add a new user to the database.

    Args:
        db: Database session
        emp_id: Employee ID
        name: User's full name
        email: User's email address
        role: User role (admin/user)

    Returns:
        Created Users object

    Raises:
        HTTPException: If email domain is invalid or user already exists
    """
    # Validate email domain
    if not email.endswith("@vthink.co.in"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid email domain. Only @vthink.co.in emails are allowed."
        )

    # Check if user already exists
    existing_user = db.query(Users).filter(Users.EMAIL == email).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="User already exists with this email."
        )

    # Create new user
    new_user = Users(
        EMP_ID=emp_id,
        NAME=name,
        EMAIL=email,
        ROLE=role,
        IS_ACTIVE=1
    )

    try:
        db.add(new_user)
        db.commit()
        db.refresh(new_user)
        return new_user
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to add user: {str(e)}"
        )


def update_user_in_db(
    db: Session,
    emp_id: str,
    name: Optional[str] = None,
    email: Optional[str] = None,
    role: Optional[str] = None
) -> Users:
    """
    Update user details in the database.

    Args:
        db: Database session
        emp_id: Employee ID of the user to update
        name: New name (optional)
        email: New email (optional)
        role: New role (optional)

    Returns:
        Updated Users object

    Raises:
        HTTPException: If user not found or email already in use
    """
    user = db.query(Users).filter(Users.EMP_ID == emp_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found."
        )

    # Check if email is being updated and if it's already in use
    if email and email != user.EMAIL:
        if not email.endswith("@vthink.co.in"):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid email domain. Only @vthink.co.in emails are allowed."
            )
        existing_user = db.query(Users).filter(Users.EMAIL == email).first()
        if existing_user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email already in use by another user."
            )
        user.EMAIL = email

    # Update fields if provided
    if name:
        user.NAME = name
    if role:
        user.ROLE = role

    try:
        db.commit()
        db.refresh(user)
        return user
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update user: {str(e)}"
        )


def delete_user_from_db(db: Session, emp_id: str) -> Dict[str, str]:
    """
    Delete a user from the database (hard delete).

    Args:
        db: Database session
        emp_id: Employee ID of the user to delete

    Returns:
        Success message

    Raises:
        HTTPException: If user not found
    """
    user = db.query(Users).filter(Users.EMP_ID == emp_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found."
        )

    try:
        db.delete(user)
        db.commit()
        return {"message": "User deleted successfully."}
    except Exception as e:
        db.rollback()
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to delete user: {str(e)}"
        )


def get_all_users_from_db(db: Session) -> List[Users]:
    """
    Get all users from the database.

    Args:
        db: Database session

    Returns:
        List of all Users objects
    """
    try:
        users = db.query(Users).all()
        return users
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve users: {str(e)}"
        )


def get_paginated_users_from_db(db: Session, page: int = 1, page_size: int = 10) -> Dict:
    """
    Get paginated users from the database.

    Args:
        db: Database session
        page: Page number (1-indexed)
        page_size: Number of users per page

    Returns:
        Dict with users, total, page, page_size, total_pages
    """
    try:
        total = db.query(Users).count()
        offset = (page - 1) * page_size
        users = db.query(Users).offset(offset).limit(page_size).all()
        total_pages = math.ceil(total / page_size) if page_size > 0 else 0
        return {
            "users": users,
            "total": total,
            "page": page,
            "page_size": page_size,
            "total_pages": total_pages,
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to retrieve users: {str(e)}"
        )


def check_user_exists_in_db(db: Session, emp_id: str) -> bool:
    """
    Check if a user exists in the database.

    Args:
        db: Database session
        emp_id: Employee ID to check

    Returns:
        True if user exists, False otherwise

    Raises:
        HTTPException: If database operation fails
    """
    if not emp_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="EMP_ID is required."
        )

    try:
        user = db.query(Users).filter(Users.EMP_ID == emp_id).first()
        return user is not None
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to check user existence: {str(e)}"
        )
