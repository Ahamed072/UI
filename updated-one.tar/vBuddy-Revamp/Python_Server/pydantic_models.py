from pydantic import BaseModel, Field, EmailStr, ConfigDict
from enum import Enum
from datetime import datetime
from typing import Optional, List, Union


class ModelName(str, Enum):
    GPT4_O = "gpt-4o"
    GPT4_O_MINI = "gpt-4o-mini"

class QueryInput(BaseModel):
    emp_id: str = Field(..., min_length=1, description="Employee ID")
    session_id: Optional[str] = Field(None, description="Session ID")
    question: str = Field(..., min_length=1, description="User question")
    model: str = Field(..., min_length=1, description="Model name")
    user_name: Optional[str] = Field(None, description="User's name for personalized responses")
    is_web_search: bool = Field(False, description="Whether to use vThink Web RAG")

class SourceInfo(BaseModel):
    """Source document information for citations."""
    file_name: str
    file_id: Optional[Union[int, str]] = None


class WebSourceInfo(BaseModel):
    """Source information for vThink Web search results."""
    url: Optional[str] = None
    site: Optional[str] = None


class QueryResponse(BaseModel):
    answer: str
    session_id: str
    model: ModelName
    sources: Optional[List[SourceInfo]] = None
    web_sources: Optional[List[WebSourceInfo]] = None
    used_document_context: bool = False
    is_web_search: bool = False


class DocumentInfo(BaseModel):
    FILE_ID: int
    FILE_NAME: str
    DESCRIPTION: Optional[str] = None
    UPLOADED_AT: datetime
    UPLOADED_BY: Optional[str] = None
    UPLOADED_BY_NAME: str = "Unknown"

class DeleteFileRequest(BaseModel):
    file_id: int


# ========== Authentication & User Management Models ==========

class LoginRequest(BaseModel):
    """Request model for login endpoint."""
    email: EmailStr


class LoginResponse(BaseModel):
    """Response model for login endpoint."""
    token: str
    role: str
    EMP_ID: str
    NAME: str
    session_id: str
    redirect: str


class LogoutRequest(BaseModel):
    """Request model for logout endpoint."""
    session_id: str


class AddUserRequest(BaseModel):
    """Request model for adding a new user."""
    model_config = ConfigDict(populate_by_name=True)

    emp_id: str = Field(..., min_length=1, alias="EMP_ID", description="Employee ID")
    name: str = Field(..., min_length=1, alias="NAME", description="User's full name")
    email: EmailStr = Field(..., alias="EMAIL", description="User's email address")
    role: str = Field(..., min_length=1, alias="ROLE", description="User role (admin/user)")


class UpdateUserRequest(BaseModel):
    """Request model for updating a user."""
    model_config = ConfigDict(populate_by_name=True)

    name: Optional[str] = Field(None, alias="NAME", description="User's full name")
    email: Optional[EmailStr] = Field(None, alias="EMAIL", description="User's email address")
    role: Optional[str] = Field(None, alias="ROLE", description="User role (admin/user)")


class UserResponse(BaseModel):
    """Response model for user data."""
    EMP_ID: str
    NAME: str
    EMAIL: str
    ROLE: str
    IS_ACTIVE: int

    class Config:
        from_attributes = True


class PaginatedUsersResponse(BaseModel):
    """Paginated response model for user listing."""
    users: list[UserResponse]
    total: int
    page: int
    page_size: int
    total_pages: int