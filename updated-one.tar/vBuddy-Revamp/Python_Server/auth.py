"""
Authentication utilities for JWT token generation and validation.
"""
import os
import uuid
from datetime import datetime, timedelta, timezone
from typing import Optional, Dict, List
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from jose import JWTError, jwt
from dotenv import load_dotenv
from sqlalchemy.orm import Session

from db_utils import get_db, Users

load_dotenv()

# Security configuration
security = HTTPBearer()
JWT_SECRET = os.getenv("JWT_SECRET")
JWT_ALGORITHM = "HS256"
TOKEN_EXPIRATION_HOURS = 8

# Allowed email domain
ALLOWED_EMAIL_DOMAIN = "@vthink.co.in"


def create_jwt_token(emp_id: str, role: str) -> str:
    """
    Generate a JWT token for the user.

    Args:
        emp_id: Employee ID
        role: User role (admin/user)

    Returns:
        JWT token string
    """
    expiration_time = datetime.now(timezone.utc) + timedelta(hours=TOKEN_EXPIRATION_HOURS)
    payload = {
        "EMP_ID": emp_id,
        "role": role,
        "exp": expiration_time,
        "iat": datetime.now(timezone.utc)
    }
    token = jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)
    return token


def verify_jwt_token(token: str) -> Dict[str, any]:
    """
    Verify and decode a JWT token.

    Args:
        token: JWT token string

    Returns:
        Decoded token payload

    Raises:
        HTTPException: If token is invalid or expired
    """
    try:
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        return payload
    except JWTError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Invalid or expired token: {str(e)}"
        )


def validate_email_domain(email: str) -> bool:
    """
    Validate that the email belongs to the allowed domain.

    Args:
        email: Email address to validate

    Returns:
        True if email domain is valid

    Raises:
        HTTPException: If email domain is invalid
    """
    if not email.endswith(ALLOWED_EMAIL_DOMAIN):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid email domain. Only {ALLOWED_EMAIL_DOMAIN} emails are allowed."
        )
    return True


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
) -> Dict[str, any]:
    """
    FastAPI dependency to get the current authenticated user from JWT token.

    Args:
        credentials: HTTP Bearer credentials
        db: Database session

    Returns:
        Dictionary containing user information (emp_id, role)

    Raises:
        HTTPException: If token is invalid, expired, or user not found
    """
    token = credentials.credentials
    payload = verify_jwt_token(token)

    emp_id = payload.get("EMP_ID")
    role = payload.get("role")

    if not emp_id or not role:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid token: Missing EMP_ID or role"
        )

    # Verify user exists in database
    user = db.query(Users).filter(Users.EMP_ID == emp_id).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )

    return {"emp_id": emp_id, "role": role}


def get_current_user_optional(
    credentials: Optional[HTTPAuthorizationCredentials] = Depends(HTTPBearer(auto_error=False)),
    db: Session = Depends(get_db)
) -> Optional[Dict[str, any]]:
    """
    FastAPI dependency to optionally get the current authenticated user.
    Returns None if token is missing or invalid (doesn't raise exception).

    Args:
        credentials: HTTP Bearer credentials (optional)
        db: Database session

    Returns:
        Dictionary containing user information (emp_id, role) or None
    """
    if not credentials:
        return None

    try:
        token = credentials.credentials
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])

        emp_id = payload.get("EMP_ID")
        role = payload.get("role")

        if not emp_id or not role:
            return None

        # Verify user exists in database
        user = db.query(Users).filter(Users.EMP_ID == emp_id).first()
        if not user:
            return None

        return {"emp_id": emp_id, "role": role}
    except Exception:
        return None


def require_role(allowed_roles: List[str]):
    """
    FastAPI dependency factory to check if the user has the required role.

    Args:
        allowed_roles: List of allowed roles (e.g., ['admin'])

    Returns:
        Dependency function that checks user role

    Usage:
        @app.get("/admin-only")
        async def admin_endpoint(current_user = Depends(require_role(["admin"]))):
            ...
    """
    def role_checker(current_user: Dict[str, any] = Depends(get_current_user)) -> Dict[str, any]:
        if current_user["role"] not in allowed_roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access forbidden: Insufficient permissions"
            )
        return current_user
    return role_checker


def generate_session_id() -> str:
    """
    Generate a unique session ID using UUID.

    Returns:
        UUID string
    """
    return str(uuid.uuid4())
