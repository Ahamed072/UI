import difflib
from typing import List, Tuple


def compare_url_lists(
    baseline_urls: List[str], current_urls: List[str]
) -> Tuple[List[str], List[str]]:
    added = []
    removed = []

    diff = difflib.unified_diff(
        baseline_urls,
        current_urls,
        fromfile="baseline",
        tofile="current",
        lineterm="",
    )

    for line in diff:
        if line.startswith("---") or line.startswith("+++") or line.startswith("@@"):
            continue
        if line.startswith("+"):
            added.append(line[1:])
        elif line.startswith("-"):
            removed.append(line[1:])

    return added, removed
