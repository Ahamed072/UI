from typing import List
import requests
from xml.etree import ElementTree

from .config import SITEMAP_NAMESPACE, REQUEST_TIMEOUT


def fetch_sitemap_urls(sitemap_url: str) -> List[str]:
    response = requests.get(sitemap_url, timeout=REQUEST_TIMEOUT)
    response.raise_for_status()
    root = ElementTree.fromstring(response.content)
    urls = [
        loc.text.strip()
        for loc in root.findall(".//ns:loc", SITEMAP_NAMESPACE)
        if loc.text
    ]
    return urls


def filter_urls(urls: List[str], exclude_patterns: List[str]) -> List[str]:
    if not exclude_patterns:
        return sorted(urls)

    filtered = [
        url
        for url in urls
        if not any(pattern in url for pattern in exclude_patterns)
    ]
    return sorted(filtered)
