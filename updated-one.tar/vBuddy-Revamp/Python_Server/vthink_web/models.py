from pydantic import BaseModel, Field
from typing import List, Optional
from enum import Enum


class SiteKey(str, Enum):
    VTHINK_CO_IN = "vthink_co_in"
    VTHINK_AI = "vthink_ai"


class BaselineData(BaseModel):
    site: str
    fetched_at: str
    urls: List[str]


class SiteDiffResult(BaseModel):
    site_label: str
    is_first_run: bool
    baseline_timestamp: Optional[str] = None
    current_url_count: int
    baseline_url_count: Optional[int] = None
    added_urls: List[str] = Field(default_factory=list)
    removed_urls: List[str] = Field(default_factory=list)
    has_changes: bool


class ComparisonResponse(BaseModel):
    compared_at: str
    results: List[SiteDiffResult]
    error_sites: List[dict] = Field(default_factory=list)


class ChatMessage(BaseModel):
    role: str
    content: str


class ChatRequest(BaseModel):
    query: str
    chat_history: List[ChatMessage] = Field(default_factory=list)
    top_k: int = Field(default=5, ge=1, le=20)


class SourceInfo(BaseModel):
    url: Optional[str] = None
    site: Optional[str] = None


class ChatResponse(BaseModel):
    answer: str
    standalone_query: str
    detected_category: List[str]
    sources: List[SourceInfo]
