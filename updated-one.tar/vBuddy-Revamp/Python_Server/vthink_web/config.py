import os

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

BASELINES_DIR = os.path.join(PROJECT_ROOT, "baselines")
CONTENT_HASHES_PATH = os.path.join(BASELINES_DIR, "content_hashes.json")

SITES = {
    "vthink_co_in": {
        "sitemap_url": "https://www.vthink.co.in/sitemap.xml",
        "label": "vthink.co.in",
        "filter_patterns": ["/newsroom", "/blogs", "/author", "/category", "/product-latest", "/project-latest","/customer-stories","/sitemap","/career-detail-latest/","/careers"],
    },
    "vthink_ai": {
        "sitemap_url": "https://www.vthink.ai/sitemap.xml",
        "label": "vthink.ai",
        "filter_patterns": [],
    },
}

SITEMAP_NAMESPACE = {"ns": "http://www.sitemaps.org/schemas/sitemap/0.9"}

REQUEST_TIMEOUT = 30

# Crawler settings
CRAWL_MAX_CONCURRENT = 5

# ChromaDB settings - uses the SHARED chroma_db directory
CHROMA_DB_DIR = os.path.join(PROJECT_ROOT, "chroma_db")
CHROMA_COLLECTION_NAME = "vthink_web_knowledge"
EMBEDDING_MODEL = "sentence-transformers/all-MiniLM-L12-v2"

# LLM settings
OPENAI_MODEL = "gpt-4o-mini"
