
---

### 🔹 Application Name: **VAR (vThink Attendance Report) System**

**Purpose**
The VAR system is used to generate attendance reports for all employees.
These reports include metrics such as:

* Work-from-home days
* Leave records
* Productive working hours
* 9-hour in-office compliance

All metrics are calculated on a **weekly** and **monthly** basis.

**Key Functionality**
HR can download attendance reports for all employees and share them via email with the respective Project Managers.

**App Owner**
HR Department (Human Resources)

**Access URL**
[https://varui.vthinkdeveloper.com/]

**Contact Persons**

* Ramani Periyasamy [ HR ]
* Anand Robertson [HR Manager]
* OMBalakumar N C [Lead Professional]

**Usage Guidelines (Issue Mapping)**

* This application is **used only by HR**
* Not accessible to all employees

---

### 🔹 Application Name: **VAM (vThink Asset Management)**

**Purpose**
VAM serves as the centralized system for **asset maintenance management** and **service ticket creation**, enabling efficient tracking and governance of both hardware and contract assets.

**App Owner**
IT Administration

**Access URL**
[https://vam.vthinkdeveloper.com/#/menu/ticket-list]

**Support Contact**

* Rithikeswar [IT support]
* Thameem Ansari [IT support]
* Gopalakrishna Chinnappan [IT support Lead]

**Usage Guidelines (Issue Mapping)**

**Users**

* Raise service tickets related to hardware
* Raise service tickets for Software Installations
* Track the status of raised tickets

**Administrators**

* Monitor, manage, and maintain all hardware and contract assets
* Assign assets to employees
* Ensure accurate asset ownership and lifecycle management
* Resolve the users who has raised their service Tickets


---

### 🔹 Application Name: **KRA(Key Responsibility Area)**

**Purpose**
Feedback for all employees is provided on a monthly basis by their assigned leads and managers. This application contains multiple goals, which are assigned to employees by their respective leads or managers. For each goal, detailed feedback is provided to the employee. Based on this monthly feedback, an employee’s work performance and adaptability to the company can be evaluated. This feedback also plays a key role in determining employee appraisals.

**Access URL**
[https://kra.vthinkdeveloper.com/]


**Support Contact**
* Baskar Kothandapani [Architect and Lead]
* Nitin Balraj [ Lead ]


**Usage Guidelines (Issue Mapping)**

**Users**

* can view their monthy feedbacks and goals
* can able to comment for the feedback - agree/disagree/others

**Administrators**

* can able to create goals for the employees
* can able to provide feedbacks for the employees
* can track the employees performances

---

### 🔹 Application Name: **vTest**

**Purpose**
vTest can be used to conduct tests for candidates during the recruitment process, as well as to conduct internal tests for employees on various courses or skill sets. The application allows evaluation of scores and automatically notifies users of their results.

**Support Contact**
* Baskar Kothandapani [Architect and Lead]
* Nitin Balraj [ Lead ]

**Access URL**
[https://vtest.vthinkdeveloper.com/]

**Usage Guidelines (Issue Mapping)**

**Users**

* Users are able to take the test, which is primarily based on a multiple-choice (MCQ) format.

**Administrators**

* Admins are able to create and manage test questions for employees.

---

### 🔹 Application Name: **VTA (vThink Talent Aquisation)**

**Purpose**
VTA serves as the centralized system for **HR Operations for Candidates** and **Manage Candidate Operations**, Specifically for Recruiting the candidate end-to-end.

**App Owner**
HR Department (Human Resources)

**Access URL**
[https://vta.vthinkdeveloper.com/Login]

**Support Contact**

* Manikandan Selvaraj [ Professional ]
* Naresh Rajkumar [Senior Associate]
* Ramani Periyasamy [ HR ]


**Usage Guidelines (Issue Mapping)**

**Users(Employees ie. Interviewers)**

* Login users who is interviewer
* Check any interview as scheduled with candidate (teams calendar)
* Fill feedback for candidate after interview

**Administrators(HR ie. Talent Acquisition team)**

* Upload candidates resumes & verify their suitability & personal details from that
* Assign incharge(HR/employee) to specific candidates
* Handle job requirement & posting 
* Schedule the interview & offer & onboard process

---

### 🔹 Application Name: **vBuddy**

**Purpose**
It is a conversational chatbot that can answer queries related to vThink policies as well as general questions about vThink, such as company details, clients, products, and more. Employees can easily learn about vThink without needing to rely on HR or other employees to get their doubts clarified.

**App Owner**
HR Department (Human Resources)

**Access URL**
Not deployed Yet , Still on development

**Support Contact**

* Baskar Kothandapani [Architect and Lead]
* Ahamed Rizwan [ Associate ]
* Prakash Krishnaswamy [ HR ]

**Usage Guidelines (Issue Mapping)**

**Users(Employees)**

* It can handle conversations related to company information and policy-related queries.

**Administrators(HR Employees and Management)**

* can provide company policy documents and other documents as knowledge for the chatbot and manage them as well.
* It can manage users and control who can access the application (user management).


---

### 🔹 Application Name: **HK (House Keeping application)**


**Purpose**
Housekeeping Application is to efficiently manage and track housekeeping tasks, employees, and approvals by providing a role-based system.

**App Owner**
Admin Department

**Access URL**
Not deployed Yet , Still on development

**Support Contact**
 
* OMBalakumar N C [Senior  Professional ]
* Sakthivel AmirthaGanesan[Senior Professional ]
* Duke [ Admin Manager ]

**Users**
* Logs in using QR code
* Sees only today’s assigned tasks
* Completes the task
* Uploads photo as proof
* Submits the task for approval

**Managers**
* Sees tasks submitted by their team
* Checks uploaded photos
* Approves the task if correct
* Rejects with comments if not correct
* Can reassign tasks if needed

---

### 🔹 Application Name: **Cab Roster**
 
**Purpose**
Cab Roster serves as the centralized system for **Manage Cab Service Operations**, Specifically for vThink professionals end-to-end.
 
**App Owner**
Admin Department (Admin Operations)
 
**Access URL**
Not deployed Yet , Still on development
 
**Support Contact**
 
* Duke Kamal [Admin Manager]
 
 
**Usage Guidelines (Issue Mapping)**
 
**Users(Employees)**
* Login users who works in vthink company
* Subscribe and use cab services
 
**Administrators(Admin ie. Admin Operations team)**
* Verifies Cab service requests
* Manages cab service operations

---
