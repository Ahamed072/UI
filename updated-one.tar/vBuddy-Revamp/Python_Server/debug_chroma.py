from chroma_utils import vectorstore

# Check if any documents exist in ChromaDB
docs = vectorstore.get()
print(f"Total Indexed Documents: {len(docs['ids'])}")

# Manually search for POSH Policy-related documents
query = "POSH policy"
retrieved_docs = vectorstore.similarity_search(query, k=2)

print("\n🔍 Retrieved Documents:")
for doc in retrieved_docs:
    print(f"Content: {doc.page_content[:200]}...\n")  # Print first 200 characters
