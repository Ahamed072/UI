from langchain_openai import ChatOpenAI
from langchain_core.output_parsers import JsonOutputParser
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_classic.chains import create_retrieval_chain
from langchain_classic.chains.combine_documents import create_stuff_documents_chain
from typing import List, Any, Optional, Dict, Tuple
from langchain_core.documents import Document
from langchain_core.retrievers import BaseRetriever
from langchain_core.callbacks import CallbackManagerForRetrieverRun
from pydantic import Field
import os
import re
from dotenv import load_dotenv
from sqlalchemy.orm import Session

from db_utils import DocumentStore
from chroma_utils import vectorstore

load_dotenv()
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

# Maximum number of conversations to send to LLMs
MAX_CONVERSATIONS_HISTORY = 10


def truncate_chat_history(chat_history: List, max_conversations: int = MAX_CONVERSATIONS_HISTORY) -> List:
    """
    Truncate chat history to the last N conversations.
    A conversation consists of a human message followed by an AI message.

    Args:
        chat_history: Full chat history list
        max_conversations: Maximum number of conversations to keep (default: 10)

    Returns:
        Truncated chat history with last N conversations
    """
    if not chat_history:
        return []

    # Each conversation = 2 messages (human + ai), so we need max_conversations * 2 messages
    max_messages = max_conversations * 2

    # Return last N messages
    return chat_history[-max_messages:] if len(chat_history) > max_messages else chat_history


# Contextual question reformulation, identify relevant docs, and determine query type prompt
query_context_analyzer_prompt = (
    "Given a chat history and the latest user question, perform the following tasks:\n\n"

     "1. REFORMULATE: If the question references context from the chat history, "
    "formulate a standalone question that can be understood without the chat history. "
    "**CRITICAL: Strip all company references (e.g., 'vThink', 'our company'), question starters (e.g., 'Who are', 'What is', 'Tell me about'), and filler words.** "
    "Return only the core subject keywords (4-8 words maximum) optimized for search. "
    "Do NOT answer the question - just reformulate it if needed, otherwise return it as is. "
    "Always prioritize retrieving relevant context first before relying on chat history.\n\n"
    
    "EXAMPLES OF TRANSFORMATION:\n"
    "User Query: 'Who are members of disciplinary committee at vThink?' -> Search Query: 'disciplinary committee members list'\n"
    "User Query: 'What is the dress code policy for vThink global technologies?' -> Search Query: 'dress code policy'\n"
    "User Query: 'Tell me about the leave policy at our company' -> Search Query: 'leave policy'\n"
    "User Query: 'Who all are the members of disciplinary committee and POSH committee at vThink Global Technologies?' -> Search Query: 'disciplinary committee and POSH committee members'\n"
    "User Query 'How to Raise a Ticket in VAM and give me the KRA link to access the app ?' -> Search Query: 'Raise a ticket in VAM , KRA link'\n\n"

    "2. IDENTIFY RELEVANT FILES: Analyze which documents from the available list are most relevant "
    "to answering the question.\n\n"
    "3. DETERMINE QUERY TYPE: Classify the user's question into one of the following types:\n"
    "   - 'policy': Questions about company policies, rules, regulations, HR guidelines, leave policies, policy links "
    "work-from-home policies, code of conduct, compliance, benefits, etc. These are answered from policy documents.\n"
    "   - 'internal_apps': {internal_apps_description}\n"
    "Available documents in the system (POLICY DOCUMENTS):\n"
    "{document_list}\n\n"
    "CRITICAL: You MUST return ONLY a valid JSON response in this exact format with no additional text:\n"
    '{{{{"standalone_question": "the reformulated or original question here", "relevant_files": [file_id_1, file_id_2], "type": "policy" | "internal_apps" | "general"}}}}\n\n'

    "IMPORTANT RULES:\n"
    "- If the question is about internal apps or their functionalities, set type='internal_apps' and relevant_files=[]\n"
    
    "- **DOMAIN PRIORITY RULE (CRITICAL):** If the query explicitly mentions a specific policy name (e.g., 'POSH', 'Leave', 'Attendance', 'WFH') or App name (e.g., 'VAR', 'VAM'), you MUST classify it as 'policy' or 'internal_apps' respectively.\n"
    "  - Do NOT classify as 'general' just because the user is asking for specific details like 'email', 'phone number', 'contact', 'link', or 'form'.\n"
    "  - Even if you are unsure the document contains the specific detail, you must still route to the domain so the retrieval system can search for it.\n\n"

    "- **CRITICAL EXCEPTION**: Requests for policy links, PDFs, or documents (e.g., 'POSH policy link', 'leave policy PDF') remain classified as policy, not internal_apps. Only app system URLs (VAR, VAM,KRA, etc.) qualify as internal_apps"
    "-When a specific policy name is mentioned (POSH, Travel, Dress Code, etc.), return ONLY that exact file ID."
    "- If the question is a greeting or about your identity, set type='general' and relevant_files=[]\n"
    "- - Requests for contact information (emails, phone numbers) documented in available files (e.g., HR email, Accounts email, IT support contact) MUST be classified as 'policy' with relevant file IDs identified, NOT 'general'."
    "If the question is relevant/even related to policies or internal products or about vthink then do not consider it as general\n"
    "- Return ONLY the JSON object. Do NOT include any explanation, markdown formatting, or text before or after the JSON."
)

qa_prompt = ChatPromptTemplate.from_messages([
    ("system", """You are a domain-specific AI assistant for vThink Global Technologies.

The user you are talking to is named {user_name}. You may greet them by name and personalize responses accordingly.

AVAILABLE KNOWLEDGE BASE:
📋 Policy Documents Available: {policy_names_list}
📱 Internal Applications Available: {internal_apps_list}

CORE IDENTITY & IDENTITY PROTOCOL:
- If asked about your identity (e.g., 'who are you'), respond that you are a domain-specific AI assistant for vThink Global Technologies
- You may greet users politely and address them by name when provided
- You can Answer on Company related Queries like policies , Internal apps , Contacts , Company Info but not personal advice, or casual chat.

CRITICAL RULE - NO HALLUCINATION:
- If the context says "NO INTERNAL APPS DATA AVAILABLE" or "NO POLICY DOCUMENTS AVAILABLE" or "NO CONTEXT AVAILABLE", you MUST immediately respond that you don't have that information
- NEVER make up or invent information when the knowledge base is empty
- Do NOT use your general knowledge to answer when context explicitly says data is unavailable
- Be honest about lack of information rather than guessing

RESPONSE GUIDELINES:
1. Use the provided context to answer questions about vThink Global Technologies
2. The context may contain either POLICY DOCUMENTS or INTERNAL APPS information:
   - Policy documents: Marked with [FROM FILE: filename.pdf/docx]
   - Internal apps: Marked with [FROM INTERNAL APP: AppName]
3. If the context contains ANY relevant information, provide a helpful answer
4. If partial information is found, share what's available and mention what's missing
5. For follow-up questions, use chat history to understand context
6. If the user asks something vague like "position?" or "details?", clarify what they mean OR use chat history context
7. Always provide a clear answer for the user
8. When asked about "list of policies" or "what policies are available" or knowledges that you have on internal policies like that, use the Policy Documents Available list above
9. When asked about "list of internal apps" or "what apps are available" or knowledges that you have on internal apps like that, use the Internal Applications Available list above
10. If the user asks for any policy document link , always give this as for all policy Links -> https://vthinktechnologies.greythr.com/v3/portal/ess/documents-view/company-policies'

INTERNAL APPS CONTEXT:
When answering questions about internal applications (VAR, VAM,VTA,KRA,etc), provide:
- answer correctly based on the provided context , if you dont find relevant answers on the context then say that you dont have that information


RESTRICTIONS:
- Do NOT provide general knowledge, mathematical expressions, or language-related queries
- Only answer questions related to vThink Global Technologies based on the provided context
- If the question is outside the provided context AND no relevant information is found, respond conversationally with varied phrases like: "I don't have information about that in the current documents", "That topic isn't covered in my knowledge base", "I couldn't find relevant details on that", etc. Rotate your responses to avoid repetition.


IMPORTANT: Be helpful within your domain, not restrictive. Partial answers are better than no answers when context is available."""),
    ("system", "Context: {context}"),
    MessagesPlaceholder(variable_name="chat_history"),
    ("human", "{input}")
])


# Custom retriever with proper Pydantic fields
class MetadataAwareRetriever(BaseRetriever):
    llm: Any = Field(description="Language model")
    vectorstore: Any = Field(description="Vector store")
    document_summary: str = Field(description="Summary of available documents")
    contextualize_prompt: Any = Field(description="Prompt template for contextualization")
    chat_history: List = Field(default_factory=list, description="Chat history")
    retrieved_sources: Dict = Field(default_factory=dict, description="Retrieved source metadata")
    query_type: str = Field(default="policy", description="Type of query: policy, internal_apps, or general")
    
    class Config:
        arbitrary_types_allowed = True
    
    def _parse_query_with_llm(self, query: str) -> tuple[str, list, str]:
        """Parse query using LLM to extract standalone question, relevant files, and query type.
        
        Args:
            query: User's original query
            
        Returns:
            tuple: (standalone_question, relevant_files, query_type)
        """
        chain = self.contextualize_prompt | self.llm | JsonOutputParser()
        truncated_history = truncate_chat_history(self.chat_history)
        
        try:
            parsed = chain.invoke({
                "input": query,
                "chat_history": truncated_history,
                "document_list": self.document_summary
            })
            
            standalone_question = parsed.get("standalone_question", query)
            relevant_files = parsed.get("relevant_files", [])
            query_type = parsed.get("type", "policy")
            
            print("standalone_question", standalone_question)
            print("query_type", query_type)
            
            return standalone_question, relevant_files, query_type
            
        except Exception as e:
            print(f"Error on Retriever: {e}")
            return query, [], "policy"
    
    def _retrieve_documents_by_type(self, query_type: str, standalone_question: str, relevant_files: list) -> List[Document]:
        """Retrieve documents from vectorstore based on query type.
        
        Args:
            query_type: Type of query (general, internal_apps, policy)
            standalone_question: Reformulated question for search
            relevant_files: List of relevant file IDs
            
        Returns:
            List of retrieved documents
        """
        if query_type == "general":
            return [Document(page_content="This is a general conversational query. No document context needed.")]
        
        if query_type == "internal_apps":
            filter_condition = {"type": "internal_apps"}
            return self.vectorstore.similarity_search(standalone_question, k=5, filter=filter_condition)
        
        # policy type
        if relevant_files:
            filter_condition = {
                "$and": [
                    {"type": "policy"},
                    {"file_id": {"$in": relevant_files}}
                ]
            }
            return self.vectorstore.similarity_search(standalone_question, k=10, filter=filter_condition)
        else:
            filter_condition = {"type": "policy"}
            return self.vectorstore.similarity_search(standalone_question, k=8, filter=filter_condition)
    
    def _extract_sources_from_docs(self, docs: List[Document], query_type: str) -> None:
        """Extract and store unique sources from retrieved documents.
        
        Args:
            docs: List of retrieved documents
            query_type: Type of query (internal_apps or policy)
        """
        self.retrieved_sources = {}
        
        for doc in docs:
            if query_type == "internal_apps":
                app_name = doc.metadata.get('app_name')
                if app_name and app_name not in self.retrieved_sources:
                    self.retrieved_sources[app_name] = {
                        'file_name': app_name,
                        'file_id': doc.metadata.get('app_url', 'internal_app'),
                        'type': 'internal_apps'
                    }
            else:
                file_id = doc.metadata.get('file_id')
                file_name = doc.metadata.get('file_name')
                if file_id and file_name and file_id not in self.retrieved_sources:
                    self.retrieved_sources[file_id] = {
                        'file_name': file_name,
                        'file_id': file_id,
                        'type': 'policy'
                    }
    
    def _add_source_markers(self, docs: List[Document], query_type: str) -> List[Document]:
        """Add source markers to document content for LLM context.
        
        Args:
            docs: List of documents to modify
            query_type: Type of query (internal_apps or policy)
            
        Returns:
            List of documents with source markers added
        """
        modified_docs = []
        
        for doc in docs:
            if query_type == "internal_apps":
                app_name = doc.metadata.get('app_name', 'Unknown App')
                modified_content = f"[FROM INTERNAL APP: {app_name}]\n{doc.page_content}"
            else:
                file_name = doc.metadata.get('file_name', 'Unknown')
                modified_content = f"[FROM FILE: {file_name}]\n{doc.page_content}"
            
            modified_docs.append(Document(page_content=modified_content, metadata=doc.metadata))
        
        return modified_docs
    
    def _get_empty_context_message(self, query_type: str) -> str:
        """Get appropriate empty context message based on query type.
        
        Args:
            query_type: Type of query (general, internal_apps, policy)
            
        Returns:
            Empty context message string
        """
        if query_type == "internal_apps":
            return "NO INTERNAL APPS DATA AVAILABLE. The knowledge base for internal applications is currently empty. You MUST respond that you don't have information about internal apps."
        elif query_type == "policy":
            return "NO POLICY DOCUMENTS AVAILABLE. The document repository is currently empty. You MUST respond that you don't have information about company policies."
        else:
            return "NO CONTEXT AVAILABLE. The knowledge base is empty."
    
    def _get_relevant_documents(
        self,
        query: str,
        *,
        run_manager: Optional[CallbackManagerForRetrieverRun] = None
    ) -> List[Document]:
        """Get relevant documents for a query with reduced cognitive complexity."""
        # Parse query with LLM
        standalone_question, relevant_files, query_type = self._parse_query_with_llm(query)
        self.query_type = query_type
        
        # Retrieve documents based on query type
        docs = self._retrieve_documents_by_type(query_type, standalone_question, relevant_files)
        
        # Handle general queries (no further processing needed)
        if query_type == "general":
            return docs
        
        # Extract sources from retrieved documents
        self._extract_sources_from_docs(docs, query_type)
        
        # Add source markers to documents
        modified_docs = self._add_source_markers(docs, query_type)
        
        # Handle empty results
        if not modified_docs:
            empty_context = self._get_empty_context_message(query_type)
            return [Document(page_content=empty_context)]
        
        # Debug output
        print(f"\n📄 DOCUMENTS SENT TO FINAL LLM:\n{'-'*50}\n" + "\n\n".join([doc.page_content for doc in modified_docs]) + f"\n{'-'*50}\n")
        return modified_docs


def get_unique_sources_string(sources: Dict) -> str:
    """Format unique sources as a string for the prompt"""
    if not sources:
        return "No source documents available."
    return "\n".join([f"- {info['file_name']}" for info in sources.values()])


def get_available_documents_summary(db: Session) -> str:
    """Fetch policy documents (PDF/DOCX) with ID, name, and description for LLM context."""
    docs = db.query(DocumentStore).filter_by(IS_DELETED=False).all()
    policy_docs = [doc for doc in docs if doc.FILE_TYPE.lower() in ['.pdf', '.docx']]
    return "\n".join([
        f"- File ID: {doc.FILE_ID}, Name: {doc.FILE_NAME}, Description: {doc.DESCRIPTION or 'No description'}"
        for doc in policy_docs
    ])


def get_internal_apps_description(db: Session) -> str:
    """Fetch the dynamic internal apps description from the database."""
    fallback = ("Questions about vThink's internal applications/tools/systems including: "
                "VAR (attendance reports), VAM (asset management), KRA (employee feedback), "
                "vTest (recruitment tests), VTA (talent acquisition)")
    try:
        internal_apps_doc = db.query(DocumentStore).filter_by(
            FILE_NAME="internal_apps_knowledge.md",
            IS_DELETED=False
        ).first()
        
        if internal_apps_doc and internal_apps_doc.DESCRIPTION:
            return internal_apps_doc.DESCRIPTION
        return fallback
    except Exception:
        return fallback


def get_policy_names_list() -> str:
    """Fetch all unique policy document names from ChromaDB."""
    try:
        result = vectorstore.get(where={"type": "policy"})
        if result and result['metadatas']:
            policy_names = set()
            for metadata in result['metadatas']:
                if 'file_name' in metadata:
                    policy_names.add(metadata['file_name'])
            
            if policy_names:
                return ", ".join(sorted(policy_names))
        return "No policy documents available"
    except Exception as e:
        print(f"Error fetching policy names: {e}")
        return "No policy documents available"


def get_internal_apps_names_list() -> str:
    """Fetch all unique internal app names from ChromaDB."""
    try:
        result = vectorstore.get(where={"type": "internal_apps"})
        if result and result['metadatas']:
            app_names = set()
            for metadata in result['metadatas']:
                if 'app_name' in metadata:
                    app_names.add(metadata['app_name'])
            
            if app_names:
                return ", ".join(sorted(app_names))
        return "No internal apps available"
    except Exception as e:
        print(f"Error fetching internal app names: {e}")
        return "No internal apps available"


def get_rag_chain_with_sources(model="", db_session=None, chat_history=[], user_name="User"):
    """Create RAG chain that tracks and returns source information."""
    llm = ChatOpenAI(model=model, openai_api_key=OPENAI_API_KEY)
    llm_for_json = ChatOpenAI(
        model=model,
        openai_api_key=OPENAI_API_KEY,
        model_kwargs={"response_format": {"type": "json_object"}},
        temperature=0
    )

    document_summary = get_available_documents_summary(db_session)
    internal_apps_desc = get_internal_apps_description(db_session)
    internal_apps_desc_escaped = internal_apps_desc.replace("{", "{{").replace("}", "}}")

    dynamic_prompt = query_context_analyzer_prompt.format(
        internal_apps_description=internal_apps_desc_escaped,
        document_list="{document_list}"
    )

    contextualize_q_prompt_dynamic = ChatPromptTemplate.from_messages([
        ("system", dynamic_prompt),
        MessagesPlaceholder("chat_history"),
        ("human", "{input}"),
    ])

    # Print the complete prompt with substituted values
    print("\n" + "="*100)
    print("📝 QUERY CONTEXT ANALYZER PROMPT (WITH SUBSTITUTED VALUES)")
    print("="*100)
    print(dynamic_prompt.replace("{document_list}", document_summary))
    print("="*100 + "\n")

    # Truncate chat history for both intermediate and final LLM (last 10 conversations)
    truncated_history = truncate_chat_history(chat_history)
    print(f"📊 Chat History: Original length={len(chat_history)} messages, Truncated to={len(truncated_history)} messages (last {MAX_CONVERSATIONS_HISTORY} conversations)")

    metadata_retriever = MetadataAwareRetriever(
        llm=llm_for_json,
        vectorstore=vectorstore,
        document_summary=document_summary,
        contextualize_prompt=contextualize_q_prompt_dynamic,
        chat_history=truncated_history  # Pass truncated history to retriever
    )

    # Fetch dynamic lists for final LLM
    policy_names = get_policy_names_list()
    internal_apps_names = get_internal_apps_names_list()

    # Inject dynamic lists into qa_prompt
    qa_prompt_with_context = qa_prompt.partial(
        user_name=user_name,
        policy_names_list=policy_names,
        internal_apps_list=internal_apps_names
    )

    question_answer_chain = create_stuff_documents_chain(llm, qa_prompt_with_context)
    rag_chain = create_retrieval_chain(metadata_retriever, question_answer_chain)

    return rag_chain, metadata_retriever