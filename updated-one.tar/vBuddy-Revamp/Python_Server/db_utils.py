from sqlalchemy import create_engine, Column, Integer, String, JSON, TIMESTAMP, ForeignKey, exists, Text, Boolean, text, DateTime
from sqlalchemy.orm import sessionmaker, declarative_base, Session
import os
import json
from datetime import datetime, timezone
from dotenv import load_dotenv

load_dotenv()

DB_URL = f"mysql+mysqlconnector://{os.getenv('DB_USER')}:{os.getenv('DB_PASSWORD')}@{os.getenv('DB_HOST')}/{os.getenv('DB_NAME')}"

engine = create_engine(DB_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine)
Base = declarative_base()


class Users(Base):
    __tablename__ = "users"
    
    EMP_ID = Column(String(50), primary_key=True)
    NAME = Column(String(255), nullable=False)
    EMAIL = Column(String(255), nullable=False, unique=True)
    ROLE = Column(String(50), nullable=False)
    IS_ACTIVE = Column(Integer, default=1)

class ChatSessions(Base):
    __tablename__ = "Chat_Sessions"
    
    SESSION_ID = Column(String(255), nullable=False, primary_key=True)
    EMP_ID = Column(String(255), ForeignKey("users.EMP_ID"), nullable=False)
    CONVERSATION = Column(JSON, nullable=False)
    CREATED_AT = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"))
    UPDATED_AT = Column(TIMESTAMP, server_default=text("CURRENT_TIMESTAMP"), onupdate=text("CURRENT_TIMESTAMP"))
    IS_DELETED = Column(Boolean, server_default="0")
    DELETED_AT = Column(TIMESTAMP, nullable=True)



class DocumentStore(Base):
    __tablename__ = "Document_Store"

    FILE_ID = Column(Integer, primary_key=True, autoincrement=True)
    FILE_NAME = Column(String(255), nullable=False)
    DESCRIPTION = Column(Text, nullable=True)
    FILE_TYPE = Column(String(50), nullable=False)
    UPLOADED_AT = Column(TIMESTAMP, server_default="CURRENT_TIMESTAMP")
    UPLOADED_BY = Column(String(100), nullable=True)
    IS_DELETED = Column(Boolean, server_default="0")
    DELETED_AT = Column(TIMESTAMP, nullable=True)
    DELETED_BY = Column(String(100), nullable=True)


class Sessions(Base):
    """Session model for JWT token management."""
    __tablename__ = "Sessions"

    SESSION_ID = Column(String(255), primary_key=True)
    EMP_ID = Column(String(255), ForeignKey("users.EMP_ID"))
    expiresAt = Column(DateTime, nullable=True)
    createdAt = Column(DateTime, nullable=False)
    updatedAt = Column(DateTime, nullable=False)
    JWT_TOKEN = Column(String(512), nullable=True)
    is_deleted = Column(Boolean, nullable=True)

def init_db():
    Base.metadata.create_all(engine)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def insert_chat_message(db: Session, emp_id, session_id, user_query, gpt_response, sources=None):
    """
    Insert chat message with optional sources.
    """
    user_exists = db.query(Users).filter(Users.EMP_ID == emp_id).first()

    if not user_exists:
        raise ValueError(f"User with EMP_ID {emp_id} does not exist in Users table.")

    log_entry = db.query(ChatSessions).filter_by(SESSION_ID=session_id).first()

    ai_message = {"role": "ai", "content": gpt_response}
    if sources:
        ai_message["sources"] = sources

    if log_entry:
        conversation = json.loads(log_entry.CONVERSATION) if log_entry.CONVERSATION else []
        conversation.append({"role": "human", "content": user_query})
        conversation.append(ai_message)
        log_entry.CONVERSATION = json.dumps(conversation)
    else:
        conversation = [{"role": "human", "content": user_query}, ai_message]
        new_log = ChatSessions(EMP_ID=emp_id, SESSION_ID=session_id, CONVERSATION=json.dumps(conversation))
        db.add(new_log)

    try:
        db.commit()
    except Exception as e:
        db.rollback()
        raise ValueError(f"Failed to insert chat message: {str(e)}")


def get_chat_history(db: Session, session_id):
    log_entry = db.query(ChatSessions).filter_by(SESSION_ID=session_id).first()
    return json.loads(log_entry.CONVERSATION) if log_entry and log_entry.CONVERSATION else []


def get_all_documents(db: Session):
    documents = db.query(
        DocumentStore.FILE_ID,
        DocumentStore.FILE_NAME,
        DocumentStore.UPLOADED_AT,
        DocumentStore.UPLOADED_BY,
        Users.NAME.label('UPLOADED_BY_NAME')
    ).outerjoin(
        Users, DocumentStore.UPLOADED_BY == Users.EMP_ID
    ).filter(
        DocumentStore.IS_DELETED == False
    ).order_by(
        DocumentStore.UPLOADED_AT.desc()
    ).all()
    
    return [
        {
            "FILE_ID": doc.FILE_ID,
            "FILE_NAME": doc.FILE_NAME,
            "UPLOADED_AT": doc.UPLOADED_AT,
            "UPLOADED_BY": doc.UPLOADED_BY,
            "UPLOADED_BY_NAME": doc.UPLOADED_BY_NAME if doc.UPLOADED_BY_NAME else "Unknown"
        } for doc in documents
    ]


def insert_document_record(db: Session, file_name: str, file_extension: str, uploaded_by: str = None, description: str = None):
    new_doc = DocumentStore(
        FILE_NAME=file_name,
        FILE_TYPE=file_extension,
        UPLOADED_BY=uploaded_by,
        DESCRIPTION=description  # Optional pre-set description
    )
    db.add(new_doc)
    db.commit()
    db.refresh(new_doc)
    return new_doc


def delete_document_record(db: Session, file_id: int) -> bool:
    doc = db.query(DocumentStore).filter_by(FILE_ID=file_id).first()
    if doc:
        db.delete(doc)
        db.commit()
        return True
    return False

def update_document_record(db: Session, file_id: int, file_name: str = None, file_description: str = None) -> bool:
    """Update document record in the database."""
    doc = db.query(DocumentStore).filter_by(FILE_ID=file_id).first()
    
    if doc:
        if file_name is not None:
            doc.FILE_NAME = file_name
        if file_description is not None:
            doc.DESCRIPTION = file_description
        
        try:
            db.commit()
            db.refresh(doc)
            return True
        except Exception as e:
            db.rollback()
            raise ValueError(f"Failed to update document: {str(e)}")
    
    return False


def soft_delete_chat_session(db: Session, session_id):
    """Soft delete a chat session when user logs out."""
    try:
        chat_session = db.query(ChatSessions).filter_by(SESSION_ID=session_id).first()
        if chat_session:
            chat_session.IS_DELETED = True
            chat_session.DELETED_AT = text("CURRENT_TIMESTAMP")
            db.commit()
            return True
        return False
    except Exception as e:
        db.rollback()
        raise ValueError(f"Failed to soft delete chat session: {str(e)}")


def create_session(db: Session, emp_id: str, session_id: str, jwt_token: str) -> Sessions:
    """
    Create a new session in the Sessions table.

    Args:
        db: Database session
        emp_id: Employee ID
        session_id: Unique session ID (UUID)
        jwt_token: JWT token for the session

    Returns:
        Created Sessions object

    Raises:
        ValueError: If session creation fails
    """
    try:
        now = datetime.now(timezone.utc)
        new_session = Sessions(
            SESSION_ID=session_id,
            EMP_ID=emp_id,
            JWT_TOKEN=jwt_token,
            createdAt=now,
            updatedAt=now,
            is_deleted=False
        )
        db.add(new_session)
        db.commit()
        db.refresh(new_session)
        return new_session
    except Exception as e:
        db.rollback()
        raise ValueError(f"Failed to create session: {str(e)}")


def delete_session_by_emp_id(db: Session, emp_id: str) -> bool:
    """
    Delete session(s) by employee ID.

    Args:
        db: Database session
        emp_id: Employee ID

    Returns:
        True if session was deleted, False otherwise
    """
    try:
        # Handle NULL and False values for is_deleted
        deleted_count = db.query(Sessions).filter(
            Sessions.EMP_ID == emp_id,
            (Sessions.is_deleted == False) | (Sessions.is_deleted == None)
        ).delete()
        db.commit()
        return deleted_count > 0
    except Exception as e:
        db.rollback()
        raise ValueError(f"Failed to delete session: {str(e)}")


def delete_session_by_session_id(db: Session, session_id: str) -> bool:
    """
    Delete session by session ID.

    Args:
        db: Database session
        session_id: Session ID

    Returns:
        True if session was deleted, False otherwise
    """
    try:
        # Handle NULL and False values for is_deleted
        deleted_count = db.query(Sessions).filter(
            Sessions.SESSION_ID == session_id,
            (Sessions.is_deleted == False) | (Sessions.is_deleted == None)
        ).delete()
        db.commit()
        return deleted_count > 0
    except Exception as e:
        db.rollback()
        raise ValueError(f"Failed to delete session: {str(e)}")
