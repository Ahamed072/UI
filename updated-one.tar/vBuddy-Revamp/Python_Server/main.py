from fastapi import FastAPI, File, UploadFile, HTTPException, Depends, Form, Request, Query, status
from fastapi.middleware.cors import CORSMiddleware
from typing import Optional
import os
import uuid
import logging
import aiofiles
from sqlalchemy.orm import Session
from dotenv import load_dotenv
from pydantic_models import (
    QueryInput, QueryResponse, DocumentInfo, DeleteFileRequest,
    LoginRequest, LoginResponse, LogoutRequest, AddUserRequest,
    UpdateUserRequest, UserResponse, PaginatedUsersResponse,
    WebSourceInfo
)
from langchain_utils import get_rag_chain_with_sources, truncate_chat_history
from chroma_utils import index_document_to_chroma, delete_doc_from_chroma, vectorstore
from vthink_web.rag import rag_pipeline as web_rag_pipeline
from vthink_web.sync_service import sync_all_sites
from db_utils import (
    get_db, insert_chat_message, get_chat_history, get_all_documents,
    insert_document_record, delete_document_record, update_document_record,
    soft_delete_chat_session, DocumentStore, create_session, delete_session_by_emp_id,
    delete_session_by_session_id, Users
)
from auth import (
    create_jwt_token, validate_email_domain, get_current_user,
    get_current_user_optional, require_role, generate_session_id
)
from user_service import (
    add_user_to_db, update_user_in_db, delete_user_from_db,
    get_all_users_from_db, get_paginated_users_from_db, check_user_exists_in_db
)

# Constants
INTERNAL_APPS_KNOWLEDGE_FILE = "internal_apps_knowledge.md"
ALLOWED_FILE_EXTENSIONS = ['.pdf', '.docx', '.md']
DEFAULT_UPLOADER = 'VT308'

def normalize_uploaded_filename(filename: str) -> str:
    """Normalize filename to prevent duplicate extensions (e.g., 'doc.pdf.pdf' -> 'doc.pdf')"""
    if filename.endswith('.pdf.pdf'):
        return filename[:-4]
    if filename.endswith('.docx.docx'):
        return filename[:-5]
    return filename


load_dotenv()

app = FastAPI()

# Allow both production and local development URLs
frontend_url = os.getenv("FRONTEND_URL", "http://localhost:4200")
allowed_origins = [
    frontend_url,
    "http://localhost:4200",
    "http://127.0.0.1:4200",
    "https://vbubby-qa.vthinkglobal.com"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _convert_chat_history_for_web(chat_history: list) -> list:
    """Convert LangChain-style chat history to simple dict format for vThink-Web RAG."""
    converted = []
    for msg in chat_history:
        if hasattr(msg, 'type'):
            role = "user" if msg.type == "human" else "assistant"
            converted.append({"role": role, "content": msg.content})
        elif isinstance(msg, dict):
            role = "user" if msg.get("role") == "human" else "assistant"
            converted.append({"role": role, "content": msg.get("content", "")})
    return converted


@app.post("/chat", response_model=QueryResponse)
async def chat(
    query_input: QueryInput,
    request: Request,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):

    request_data = await request.json()
    print(f"Incoming Request Data: {request_data}")

    session_id = query_input.session_id or str(uuid.uuid4())
    emp_id = query_input.emp_id
    user_name = query_input.user_name or "User"

    logging.info(f"Chat request | Session: {session_id}, User: {emp_id}, "
                 f"Query: {query_input.question}, WebSearch: {query_input.is_web_search}")

    if query_input.is_web_search:
        # --- vThink Web RAG Pipeline ---
        chat_history = get_chat_history(db, session_id)
        web_chat_history = _convert_chat_history_for_web(chat_history)

        result = web_rag_pipeline(
            query=query_input.question,
            chat_history=web_chat_history,
        )

        raw_answer = result["answer"]
        web_sources = result.get("sources", [])

        insert_chat_message(
            db=db,
            emp_id=emp_id,
            session_id=session_id,
            user_query=query_input.question,
            gpt_response=raw_answer,
            sources=None
        )

        return QueryResponse(
            answer=raw_answer,
            session_id=session_id,
            model=query_input.model,
            sources=None,
            web_sources=[WebSourceInfo(url=s.get("url"), site=s.get("site")) for s in web_sources],
            used_document_context=bool(web_sources),
            is_web_search=True,
        )

    else:
        # --- Existing Policy RAG Pipeline (unchanged) ---
        chat_history = get_chat_history(db, session_id)

        rag_chain, metadata_retriever = get_rag_chain_with_sources(query_input.model, db, chat_history, user_name)

        # Truncate chat history to last 10 conversations for final LLM
        truncated_history = truncate_chat_history(chat_history)

        result = rag_chain.invoke({
            "input": query_input.question,
            "chat_history": truncated_history
        })

        raw_answer = result['answer']
        retrieved_sources = metadata_retriever.retrieved_sources
        sources = list(retrieved_sources.values())
        query_type = metadata_retriever.query_type

        used_context = bool(sources)
        if query_type != 'policy':
            sources = []

        insert_chat_message(
            db=db,
            emp_id=emp_id,
            session_id=session_id,
            user_query=query_input.question,
            gpt_response=raw_answer,
            sources=sources if query_type == 'policy' and sources else None
        )

        return QueryResponse(
            answer=raw_answer,
            session_id=session_id,
            model=query_input.model,
            sources=sources,
            web_sources=None,
            used_document_context=used_context,
            is_web_search=False,
        )




@app.post("/upload-doc")
async def upload_and_index_document(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(["admin"]))
):
    normalized_filename = normalize_uploaded_filename(file.filename)
    file_extension = os.path.splitext(normalized_filename)[1].lower()
    
    if file_extension not in ALLOWED_FILE_EXTENSIONS:
        raise HTTPException(status_code=400, detail=f"Unsupported file type. Allowed: {', '.join(ALLOWED_FILE_EXTENSIONS)}")
    
    is_internal_apps_md = (normalized_filename == INTERNAL_APPS_KNOWLEDGE_FILE)
    temp_file_path = f"temp_{normalized_filename}"

    try:
        # Use async file operations
        async with aiofiles.open(temp_file_path, "wb") as buffer:
            content = await file.read()
            await buffer.write(content)
        
        file_record = insert_document_record(db, normalized_filename, file_extension, DEFAULT_UPLOADER)
        logging.info(f"Inserted document metadata: {file_record.FILE_ID}, {file_record.FILE_NAME}")
        
        if is_internal_apps_md:
            from chroma_utils import index_internal_apps_to_chroma
            success, description = index_internal_apps_to_chroma(temp_file_path, file_record)
        else:
            success, description = index_document_to_chroma(temp_file_path, file_record)
        
        if success and description:
            update_document_record(db, file_id=file_record.FILE_ID, file_description=description)
            logging.info(f"Successfully indexed {normalized_filename}")
            return {"message": f"File {normalized_filename} uploaded and indexed successfully.", "file_id": file_record.FILE_ID}
        else:
            delete_document_record(db, file_record.FILE_ID)
            raise HTTPException(status_code=500, detail=f"Failed to index {normalized_filename}.")
    
    finally:
        if os.path.exists(temp_file_path):
            os.remove(temp_file_path)


@app.get("/list-docs", response_model=list[DocumentInfo])
def list_documents(
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(["admin"]))
):
    return get_all_documents(db)


@app.post("/delete-doc")
def delete_document(
    request: DeleteFileRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(["admin"]))
):
    try:
        logging.info(f"Deleting document with file_id {request.file_id}")
        
        doc_record = db.query(DocumentStore).filter_by(FILE_ID=request.file_id, IS_DELETED=False).first()
        if not doc_record:
            raise HTTPException(status_code=404, detail=f"Document with file_id {request.file_id} not found")
        
        is_internal_apps_md = (doc_record.FILE_NAME == INTERNAL_APPS_KNOWLEDGE_FILE)
        
        if is_internal_apps_md:
            try:
                existing_docs = vectorstore.get(where={"type": "internal_apps"})
                if existing_docs and len(existing_docs['ids']) > 0:
                    vectorstore._collection.delete(where={"type": "internal_apps"})
                chroma_deleted = True
            except Exception as e:
                logging.error(f"Error deleting internal apps: {e}")
                chroma_deleted = False
        else:
            chroma_deleted = delete_doc_from_chroma(request.file_id)

        if not chroma_deleted:
            raise HTTPException(status_code=500, detail="Failed to delete document from ChromaDB")

        db_deleted = delete_document_record(db, request.file_id)
        if not db_deleted:
            raise HTTPException(status_code=500, detail="Deleted from ChromaDB but failed to delete from MySQL")

        return {"message": f"Successfully deleted document with file_id {request.file_id}"}

    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


def _delete_old_chunks_from_chroma(is_internal_apps: bool, file_id: int = None) -> None:
    """Helper function to delete old document chunks from ChromaDB."""
    if is_internal_apps:
        try:
            existing_docs = vectorstore.get(where={"type": "internal_apps"})
            if existing_docs and len(existing_docs['ids']) > 0:
                vectorstore._collection.delete(where={"type": "internal_apps"})
        except Exception as e:
            logging.warning(f"No existing internal app documents to delete: {e}")
    else:
        delete_doc_from_chroma(file_id)


def _create_temp_file_record(file_id: int, file_name: str):
    """Helper function to create a temporary file record object."""
    class TempFileRecord:
        def __init__(self, file_id, file_name, description=None):
            self.FILE_ID = file_id
            self.FILE_NAME = file_name
            self.DESCRIPTION = description
    return TempFileRecord(file_id, file_name)


@app.post("/update-doc")
async def update_document(
    file: UploadFile = File(...),
    file_id: int = Form(...),
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(["admin"]))
):
    """Update an existing document by replacing its content while preserving FILE_ID."""
    normalized_filename = normalize_uploaded_filename(file.filename)
    file_extension = os.path.splitext(normalized_filename)[1].lower()
    is_internal_apps_md = (normalized_filename == INTERNAL_APPS_KNOWLEDGE_FILE)

    if file_extension not in ALLOWED_FILE_EXTENSIONS:
        raise HTTPException(status_code=400, detail=f"Unsupported file type. Allowed: {', '.join(ALLOWED_FILE_EXTENSIONS)}")

    existing_doc = db.query(DocumentStore).filter_by(FILE_ID=file_id, IS_DELETED=False).first()
    if not existing_doc:
        raise HTTPException(status_code=404, detail=f"Document with file_id {file_id} not found")

    temp_file_path = f"temp_update_{normalized_filename}"

    try:
        # Use async file operations
        async with aiofiles.open(temp_file_path, "wb") as buffer:
            content = await file.read()
            await buffer.write(content)

        # Delete old chunks from ChromaDB using helper function
        _delete_old_chunks_from_chroma(is_internal_apps_md, file_id)

        # Create temporary file record
        temp_record = _create_temp_file_record(file_id, normalized_filename)

        if is_internal_apps_md:
            from chroma_utils import index_internal_apps_to_chroma
            success, description = index_internal_apps_to_chroma(temp_file_path, temp_record)
        else:
            success, description = index_document_to_chroma(temp_file_path, temp_record)

        if success and description:
            existing_doc.FILE_NAME = normalized_filename
            existing_doc.FILE_TYPE = file_extension
            existing_doc.DESCRIPTION = description
            db.commit()
            logging.info(f"Updated document {file_id} with {normalized_filename}")
            return {
                "message": f"Document {file_id} updated successfully with {normalized_filename}",
                "file_id": file_id,
                "new_file_name": normalized_filename
            }
        else:
            raise HTTPException(status_code=500, detail="Failed to index new document in ChromaDB")

    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Error updating document: {e}")
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        if os.path.exists(temp_file_path):
            os.remove(temp_file_path)


@app.get("/get-conversation/{session_id}")
def get_conversation(
    session_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """Get conversation history for a specific session."""
    try:
        conversation = get_chat_history(db, session_id)
        return {"conversation": conversation, "session_id": session_id}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/end-session/{session_id}")
def end_chat_session(session_id: str, db: Session = Depends(get_db)):
    """Soft delete chat session when user logs out."""
    try:
        success = soft_delete_chat_session(db, session_id)
        if success:
            return {"message": f"Chat session {session_id} ended successfully"}
        raise HTTPException(status_code=404, detail="Session not found")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ========== vThink Web Sync Endpoint (Admin only) ==========

@app.post("/sync-web")
async def sync_web_knowledge_base(
    current_user: dict = Depends(require_role(["admin"]))
):
    """
    Trigger vThink Web knowledge base sync.
    Phase 1: Compare sitemaps to detect URL changes.
    Phase 2: Crawl changed URLs, clean via LLM, store in ChromaDB.
    """
    try:
        logging.info(f"Web sync initiated by {current_user['emp_id']}")
        result = await sync_all_sites()
        logging.info(f"Web sync completed successfully")
        return result
    except Exception as e:
        logging.error(f"Web sync failed: {e}")
        raise HTTPException(status_code=500, detail=f"Sync failed: {str(e)}")


# ========== Authentication Endpoints ==========

@app.post("/api/auth/login", response_model=LoginResponse)
async def login(request: LoginRequest, db: Session = Depends(get_db)):
    """
    Login endpoint - validates email and returns JWT token with session info.

    Args:
        request: LoginRequest with email
        db: Database session

    Returns:
        LoginResponse with token, role, EMP_ID, NAME, session_id, redirect path
    """
    try:
        # Validate email domain
        validate_email_domain(request.email)

        # Find user by email
        user = db.query(Users).filter(Users.EMAIL == request.email).first()
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="User not found"
            )

        # Generate JWT token (8-hour expiry)
        token = create_jwt_token(user.EMP_ID, user.ROLE)

        # Generate session ID
        session_id = generate_session_id()

        # Store session in database
        create_session(db, user.EMP_ID, session_id, token)

        # Determine redirect path based on role
        redirect_path = "/dashboard" if user.ROLE == "admin" else "/chatbot"

        logging.info(f"Login successful | EMP_ID: {user.EMP_ID}, Role: {user.ROLE}")

        return LoginResponse(
            token=token,
            role=user.ROLE,
            EMP_ID=user.EMP_ID,
            NAME=user.NAME,
            session_id=session_id,
            redirect=redirect_path
        )

    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Login error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Login failed: {str(e)}"
        )


@app.post("/api/auth/logout")
async def logout(
    request: LogoutRequest,
    db: Session = Depends(get_db),
    current_user: Optional[dict] = Depends(get_current_user_optional)
):
    """
    Logout endpoint - ends session and soft-deletes chat history.

    Note: Authentication is optional for logout to handle expired tokens gracefully.

    Args:
        request: LogoutRequest with session_id
        db: Database session
        current_user: Current authenticated user (optional)

    Returns:
        Success message
    """
    try:
        # Try to get emp_id from authenticated user, otherwise proceed without it
        emp_id = current_user["emp_id"] if current_user else "unknown"

        # Delete session from Sessions table
        deleted = delete_session_by_session_id(db, request.session_id)
        if not deleted:
            logging.warning(f"Session {request.session_id} not found for user {emp_id}")
        else:
            logging.info(f"Session {request.session_id} deleted for user {emp_id}")

        # Soft delete chat session
        chat_deleted = soft_delete_chat_session(db, request.session_id)
        if chat_deleted:
            logging.info(f"Chat session {request.session_id} soft-deleted")

        logging.info(f"Logout successful | EMP_ID: {emp_id}, Session: {request.session_id}")
        return {"message": "Logged out successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logging.error(f"Logout error: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Logout failed: {str(e)}"
        )


# ========== User Management Endpoints (Admin only) ==========

@app.post("/api/users/add", response_model=UserResponse)
async def add_user(
    user_data: AddUserRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(["admin"]))
):
    """
    Add a new user (Admin only).

    Args:
        user_data: User data to add
        db: Database session
        current_user: Current authenticated admin user

    Returns:
        Created user data
    """
    new_user = add_user_to_db(
        db,
        emp_id=user_data.emp_id,
        name=user_data.name,
        email=user_data.email,
        role=user_data.role
    )
    logging.info(f"User added | EMP_ID: {new_user.EMP_ID}, by: {current_user['emp_id']}")
    return UserResponse(
        EMP_ID=new_user.EMP_ID,
        NAME=new_user.NAME,
        EMAIL=new_user.EMAIL,
        ROLE=new_user.ROLE,
        IS_ACTIVE=new_user.IS_ACTIVE
    )


@app.put("/api/users/edit/{emp_id}", response_model=UserResponse)
async def edit_user(
    emp_id: str,
    user_data: UpdateUserRequest,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(["admin"]))
):
    """
    Update user details (Admin only).

    Args:
        emp_id: Employee ID of user to update
        user_data: Updated user data
        db: Database session
        current_user: Current authenticated admin user

    Returns:
        Updated user data
    """
    updated_user = update_user_in_db(
        db,
        emp_id=emp_id,
        name=user_data.name,
        email=user_data.email,
        role=user_data.role
    )
    logging.info(f"User updated | EMP_ID: {emp_id}, by: {current_user['emp_id']}")
    return UserResponse(
        EMP_ID=updated_user.EMP_ID,
        NAME=updated_user.NAME,
        EMAIL=updated_user.EMAIL,
        ROLE=updated_user.ROLE,
        IS_ACTIVE=updated_user.IS_ACTIVE
    )


@app.delete("/api/users/delete/{emp_id}")
async def delete_user(
    emp_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(["admin"]))
):
    """
    Delete a user (Admin only).

    Args:
        emp_id: Employee ID of user to delete
        db: Database session
        current_user: Current authenticated admin user

    Returns:
        Success message
    """
    result = delete_user_from_db(db, emp_id)
    logging.info(f"User deleted | EMP_ID: {emp_id}, by: {current_user['emp_id']}")
    return result


@app.get("/api/users/list", response_model=PaginatedUsersResponse)
async def list_users(
    page: int = Query(1, ge=1),
    page_size: int = Query(10, ge=1, le=100),
    db: Session = Depends(get_db),
    current_user: dict = Depends(require_role(["admin"]))
):
    """
    List users with server-side pagination (Admin only).

    Args:
        page: Page number (1-indexed, default 1)
        page_size: Number of users per page (default 10, max 100)
        db: Database session
        current_user: Current authenticated admin user

    Returns:
        Paginated list of users with total count and page info
    """
    result = get_paginated_users_from_db(db, page, page_size)
    return PaginatedUsersResponse(
        users=[
            UserResponse(
                EMP_ID=user.EMP_ID,
                NAME=user.NAME,
                EMAIL=user.EMAIL,
                ROLE=user.ROLE,
                IS_ACTIVE=user.IS_ACTIVE
            )
            for user in result["users"]
        ],
        total=result["total"],
        page=result["page"],
        page_size=result["page_size"],
        total_pages=result["total_pages"]
    )


@app.post("/api/users/check-user/{emp_id}")
async def check_user_exists(emp_id: str, db: Session = Depends(get_db)):
    """
    Check if a user exists by EMP_ID.

    Args:
        emp_id: Employee ID to check
        db: Database session

    Returns:
        Success message if user exists, 404 otherwise
    """
    exists = check_user_exists_in_db(db, emp_id)
    if not exists:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"User with EMP_ID {emp_id} does not exist."
        )
    return {"message": "User exists", "emp_id": emp_id}
