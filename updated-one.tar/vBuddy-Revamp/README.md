# vBuddy - Employee Policy Assistant Chatbot

An AI-powered employee assistant chatbot for vThink Global Technologies that helps employees find answers to company policy questions instantly.

---

## 📋 Table of Contents

- [Overview](#overview)
- [Architecture](#architecture)
- [Prerequisites](#prerequisites)
- [Project Structure](#project-structure)
- [Setup Instructions](#setup-instructions)
  - [1. Database Setup](#1-database-setup)
  - [2. Python Server Setup](#2-python-server-setup)
  - [3. Angular Frontend Setup](#3-angular-frontend-setup)
- [Running the Application](#running-the-application)
- [Environment Variables](#environment-variables)
- [API Endpoints](#api-endpoints)
- [Troubleshooting](#troubleshooting)

---

## 🔍 Overview

vBuddy is a RAG (Retrieval-Augmented Generation) based chatbot that can:
- Allow employees to ask questions about company policies
- Provide instant, accurate answers from uploaded HR/Policy documents
- Support Microsoft SSO login for secure access
- Include an Admin panel for user and document management
- Role-based access control (Admin vs User)

---

## 🏗️ Architecture

```
┌─────────────────-┐
│  Angular Frontend│
│    (Port 4200)   │
└────────┬─────────┘
         │ HTTP/REST API
         ▼
┌─────────────────────────────────┐
│      Python FastAPI Server      │
│        (Port 8000)              │
│                                 │
│  ┌───────────────────────────┐  │
│  │  Authentication Module    │  │
│  │  - JWT Tokens             │  │
│  │  - Session Management     │  │
│  │  - User Management        │  │
│  └───────────────────────────┘  │
│                                 │
│  ┌───────────────────────────┐  │
│  │     RAG Engine            │  │
│  │  - Document Processing    │  │
│  │  - Vector Search          │  │
│  │  - LLM Response Gen       │  │
│  └───────────────────────────┘  │
└──────────────┬──────────────────┘
               │
               ▼
    ┌─────────────────────┐
    │   MySQL Database    │
    │   + ChromaDB        │
    │   (Vector Store)    │
    └─────────────────────┘
```

---

## ✅ Prerequisites

Before setting up the project, ensure you have the following installed:

| Software | Version | Download Link |
|----------|---------|---------------|
| **Python** | 3.9 or higher | [python.org](https://www.python.org/) |
| **MySQL** | 8.0 or higher | [mysql.com](https://www.mysql.com/) |
| **Angular CLI** | v14 | `npm install -g @angular/cli@14` |
| **Node.js** | v16 or higher | [nodejs.org](https://nodejs.org/) |
| **Git** | Latest | [git-scm.com](https://git-scm.com/) |

---

## 📁 Project Structure

```
vBuddy-Team-1/
├── Front_End/          # Angular 14 Frontend Application
├── Python_Server/      # Python/FastAPI Backend (All-in-One Server)
│   ├── main.py         # Main application entry point
│   ├── auth.py         # Authentication utilities
│   ├── user_service.py # User management functions
│   ├── db_utils.py     # Database models and utilities
│   ├── pydantic_models.py # Request/Response models
│   └── requirements.txt # Python dependencies
├── dump.sql            # Database schema and initial data
└── README.md           # This file
```

---

## 🚀 Setup Instructions

### 1. Database Setup

#### Step 1: Create the Database
Open MySQL command line or MySQL Workbench and run:

```sql
CREATE DATABASE vbuddy_db;
```

#### Step 2: Import the Database Schema
Navigate to the project root folder and import the SQL dump:

```bash
mysql -u your_username -p vbuddy_db < dump.sql
```

Or using MySQL Workbench:
1. Open MySQL Workbench
2. Connect to your MySQL server
3. Go to **Server** → **Data Import**
4. Select "Import from Self-Contained File" and choose `dump.sql`
5. Select target schema as `vbuddy_db`
6. Click **Start Import**

---

### 2. Python Server Setup

#### Step 1: Navigate to Python Server folder
```bash
cd Python_Server
```

#### Step 2: Create a Virtual Environment (Recommended)
```bash
# Create virtual environment
python3 -m venv venv

# Activate virtual environment
# On macOS/Linux:
source venv/bin/activate

# On Windows:
venv\Scripts\activate
```

#### Step 3: Install Python Dependencies
```bash
pip install -r requirements.txt
```

#### Step 4: Create Environment File
Create a `.env` file in the `Python_Server` folder:

```bash
touch .env
```

Add the following variables to the `.env` file:

```env
# Server Configuration
PORT=8000

# Database Configuration
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_mysql_password
DB_NAME=vbuddy_db

# OpenAI Configuration
OPENAI_API_KEY=your_openai_api_key_here

# JWT Configuration
JWT_SECRET=your_jwt_secret_key_here

# Frontend Configuration
FRONTEND_URL=http://localhost:4200
```

---

### 3. Angular Frontend Setup

#### Step 1: Navigate to Frontend folder
```bash
cd Front_End
```

#### Step 2: Install Angular Dependencies
```bash
npm install
```

#### Step 3: Configure Microsoft Azure AD (for SSO Login)
Update the MSAL configuration in `src/app/app.module.ts` with your Azure AD credentials:
- Client ID
- Tenant ID
- Redirect URI

#### Step 4: Update API URL (if needed)
Edit `src/app/app.constants.ts` to set your Python Server URL:

```typescript
export const AppConstants = {
    apiBaseUrl: "http://localhost:8000",  // Python Server URL
    frontendBaseUrl: "http://localhost:4200",
    // ... other constants
};
```

---

## ▶️ Running the Application

**Important:** Start the servers in the following order:

### Terminal 1: Start Python Server (Port 8000)
```bash
cd Python_Server
source venv/bin/activate  # If using virtual environment
python3 -m uvicorn main:app --reload
```
✅ You should see: `Uvicorn running on http://127.0.0.1:8000`

### Terminal 2: Start Angular Frontend (Port 4200)
```bash
cd Front_End
ng serve
```
✅ You should see: `Angular Live Development Server is listening on localhost:4200`

### Access the Application
Open your browser and navigate to:
```
http://localhost:4200
```

---

## 🔐 Environment Variables

### Python Server (.env)

| Variable | Description | Example |
|----------|-------------|---------|
| `PORT` | Server port | `8000` |
| `OPENAI_API_KEY` | Your OpenAI API key | `sk-xxxxxxxx` |
| `DB_HOST` | MySQL host address | `localhost` |
| `DB_USER` | MySQL username | `root` |
| `DB_PASSWORD` | MySQL password | `password123` |
| `DB_NAME` | Database name | `vbuddy_db` |
| `JWT_SECRET` | Secret key for JWT tokens | `your-secret-key` |
| `FRONTEND_URL` | Frontend URL for CORS | `http://localhost:4200` |

---

## 🌐 API Endpoints

### Authentication

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/login` | User login with email |
| POST | `/api/auth/logout` | User logout |

### User Management (Admin Only)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/users/add` | Add new user |
| PUT | `/api/users/edit/{emp_id}` | Update user |
| DELETE | `/api/users/delete/{emp_id}` | Delete user |
| GET | `/api/users/list` | List all users |
| POST | `/api/users/check-user/{emp_id}` | Check if user exists |

### Chat & RAG

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/chat` | Send chat query |
| GET | `/get-conversation/{session_id}` | Get conversation history |
| POST | `/end-session/{session_id}` | End chat session |

### Document Management (Admin Only)

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/upload-doc` | Upload document |
| GET | `/list-docs` | List all documents |
| POST | `/delete-doc` | Delete document |
| POST | `/update-doc` | Update document |

---

## ❓ Troubleshooting

### Common Issues

#### 1. "Module not found" error in Python
```bash
pip install -r requirements.txt
```

#### 2. "Cannot connect to MySQL" error
- Verify MySQL service is running
- Check your database credentials in `.env` file
- Ensure the database `vbuddy_db` exists

#### 3. Angular build fails
```bash
# Clear cache and reinstall
cd Front_End
rm -rf node_modules
npm cache clean --force
npm install
```

#### 4. CORS errors in browser
- Ensure Python server is running on port 8000
- Check that `FRONTEND_URL` in `.env` matches your Angular URL
- Verify `apiBaseUrl` in `app.constants.ts` points to Python Server

#### 5. "Port already in use" error
```bash
# Find and kill process on specific port (example: port 8000)
# On macOS/Linux:
lsof -ti:8000 | xargs kill -9

# On Windows:
netstat -ano | findstr :8000
taskkill /PID <PID> /F
```

#### 6. Login not working
- Verify email domain is `@vthink.co.in`
- Check if user exists in database
- Ensure `JWT_SECRET` is set in `.env`
- Check browser console for error messages

#### 7. Chat responses not working
- Verify `OPENAI_API_KEY` is valid
- Check Python server logs for errors
- Ensure documents are uploaded for RAG to work

---

## 📞 Support

For any issues or questions, please contact the development team.

---

## 📄 License

This project is proprietary to vThink Global Technologies.
